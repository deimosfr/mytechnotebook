/****************************************************************************/
/*                                                                          */
/*   daemon_func.h                                                          */
/*   Generic function to create daemon process                              */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/


#if !defined( DAEMON_FUNC_H )
#define DAEMON_FUNC_H

void daemon_init( int ignore_sigcld, void (*SIGTERM_handler)(int), void (*cleanup_func)(void*), void* arg );

#endif
