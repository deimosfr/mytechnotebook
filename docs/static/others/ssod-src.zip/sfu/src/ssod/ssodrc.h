
/****************************************************************************/
/*                                                                          */
/*   ssodrc.h                                                               */
/*   Error messages                                                         */
/*                                                                          */
/*   Copyright 1998-2000 Microsoft Corporation                              */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _SSOD_RC_H
#define _SSOD_RC_H

const char* IDS_SSOD_KILLED_BY_TERM_SIGNAL="Ssod killed by term signal";
const char* IDS_SINGLE_SIGN_ON_DAEMON="Single Sign-On Daemon";
const char* IDS_COPYRIGHT="Copyright 1998 -2000 Microsoft Corporation";
const char* IDS_RIGHTS_RESERVED="All rights reserved.";
const char* IDS_USAGE="Usage -- The following command line options are valid";
const char* IDS_VERBOSE_MODE="  -v                   - verbose mode";
const char* IDS_COULD_NOT_CHDIR_TO="Could not change dir to";
const char* IDS_DIR="Dir: ";
const char* IDS_UNABLE_TO_RUN_NIS_UPDATE_SCRIPT="Unable to run nis update script";
const char* IDS_RECEIVED_MESSAGE_OF_IMPROPER_TYPE="Received message of improper type";
const char* IDS_RESTRICTED_FROM_SYNCHRONIZING_PASSWORD="Restricted from synchronizing password";
const char* IDS_SUCCESSFULLY_UPDATED_PASSWORD_VIA_PAM="Successfully updated password via PAM";
const char* IDS_SUCCESSFULLY_UPDATED_PASSWORD="Successfully updated password";
const char* IDS_ERROR="Error: ";
const char* IDS_FAILED_TO_UPDATE_PASSWORD="Failed to update password";
const char* IDS_TOO_MANY_NIS_CHILDREN_ARE_ACTIVE_CURRENTLY="Too many NIS children are active currently";
const char* IDS_UNABLE_TO_UPDATE_NIS_PASSWORDS="Unable tp update NIS passwords";
const char* IDS_UNABLE_TO_COMPLETE_TRANSMISSION_OF_RESPONSE_PACKET="Unable to complete transmission of response packet";
const char* IDS_RECEIVED_SIGNAL_TO_REREAD_CONF_FILE="Received signal to reread config file";
const char* IDS_SSOD_CAN_ONLY_BE_RUN_BY_ROOT="Ssod can only be run by root";
const char* IDS_UNABLE_TO_BIND="Unable to bind";
const char* IDS_PORT_NUMBER="Port Number: ";
const char* IDS_UNABLE_TO_LISTEN="Unable to listen";
const char* IDS_ERROR_REREADING_CONFIGURATION_FILE="Error rereading config file";
const char* IDS_CONFIGURATION_FILE_REREAD_SUCCESSFULLY="Configuration file reread successfully";
const char* IDS_NTHOST="Nt host: ";
const char* IDS_NT_HOST_NOT_TRUSTED="Nt host not trusted";
const char* IDS_CANT_FORK_CHILD_PROCESS_TOHANDLE_PASSWORD_PROPAGATION="Can't fork child process to handle password propagation";
const char* IDS_CANNOT_OPEN_PASSWORD_FILE="Cannot open password file";
const char* IDS_BAD_PASSWORD_FILE="Bad password file";
const char* IDS_UNABLE_TO_CREATE_PACKET_CONTAINER="Error in received data. check for network configuration errors.";
const char* IDS_UNABLE_TO_CREATE_SOCKET="Unable to create socket";
const char* IDS_SSOD_FAILED_TO_LOOK_UP_UNIX_USER="Ssod failed to look up UNIX user";
const char* IDS_UNABLE_TO_SETSOCKOPT="Unable to set socket option";

#endif // _SSOD_RC_H_

