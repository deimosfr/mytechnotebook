/****************************************************************************/
/*                                                                          */
/*   password.cpp                                                           */
/*   Functions to change a user's password                                  */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/


#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pwd.h>
#include <errno.h>
#include <syslog.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/timeb.h>
#include <time.h>

#ifdef aix42
	#include <time.h>
	#include <strings.h>
	#include <userpw.h>
#else
	#include <shadow.h>
#endif

#include "passwdrc.h"

#include <crypt.h>
#ifndef linux
#pragma warning( disable:4005 ) // warning C4005: macro redefinition
#endif
#include "password.h"
#ifndef linux
#pragma warning( default:4005 )
#endif

#include "../common/messages.h"

extern "C" void printMessages(int msgType,const char* str);

#ifdef hp700_ux10    //putspwent is found with no prototype in library
extern "C" int putpwent(const struct passwd *p, FILE *f);
struct spwd *fgetspent(FILE *fp);
int putspent(const struct spwd *p, FILE *fp);
#endif 

#ifdef aix42

/* modes for set attribute routines */
#define S_READ          0x1
#define S_WRITE         0x2

#endif

// From resetpass.c

#define MAXLINE 1000                                       // Maximum number of lines allowed in the passwd file
#define PASSWORD_TMP_FILE "/tmp/ptmp"                      // Temporary file used when changing password
#define MAX_RETRIES 5                                      // Maximum number of retries to lock passwd file

extern "C" size_t strlcat(char *dst, const char *src, size_t sz);

extern "C" size_t strlcpy(char *dst, const char *src, size_t siz);
// Additional defines in order to use resetpass.c code here

size_t strlcat(char *dst, const char *src, size_t sz)
{
	size_t n = sz;
	char *p, *q;

	if ((p = (char*) memchr(dst, '\0', sz)) != 0) {
		n = p - dst;
		if ((q = (char*) memccpy(p, src, '\0', sz - n)) != 0)
													return q - dst - 1;
										/*** 
										 * * Not enough space: terminate (sz cannot be 0)
						 * 		 		 * and return the same answer as if it had fit
										 * 		 		 		 */
											dst[sz - 1] = '\0';
											}
	return n + strlen(src);
}
size_t strlcpy(char *dst, const char *src, size_t siz)
{
        char *d = dst;
	const char *s = src;
	size_t n = siz;

	if (n != 0 && --n != 0) {
	        do {
									                           if ((*d++ = *s++) == 0)
									                                   break;
										                   } while (--n != 0);
	 }

	if (n == 0) {

		if (siz != 0)
										                           *(d) = '\0';
									                   while (*s++)
									                           ;
	
	}
	return(s - src - 1);
}

#define random rand
#define srandom srand

// function that computes the number days since January  1,  1970
// and today( the day of password change)

int GetLastChgDays(time_t *pnDays)
{
	struct timeb tp;
	int rc;

	rc = ftime(&tp);

	if (!rc)
		 *pnDays = 1 + (tp.time / ( 24 * 60 * 60)) ;

	return  rc;
}

// Function that converts long to char*


void
toprintchar(char *s, long int v, int n)
{
  static unsigned char szItoA[] = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

  while(--n >=0)
  {
    *s++ = szItoA[v&0x3f];
    v >>= 6;
  }
}


// Function to change passwd file entries

DWORD
setpassword(char *szUserName, const char *szPassword, const char *szPasswordFile, unsigned int fTemp,
			unsigned int fCaseIgnore)
{
    int retries=0;
    int fdTmpPasswordFile;
    int fFound = 0, fValidPassword = 0;
    FILE *fpTmpPasswordFile, *fpPasswordFile;
    char salt[9];
    char szLine[MAX_PW_ENTRY_LEN], *szPtr = NULL, *szCryptPass = NULL;
    char szTmpPasswordFile[1000], szPasswordFileOld[1000];
    char szBuffer[MAX_BUFFER_SIZE+1];
    
    char *szTmpStr;

	unsigned int fSameUser;

    strlcpy(szPasswordFileOld,szPasswordFile, sizeof(szPasswordFileOld));
    strlcat(szPasswordFileOld,".old", sizeof(szPasswordFileOld)-strlen(szPasswordFile));
    strlcpy(szTmpPasswordFile, szPasswordFile, sizeof(szTmpPasswordFile));

    if ((szTmpStr = strrchr(szTmpPasswordFile,'/')) == NULL)
        szTmpStr = szTmpPasswordFile-1;

    sprintf(szTmpStr+1,"ptmp.%d",getpid());

    //open the temporary file for writing in exclusive access mode
    while((( fdTmpPasswordFile = open (szTmpPasswordFile, O_CREAT|O_WRONLY|O_EXCL, 0600))< 0) && retries  < MAX_RETRIES)
    {
        sleep(1); // wait for a second before retrying.
        retries++;
    }
    
    if (retries == MAX_RETRIES)
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_TEMPORARY_PASSWORD_FILE_CREATION_ERROR,IDS_ERROR,strerror(errno));
    	printMessages(LOGERR,szBuffer);
        
        return ERROR_LOCK_VIOLATION;
    }
    if ( NULL == ((fpTmpPasswordFile = fdopen(fdTmpPasswordFile,"w"))))
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_TEMPORARY_PASSWORD_FILE_CREATION_ERROR,IDS_ERROR,strerror(errno));
    	printMessages(LOGERR,szBuffer);
    	
        return ERROR_CANNOT_OPEN_FILE;
    }

    if ( NULL == ( fpPasswordFile = fopen(szPasswordFile,"r")) )
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_PASSWORD_FILE_OPENING_ERROR,IDS_ERROR,strerror(errno));
    	printMessages(LOGERR,szBuffer);
    
        return ERROR_CANNOT_OPEN_FILE;
    }

    // 
    // Parse the passwd file, find the user, replace the password
    // Write to temp file

    while (fgets(szLine, sizeof(szLine), fpPasswordFile))
    {
        if (!strchr(szLine, '\n'))
        {
        	printMessages(LOGERR,IDS_BAD_PASSWORD_FILE);
            
            return ERROR_BAD_PASSWORD_FILE;
        }

        if (fFound)
        {
           fprintf(fpTmpPasswordFile, "%s", szLine); 
           if (ferror(fpTmpPasswordFile))
           {
           	   snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_WRITING_TEMPORARY_PASSWORD_FILE,IDS_ERROR,strerror(errno));
    		   printMessages(LOGERR,szBuffer);
               
               return ERROR_WRITE_FAULT;
           }
           continue;
        }

        //
        // Skip blank and comment lines

        for (szPtr = szLine; *szPtr != '\n'; szPtr++)
            if (*szPtr != ' ' && *szPtr != '\t')
                break;
        if (*szPtr == '#' || *szPtr == '\n')
        {
            (void)fprintf(fpTmpPasswordFile, "%s", szLine);
            if (ferror(fpTmpPasswordFile))
            {
               snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_WRITING_TEMPORARY_PASSWORD_FILE,IDS_ERROR,strerror(errno));
    		   printMessages(LOGERR,szBuffer);
               
               return ERROR_WRITE_FAULT;
            }
        }

        if (!(szPtr = strchr(szLine, ':')))
        {
			printMessages(LOGERR,IDS_BAD_PASSWORD_FILE);
            
            return ERROR_BAD_PASSWORD_FILE;
        }
        *szPtr = '\0';

		// username in NT and UNIX could differ in case.
		// use the config file directive to compare

		if (fCaseIgnore)
			fSameUser = strcasecmp(szLine, szUserName);
		else
			fSameUser = strcmp(szLine, szUserName);

        if (fSameUser) // Not the same user 
		{

            *szPtr = ':';
            (void)fprintf(fpTmpPasswordFile, "%s", szLine);
            if (ferror(fpTmpPasswordFile))
            {
            	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_WRITING_TEMPORARY_PASSWORD_FILE,IDS_ERROR,strerror(errno));
    		    printMessages(LOGERR,szBuffer);   
                
                return ERROR_WRITE_FAULT;
            }
            continue;
        }

		// copy the unix username into szUserName for use later.
		//

		strcpy(szUserName,szLine);

        szCryptPass = szPtr+1;

        if (!(szPtr = strchr(szCryptPass, ':')))
        {
            printMessages(LOGERR,IDS_BAD_PASSWORD_FILE);
            
            return ERROR_BAD_PASSWORD_FILE;
        }
        *szPtr = '\0';

        //
        // We allow password to be blank and any other 13 character lengh
        // ansi string (just a heuristic). In other cases, we consider what is their 
        // in the password field is not a valid crypted passwrod and the account is 
        // disabled. We make no attempt to enable it. 
        //

        if (!*szCryptPass)
        {
            fValidPassword = 1;
        }

        if (strlen(szCryptPass) == CRYPT_PASSWORD_LEN)
        {
            for (;*szCryptPass && isascii(*szCryptPass); szCryptPass++);

            if (!*szCryptPass)
            {
                fValidPassword = 1;
            }
        }

        if (!fValidPassword)
        {
            // Doesn't look like a valid password; Entry is disabled, 
            // although the user could be found

            fclose(fpPasswordFile);
            fclose(fpTmpPasswordFile);
            unlink(szTmpPasswordFile);

            
            snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_LOGIN_DISABLED,IDS_USER,szUserName,IDS_ERROR,strerror(errno));
            printMessages(LOGERR,szBuffer);
            
            return ERROR_USER_LOGIN_DISABLED;
        }
            
        srandom((int)time((time_t *)NULL));
        toprintchar(&salt[0], random(), 2);

        fprintf(fpTmpPasswordFile, "%s:%s:%s", szLine, crypt(szPassword,salt),szPtr + 1);
        if (ferror(fpTmpPasswordFile))
        {
			printMessages(LOGERR,IDS_ERROR_WRITING_TEMPORARY_PASSWORD_FILE);

            return ERROR_WRITE_FAULT;
        }
        fFound = 1;
		
    }

    fclose(fpPasswordFile);
    fclose(fpTmpPasswordFile);

    if (fFound && !fTemp)
    {
        mode_t  accessMode;
        struct stat statEntry;

        // Get the access permissions of the file first
        if (stat(szPasswordFile, &statEntry) != 0)
        {
            // Set to some default value
            accessMode = 0600 & ~umask(0);
        }
        else
        {
            // Read the access mode into our variable
            // Only the last 12 bits are relevant to us
            accessMode = statEntry.st_mode & 07777;
        }

        unlink(szPasswordFileOld);

        if ( link(szPasswordFile,szPasswordFileOld) == -1 )
        {
        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_UNLINKING_OLD_PASSWORD_FILE,IDS_ERROR,strerror(errno));
    		printMessages(LOGERR,szBuffer);   
                
            unlink(szTmpPasswordFile);
            return errno;
        }
        if ( rename(szTmpPasswordFile,szPasswordFile) == -1 )
        {
        	snprintf(szBuffer, sizeof(szBuffer), "%s %s %s",IDS_ERROR_UNLINKING_OLD_PASSWORD_FILE,IDS_ERROR,strerror(errno));
    		printMessages(LOGERR,szBuffer);   

            unlink(szTmpPasswordFile);
            return errno;
        }
        chmod(szPasswordFile, accessMode);
    }
    else
        unlink(szTmpPasswordFile);

    if (fFound)
        return ERROR_SUCCESS;

    return (ERROR_NO_USER_ENTRY);
}



// Function to change shadow file passwords

DWORD
setshadowpassword(char *szUserName, char *szPassword, char *szShadowPasswordFile, unsigned int fTemp, 
				  unsigned int fCaseIgnore)
{
#ifdef hp700_ux10
    return ERROR_SUCCESS;
#endif

    int retries=0;
    int fdTmpShadowPasswordFile;
    int fFound = 0, fValidPassword = 0;
    FILE *fpTmpShadowPasswordFile, *fpShadowPasswordFile;
    char salt[9];
    char szLine[MAX_PW_ENTRY_LEN], *szPtr = NULL, *szCryptPass = NULL;
    char szTmpShadowPasswordFile[1000], szShadowPasswordFileOld[1000];
    
    char *szTmpStr;

	unsigned int fSameUser;
	time_t nDays;
	char szBuffer[MAX_BUFFER_SIZE+1];


#ifdef aix42
    struct timeb tb;
	int rc;
	struct userpw *pUserPw = NULL;
	struct userpw UserPw = {0};
	char cryptPassword[14];

	//  open database in read mode
	if (rc = setpwdb(S_READ))
	{
		printMessages(LOGERR,IDS_UNABLE_TO_READ_PASSWD_FILE);

		return ERROR_CANNOT_OPEN_FILE;
	}

	if ((pUserPw = getuserpw(szUserName)) == NULL)
	{
		// username in NT and UNIX could differ in case.
		// use the config file directive to compare

		if (!fCaseIgnore)
		{
			// you didnt find the user
			
			printMessages(LOGERR,IDS_BAD_SHADOW_FILE);

			return ERROR_BAD_SHADOW_FILE;
		}
		else
		{
			// read the /etc/security/passwd file and
			// in each stanza look for '<user name>:'

			if ( NULL == ( fpShadowPasswordFile = fopen(szShadowPasswordFile,"r")) )
			{
				snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_CANNOT_OPEN_ETC_SEC_PASS_FILE,IDS_ERROR,strerror(errno));
				printMessages(LOGWARN,szBuffer);
				
				return ERROR_CANNOT_OPEN_FILE;
			}

			while (fgets(szLine, sizeof(szLine), fpShadowPasswordFile))
			{
				if (!strchr(szLine, '\n'))
				{
					fclose(fpShadowPasswordFile);
					printMessages(LOGERR,IDS_BAD_SHADOW_FILE);

					return ERROR_BAD_SHADOW_FILE;
				}
				
				// in the user name line inside the stanza
				if (szPtr = strchr(szLine, ':'))
				{
					*szPtr = '\0';

					if (fFound  =  !strcasecmp(szLine, szUserName))
					{
					    strcpy(szUserName, szLine);
					    break;
					}
				}
			}
			
			if (!fFound)
			{
				fclose(fpShadowPasswordFile);
				printMessages(LOGERR,IDS_BAD_SHADOW_FILE);
				
				return ERROR_NO_USER_ENTRY;
			}
			else
			{
				snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_FOUND_USER,IDS_USER,szUserName);
				printMessages(LOGERR,szBuffer);
				
				if ((pUserPw = getuserpw(szUserName)) == NULL)
				{
					printMessages(LOGERR,IDS_BAD_SHADOW_FILE);
					return ERROR_BAD_SHADOW_FILE;
				}
			}

            fclose(fpShadowPasswordFile);
		}
	}
	
	strncpy(UserPw.upw_name, pUserPw->upw_name, PW_NAMELEN);
	UserPw.upw_flags =  pUserPw->upw_flags ;

	if (rc = endpwdb())
	{
		printMessages(LOGERR,IDS_UNABLE_TO_READ_PASSWD_FILE);

		return ERROR_CANNOT_OPEN_FILE;
	}

	// make ready security database for write
	if (rc = setpwdb(S_WRITE))
	{
		printMessages(LOGERR,IDS_UNABLE_TO_READ_PASSWD_FILE);

		return ERROR_CANNOT_OPEN_FILE;
	}

	// set the  user passwd entry for /etc/security/passwd and set it.
	srandom((int)time((time_t *)NULL));
	toprintchar(&salt[0], random(), 2);
	strlcpy(cryptPassword, crypt(szPassword,salt), sizeof(cryptPassword));
	UserPw.upw_passwd = cryptPassword;

	if (-1 == ftime(&tb))
	{
		printMessages(LOGERR,IDS_ERROR_COMPUTING_LAST_CHG_FIELD);
		endpwdb();
		return ERROR_COMPUTING_LASTCHG_FIELD;
	}

	UserPw.upw_lastupdate = tb.time;

	if (putuserpw(&UserPw))
	{
		//  failed to update the database

		snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_WRITING_PASSWD_FILE,IDS_ERROR,strerror(errno));
		printMessages(LOGERR,szBuffer);
		endpwdb();
		return ERROR_WRITE_FAULT;
	}

#else

    // 
    // Parse the shadow file, find the user, replace the password
    // Write to temp file

    snprintf(szShadowPasswordFileOld, sizeof(szShadowPasswordFileOld), "%s.old", szShadowPasswordFile);
    strlcpy(szTmpShadowPasswordFile, szShadowPasswordFile, sizeof(szTmpShadowPasswordFile));


    if ((szTmpStr = strrchr(szTmpShadowPasswordFile,'/')) == NULL)
        szTmpStr = szTmpShadowPasswordFile-1;

    sprintf(szTmpStr+1,"shtmp.%d",getpid());
    
    //open the temporary file for writing in exclusive access mode
    while((( fdTmpShadowPasswordFile = open (szTmpShadowPasswordFile, O_CREAT|O_WRONLY|O_EXCL, 0600))< 0) && retries  < MAX_RETRIES)
    {
        sleep(1);  // wait for a second before retrying.
        retries++;
    }
    
    if (retries == MAX_RETRIES)
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_TEMPORARY_SHADOW_PASSWORD_FILE_CREATION_ERROR,IDS_ERROR,strerror(errno));
		printMessages(LOGWARN,szBuffer);
		
        return ERROR_LOCK_VIOLATION;
    }
    if ( NULL == ((fpTmpShadowPasswordFile = fdopen(fdTmpShadowPasswordFile,"w"))))
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_TEMPORARY_SHADOW_PASSWORD_FILE_CREATION_ERROR,IDS_ERROR,strerror(errno));
		printMessages(LOGWARN,szBuffer);

        return ERROR_CANNOT_OPEN_FILE;
    }

    if ( NULL == ( fpShadowPasswordFile = fopen(szShadowPasswordFile,"r")) )
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_SHADOW_TEMPORARY_PASSWORD_FILE_OPENING_ERROR,IDS_ERROR,strerror(errno));
		printMessages(LOGWARN,szBuffer);

        return ERROR_CANNOT_OPEN_FILE;
    }

    while (fgets(szLine, sizeof(szLine), fpShadowPasswordFile))
    {
        if (!strchr(szLine, '\n'))
        {
			printMessages(LOGERR,IDS_BAD_SHADOW_FILE);
			
            return ERROR_BAD_SHADOW_FILE;
        }

        if (fFound)
        {
           fprintf(fpTmpShadowPasswordFile, "%s", szLine); 
           if (ferror(fpTmpShadowPasswordFile))
           {
           	   snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_WRITING_SHADOW_TEMPORARY_PASSWORD_FILE,IDS_ERROR,strerror(errno));
			   printMessages(LOGERR,szBuffer);
			   
               return ERROR_WRITE_FAULT;
           }
           continue;
        }

        for (szPtr = szLine; *szPtr != '\n'; szPtr++)
            if (*szPtr != ' ' && *szPtr != '\t')
                break;

        //
        // Skip blank and comment lines although there is very little 
        // chance a shadow file will have comments

        if (*szPtr == '#' || *szPtr == '\n')
        {
            (void)fprintf(fpTmpShadowPasswordFile, "%s", szLine);
            if (ferror(fpTmpShadowPasswordFile))
            {
                snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_WRITING_SHADOW_TEMPORARY_PASSWORD_FILE,IDS_ERROR,strerror(errno));
			    printMessages(LOGERR,szBuffer);
			   
                return ERROR_WRITE_FAULT;
            }
            if (ferror(fpTmpShadowPasswordFile))

            continue;
        }

        if (!(szPtr = strchr(szLine, ':')))
        {
            printMessages(LOGERR,IDS_BAD_SHADOW_FILE);
            
            return ERROR_BAD_SHADOW_FILE;
        }
        *szPtr = '\0';

		// username in NT and UNIX could differ in case.
		// use the config file directive to compare

		if (fCaseIgnore)
			fSameUser = strcasecmp(szLine, szUserName);
		else
			fSameUser = strcmp(szLine, szUserName);

        if (fSameUser)  // Not the same user
		{
            *szPtr = ':';
            (void)fprintf(fpTmpShadowPasswordFile, "%s", szLine);
            if (ferror(fpTmpShadowPasswordFile))
            {
            	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_WRITING_SHADOW_TEMPORARY_PASSWORD_FILE,IDS_ERROR,strerror(errno));
			    printMessages(LOGERR,szBuffer);
			   
                return ERROR_WRITE_FAULT;
            }
            continue;
        }

		// copy the unix username into szUserName for use later.
		//

		strcpy(szUserName,szLine);

        szCryptPass = szPtr+1;

        if (!(szPtr = strchr(szCryptPass, ':')))
        {
			printMessages(LOGERR,IDS_BAD_SHADOW_FILE);
			
            return ERROR_BAD_SHADOW_FILE;
        }
        *szPtr = '\0';

        //
        // We allow password to be blank and any other 13 character lengh
        // ansi string (just a heuristic). In other cases, we consider what is their 
        // in the password field is not a valid crypted passwrod and the account is 
        // disabled. We make no attempt to enable it. 
        //

        if (!*szCryptPass)
        {
            fValidPassword = 1;
        }

        if (strlen(szCryptPass) == CRYPT_PASSWORD_LEN)
        {
            for (;*szCryptPass && isascii(*szCryptPass); szCryptPass++);

            if (!*szCryptPass)
            {
                fValidPassword = 1;
            }
        }

        if (!fValidPassword)
        {
            // Doesn't look like a valid password; Entry is disabled, 
            // although the user could be found
            fclose(fpShadowPasswordFile);
            fclose(fpTmpShadowPasswordFile);
            unlink(szTmpShadowPasswordFile);

            snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_LOGIN_DISABLED,IDS_USER,szUserName,IDS_ERROR,strerror(errno));
            printMessages(LOGERR,szBuffer);
            
            return ERROR_USER_LOGIN_DISABLED;
        }
            
        srandom((int)time((time_t *)NULL));
        toprintchar(&salt[0], random(), 2);

		// update the lastchg field of shadow passwd file
		// The field is -  The number of days between January  1,  1970,  and
		// the date that the password was last modified.
		//

		// extract rest of filds after lastchg field
		//

        if (!(szPtr = strchr(szPtr + 1, ':')))
        {
            printMessages(LOGERR,IDS_BAD_SHADOW_FILE);
            
            return ERROR_BAD_SHADOW_FILE;
        }
		if (GetLastChgDays(&nDays))
		{
			printMessages(LOGERR,IDS_ERROR_COMPUTING_LAST_CHG_FIELD);
			
            return ERROR_COMPUTING_LASTCHG_FIELD;
		}
		
        fprintf(fpTmpShadowPasswordFile, "%s:%s:%ld:%s", szLine, crypt(szPassword,salt), nDays, szPtr+1);
        if (ferror(fpTmpShadowPasswordFile))
        {
			printMessages(LOGERR,IDS_ERROR_WRITING_SHADOW_TEMPORARY_PASSWORD_FILE);
            return ERROR_WRITE_FAULT;
        }
        fFound = 1;

    }

    fclose(fpShadowPasswordFile);
    fclose(fpTmpShadowPasswordFile);
    if (fFound && !fTemp)
    {
        mode_t  accessMode;
        struct stat statEntry;

        // Get the access permissions of the file first
        if (stat(szShadowPasswordFile, &statEntry) != 0)
        {
            // Set to some default value
            accessMode = 0600 & ~umask(0);
        }
        else
        {
            // Read the access mode into our variable
            // Only the last 12 bits are relevant to us
            accessMode = statEntry.st_mode & 07777;
        }

        unlink(szShadowPasswordFileOld);

        if ( link(szShadowPasswordFile,szShadowPasswordFileOld) == -1 )
        {
        	printMessages(LOGERR,IDS_ERROR_LINKING_SHADOW_FILE_TO_OLD_SHADOW_FILE);
            unlink(szTmpShadowPasswordFile);
            return errno;
        }
        if ( rename(szTmpShadowPasswordFile,szShadowPasswordFile) == -1 )
        {
        	printMessages(LOGERR,IDS_ERROR_RENAMING_TMP_SHADOW_FILE_TO_SHADOW_FILE);

            unlink(szTmpShadowPasswordFile);
            return errno;
        }
        chmod(szShadowPasswordFile, accessMode);
    }
    else
        unlink(szTmpShadowPasswordFile);

    if (fFound)
        return ERROR_SUCCESS;

    return ERROR_NO_USER_ENTRY;
#endif  // ifdef aix42
}
