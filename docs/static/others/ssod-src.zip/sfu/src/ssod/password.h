
/****************************************************************************/
/*                                                                          */
/*   password.h                                                             */
/*   Functions to change a user's password                                  */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/




#if !defined( PASSWORD_H )
#define PASSWORD_H
#include "../common/nttype.h"

// *******************************
// BUG BUG BUG BUG BUG BUG BUG BUG
// *******************************
// These shoule be redefied to 
// SSOD_ERROR_SUCCESS,
// SSOD_ERROR_FILE_NOT_FOUND etc.
// *******************************
// BUG BUG BUG BUG BUG BUG BUG BUG
// *******************************

#define CRYPT_PASSWORD_LEN   13
#define MAX_PW_ENTRY_LEN     1024
#define MAX_BUFFER_SIZE      512


#define ERROR_SUCCESS        0
#define ERROR_FILE_NOT_FOUND 1
#define ERROR_LOCK_VIOLATION 2
#define ERROR_CANNOT_OPEN_FILE 3
#define ERROR_PASSWORD_NOT_UPDATED 4
#define ERROR_PROTOCOL 5
#define ERROR_BAD_USER_NAME 6
#define ERROR_DECRYPTING 7
#define ERROR_VERSION_NOT_SUPPORTED 8
#define ERROR_BAD_PASSWORD 9
#define ERROR_CANNOT_MAKE_MAPS 10
#define ERROR_WRITE_FAULT 11
#define ERROR_NO_USER_ENTRY  12
#define ERROR_USER_LOGIN_DISABLED 13
#define ERROR_USER_REFUSED 14
#define ERROR_PASSWORD_EXPIRED 15
#define ERROR_PASSWORD_CANT_CHANGE 16
#define ERROR_HISTORY_CONFLICT 17
#define ERROR_TOO_SHORT 18
#define ERROR_TOO_RECENT 19
#define ERROR_BAD_PASSWORD_FILE 20
#define ERROR_BAD_SHADOW_FILE 21
#define ERROR_COMPUTING_LASTCHG_FIELD 22
#define ERROR_VERSION_NUMBER_MISMATCH 23
#define ERROR_PASSWORD_LENGTH_LESS 24
#define ERROR_UPDATE_PASSWORD_FILE 25

#define LAST_ERROR_NUMBER  25

#if 0
static char* szErrors[] = {	"success",
						  	"file not found",
						  	"lock violation",
						  	"cannot open file",
						  	"password not updated",
				 			"protocol error",
							"bad user name",
							"error decrypting  data",
							"version not supported",
							"bad password",
							"cannot make maps",
							"write fault",
							"no user entry",
							"user login disabled",
							"user refused",
							"password expired",
							"password cant change",
							"history conflict",
							"too short password",
							"too recent change of password",
							"bad password file",
							"bad shadow file",
							"computing lastchange field",
							"version number mismatch",
							"password length less than minimum needed",
							"failed to update password"
};
#endif

const char* getErrorString(int errorId);

DWORD setpassword(char *szUserName, char *szPassword, char *szPasswordFile, unsigned int fTemp,
						  unsigned int fCaseIgnore);
DWORD setshadowpassword(char *szUserName, char *szPassword, char *szShadowPasswordFile, 
                                unsigned int fTemp, unsigned int fCaseIgnore);

#endif /* PASSWORD_H */
