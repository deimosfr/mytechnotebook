/****************************************************************************/
/*                                                                          */
/*   SSO_Packet.h                                                           */
/*   Single Sign-On Packet containing classes                               */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/



#include <sys/types.h>

#include "../common/nttype.h"

#if 0
typedef unsigned long HCRYPTKEY;
#else
#define HCRYPTKEY DWORD
#endif


#if !defined( SSO_PACKET )
#define SSO_PACKET

#include "../common/crypto.h"


// version number
#include "../common/psyncver.h"

#define SUCCESS_RECEIVING 0
#define ERROR_RECEIVING  -1
#define ERROR_VERSION    -2

//
// Macros to add version number management
//

#define MAKE_VERSION_NUMBER( X, Y )  X << 16 + Y
#define MAJOR_VERSION_NUMBER( X )   X >> 16
#define MINOR_VERSION_NUMBER( X )   X & 0x0000FFFF


// sends some data on a socket

int
send_n( SOCKET& sock, void* buf, size_t bufsize );

//
// Generic <SSO_Packet> class
//




class SSO_Packet
{
 public:

    virtual int send_packet( SOCKET sock ) = 0;
    // Send a packet on <sock>, return 0 on success, -1 on failure.

    static SSO_Packet* recv_packet( SOCKET sock, unsigned short bServer, char* secret );
    // Receive a packet from <sock>, return a new packet on success, NULL on failure.

    void set_version_number( DWORD version_number );
    // Set the version number of this packet.

    DWORD get_version_number();
    // Returns the version number of this packet.

    DWORD get_message_size();
    // Returns the message size of this packet

    DWORD get_message_type();
    // Returns the message type of this packet

    virtual ~SSO_Packet();
    // Destructor

 protected:
    DWORD version_number_;
    // version number for this packet

    DWORD message_size_;
    // size of the body of this message

    DWORD message_type_;
    // type of this packet

    char* delete_buffer_;
    // pointer to data to be deleted when destructed

    SSO_Packet( DWORD message_type, DWORD message_size );
    // Constructor

    int send_packet_header( SOCKET sock );
    // Send the packet header (version number and message size) on <sock>,
    // return 0 on success, -1 on failure.

    virtual int recv_data( char*, size_t, BYTE*, char* , char*) = 0;
    // Parse body of message (message type and additional fields dependent
    // on packet type), return 0 on success, -1 on failure.

 private:
    static int receive_socket_data( SOCKET sock, DWORD&, DWORD&, char*& );
    // Receive the message header (version number and message size) and buffer of message body
    // (all fields of messsage body in one buffer), return 0 on success, -1 on failure.

    static int parse_message_type( SSO_Packet*&, char*, DWORD );
    // Parse the message type and create the proper type of packet,
    // return 0 on success, -1 on failure.

};





//
// Class for containing <SSO_Request_Packet>s
//






class SSO_Request_Packet : public SSO_Packet
{
public:
    SSO_Request_Packet();
    // Constructor

    ~SSO_Request_Packet();

    virtual int send_packet( SOCKET sock );
    // Send a packet on <sock>, return 0 on success, -1 on failure.

    void set_username( char* );
    // Set the username for this packet.

#ifndef _DOMAIN_
    void set_domain( char* );
    // Set the domain for this packet.
#endif

    void set_password( char* );
    // Set the cleartext password for this packet.

    char* get_username();
    // Returns the username for this packet.

#ifndef _DOMAIN_
    char* get_domain();
    // Returns the domain for this packet.
#endif

    char* get_password();
    // Returns the cleartext password for this packet.

    BOOL is_admin();
    // Whether admin is changing the password

private:
    void calculate_message_size();
    // Calcuate the message size for this packet

    virtual int recv_data( char*, size_t, BYTE*, char*, char* );
    // Parse body of message (message type and additional fields dependent
    // on packet type), return 0 on success, -1 on failure.
    
    char* decrypted_buffer_;

    char* username_;
    // Username for this packet.

#ifndef _DOMAIN_
    char* domain_;
    // Domain for this packet.
#endif

    char* password_;
    // Password for this packet

};





//
// Class for containing <SSO_Response_Packet>s
//





class SSO_Response_Packet : public SSO_Packet
{
 public:
    SSO_Response_Packet();
    // Constructor

    virtual int send_packet( SOCKET sock );
    // Send a packet on <sock>, return 0 on success, -1 on failure.


    void set_error( DWORD );
    // Set the error number for this packet.

    DWORD get_error();
    // Returns the error number for this packet.

    static char* conv_err_to_str( DWORD error_number);
    // Returns a buffer with a text conversion of the <error_number>
    // (similar to errno and perror()'s relationship)

 private:
    virtual int recv_data( char*, size_t, BYTE*, char*, char*);
    // Parse body of message (message type and additional fields dependent
    // on packet type), return 0 on success, -1 on failure.

    DWORD error_;
    // Error number for this packet.

};


#endif /* SSO_PACKET */


