/****************************************************************************/
/*                                                                          */
/*   passwdrc.h                                                             */
/*   Error messages                                                         */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _PASSWD_RC_H_
#define _PASSWD_RC_H_

//char* 	IDS_ERROR="Error: ";
const extern  char*   IDS_ERROR;
//char*	IDS_USER="User: ";
const extern  char*	IDS_USER;
const char*	IDS_TEMPORARY_PASSWORD_FILE_CREATION_ERROR="Temporary password file creation error";
const char* 	IDS_TEMPORARY_PASSWORD_FILE_OPENING_ERROR="Temporary password file opening error";
const char*	IDS_PASSWORD_FILE_OPENING_ERROR="Password file opening error";
//char*	IDS_BAD_PASSWORD_FILE="Bad password file";
const extern  char*	IDS_BAD_PASSWORD_FILE;
const char*	IDS_ERROR_WRITING_TEMPORARY_PASSWORD_FILE="Error when writing temporary password file";
const char*	IDS_ERROR_UNLINKING_OLD_PASSWORD_FILE="Error in unlinking old password file";
const char*	IDS_UNABLE_TO_READ_PASSWD_FILE="Unable to read password file";
const char*	IDS_BAD_SHADOW_FILE="Bad shadow file";
const char*	IDS_CANNOT_OPEN_ETC_SEC_PASS_FILE="Cannot open /etc/security/passwd file";
const char*	IDS_FOUND_USER="Found user";
const char*	IDS_ERROR_COMPUTING_LAST_CHG_FIELD="Error computing LastChg field";
const char*	IDS_ERROR_WRITING_PASSWD_FILE="Error when writing password file";
const char*	IDS_TEMPORARY_SHADOW_PASSWORD_FILE_CREATION_ERROR="Temporary shadow password file creation error";
const char* 	IDS_SHADOW_TEMPORARY_PASSWORD_FILE_OPENING_ERROR="Temporary shadow password file opening error";
const char*	IDS_ERROR_WRITING_SHADOW_TEMPORARY_PASSWORD_FILE="Error when writing shadow temporary password file";
const char*	IDS_ERROR_LINKING_SHADOW_FILE_TO_OLD_SHADOW_FILE="Error linking shadow file to old shadow file";
const char*	IDS_ERROR_RENAMING_TMP_SHADOW_FILE_TO_SHADOW_FILE="Error renaming tmp shadow file to shadow file";
const char*	IDS_LOGIN_DISABLED="Login disabled";

#endif // _PASSWD_RC_H_


