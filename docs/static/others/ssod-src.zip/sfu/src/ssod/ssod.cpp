/****************************************************************************/
/*                                                                          */
/*   ssod.cpp                                                               */
/*   Single Sign-On Daemon for Unix Platforms                               */
/*                                                                          */
/*   Copyright 1998-2000 Microsoft Corporation                              */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#define _CMA_NOWRAPPERS_ 

#include "ssodrc.h"
#include "ssod.h"
#include "../common/messages.h"
#include "../common/config.cpp"

extern "C" void printMessages(int msgType,const char* str);

//extern "C" int SyncPasswordThruPAM(const char *szUser, const char *szNewPassword);
int SyncPasswordThruPAM(const char *szUser, const char *szNewPassword);

// Handler for SIGTERM signal
// Note:  SIGTERM is sent by the system to notify all running processes that the system is going from
// multiuser to single-user mode.  This daemon should shutdown gracifully when that happens.

void
SIGTERM_handler( int )
{
     // send some dummy stuff to break the blocking io of accept

    send_n((SOCKET&)(Globals::instance() -> accept_sock_),0,0);

    Globals::instance() -> done_ = 1;

	printMessages(LOGERR,IDS_SSOD_KILLED_BY_TERM_SIGNAL);
 }


// Display usage instructions

void
usage()
{
    printMessages(COUT,IDS_SINGLE_SIGN_ON_DAEMON);
    cout << endl;

    printMessages(COUT,IDS_COPYRIGHT);
    cout << endl;

    printMessages(COUT,IDS_RIGHTS_RESERVED);
    cout << endl << endl;

    printMessages(COUT,IDS_USAGE);
    cout << endl << endl;

    printMessages(COUT,IDS_VERBOSE_MODE);
    cout << endl;
}


// Parse command line arguments.


int
parse_args( int argc, char** argv )
{    
    int verbose = 0;

    
    if ( argc ==2 && strcmp( argv[1], "-v" ) == 0 )
        verbose = 1;

	if ( (argc > 1) && ( 1 != verbose ) )
    {
        usage();
        return -1;
    }

    // set the globals structure to use temp. Till we go to refined version
    Globals::instance() -> use_temp_ = DEFAULT_USE_TEMP;

    // Get the configuration into globals
    if (getConfiguration(Globals::instance()) != SUCCESS)
    {
        // Error reading configuration file
        exit(1);
    }

    // Parse out NIS_update_make_

    if( Globals::instance() -> use_NIS_ )
    {
        Globals::instance() -> NIS_update_make_ = Globals::instance() -> NIS_update_path_
                                             + strlen( Globals::instance() -> NIS_update_path_ ) + 1;

    while( *( Globals::instance() -> NIS_update_make_ - 1 ) != '/' )
        Globals::instance() -> NIS_update_make_--;

    // Note the negative indexing!!

    Globals::instance() -> NIS_update_make_[-1] = '\0';

    }

    if( verbose )
    {
        cerr << "Port:  " <<  Globals::instance() ->dwPortNumber << endl;
        cerr << "Use shadow:  " << Globals::instance() -> use_shadow_ << endl;
        cerr << "Case Ignore Name:  " << Globals::instance() -> caseignore_name_ << endl;
        cerr << "Use temp:  " << Globals::instance() -> use_temp_ << endl;
        cerr << "Use NIS:  " << Globals::instance() -> use_NIS_ << endl;
        cerr << "File path:  " << Globals::instance() -> file_path_ << endl;
        cerr << "Temp path:  " <<  Globals::instance() -> temp_path_ << endl;
        cerr << "Pam_supported  " <<  Globals::instance() -> pam_supported_ << endl;
        
        if( Globals::instance() -> NIS_update_path_ != 0 )
        {
            cerr << "NIS update path:  " << Globals::instance() -> NIS_update_path_ << endl;
            cerr << "NIS update makefile:  " << Globals::instance() -> NIS_update_make_ << endl;
        }
    }

    return 0;
}


int
update_NIS()
{
	char szBuffer[MAX_BUFFER_SIZE + 1];
	
    switch( fork() )
    {
    case -1:          // error
        return -1;

    case 0:           // child
    
    close( Globals::instance() -> recv_sock_ );

    if ( chdir( Globals::instance() ->NIS_update_path_ ) )
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_COULD_NOT_CHDIR_TO,IDS_DIR,Globals::instance() ->NIS_update_path_);
    	printMessages(LOGERR,szBuffer);
    	
    }
    else  
    {
        int fd=0;                          
	    fd = open ("/dev/null", O_WRONLY);
	    dup2 (fd, 1);
	    dup2 (fd, 2);
        execlp( "make", "make", "-f", Globals::instance() -> NIS_update_make_, NULL );
    }

	printMessages(LOGERR,IDS_UNABLE_TO_RUN_NIS_UPDATE_SCRIPT); 
    _exit( 0 );

    default:          // parent
    CurrNISChilds++;
        return 0;

    }
}

void
request_handler( )
{
    SSO_Response_Packet response;
    DWORD error;

    char    szUser[MAXUSERNAMELENGTH];
    char	szBuffer[MAX_BUFFER_SIZE + 1];

    struct sigaction act, oact;
    sigset_t s;

    //Disabling the signal handler for  child process.

    sigemptyset(&s);
    act.sa_handler = SIG_DFL;
    act.sa_mask = s;
    //act.sa_flags = SA_RESTART;
    act.sa_flags = 0x10000000;
    sigaction( SIGCHLD, &act, &oact );

    // We are the server so the second parameter to recv_packet is set to 1.
    SSO_Request_Packet* packet =
    (SSO_Request_Packet*) SSO_Packet::recv_packet( Globals::instance() -> recv_sock_, 1, (char*)Globals::instance()->szEncryptionKey );
 
    if( packet == 0 )
    {
    	printMessages(LOGERR,IDS_UNABLE_TO_CREATE_PACKET_CONTAINER); 
        error = ERROR_PROTOCOL;
        goto RESPOND;
    }
    
    
    if( packet->get_message_type() != 0 )
    {
    	printMessages(LOGERR,IDS_RECEIVED_MESSAGE_OF_IMPROPER_TYPE); 
        delete packet;
        error = ERROR_PROTOCOL;
        goto RESPOND;
    }

    // check that this user is a user in the SYNC_USERS list
    if (syncThisUser(packet->get_username()) != ERROR_SUCCESS)
    {
    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_RESTRICTED_FROM_SYNCHRONIZING_PASSWORD,IDS_USER,packet->get_username());
    	printMessages(LOGERR,szBuffer);
    	
        delete packet;
        error = ERROR_USER_REFUSED;
        goto RESPOND;
    }
    strlcpy(szUser, packet->get_username(), sizeof(szUser));
    // Change the password and set the response error message with returned value

    // aix42  and hp10.2 dont have PAM support

    #ifdef solaris
    // we no longer know, who is initiating the password change admin or the user himself
    // so sending hardcoded FALSE as first parameter to conformToPassLength()
    if (!conformToPassLength(FALSE,strlen(packet->get_password())))
    {
        //printMessages(LOGERR,IDS_PASSWORD_LENGTH_LESSER_THAN_REQUIRED);

        delete packet;

        error = ERROR_PASSWORD_LENGTH_LESS;
        goto RESPOND;
    }
    #endif
    #ifndef aix42 
    
        error  = lookUpUnixUser(packet->get_username(), 
                              szUser, 
                              Globals::instance() -> file_path_,
                              Globals::instance() ->caseignore_name_);


        if( error != ERROR_SUCCESS && ! Globals::instance() -> pam_supported_) {
        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_SSOD_FAILED_TO_LOOK_UP_UNIX_USER,IDS_ERROR,getErrorString(error),
        		IDS_USER,packet->get_username());
			printMessages(LOGERR,szBuffer);
		    error = ERROR_NO_USER_ENTRY;
		    goto RESPOND;
             
        }
	#ifndef hp10

    
		error = SyncPasswordThruPAM( szUser, packet->get_password());
        
        
        
        if( error == ERROR_SUCCESS ) {
        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_SUCCESSFULLY_UPDATED_PASSWORD_VIA_PAM,IDS_USER,szUser);
        	printMessages(LOGINFO,szBuffer);
        }
        else
        { 
        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_FAILED_TO_UPDATE_PASSWORD,IDS_ERROR,getErrorString(error),
        		IDS_USER,szUser);
        	error = ERROR_PASSWORD_NOT_UPDATED;
			printMessages(LOGERR,szBuffer);
             
        }
        
        delete packet;
        goto UPDATE_NIS;
    
  
        
	#endif
	#endif

	    if( Globals::instance() -> use_shadow_ )
	    {
	        error = setshadowpassword( packet->get_username(),
	                   packet->get_password(),
	                   Globals::instance() -> file_path_,
	                   Globals::instance() -> use_temp_ ,
	                   Globals::instance() ->caseignore_name_);
	    }
	    else
	    {
	        error = setpassword( packet->get_username(),
	                 packet->get_password(),
	                 Globals::instance() -> file_path_,
	                 Globals::instance() -> use_temp_ ,
	                 Globals::instance() ->caseignore_name_);
	    }

	    if( error == ERROR_SUCCESS )
    	{
        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_SUCCESSFULLY_UPDATED_PASSWORD,IDS_USER,szUser);
        	printMessages(LOGINFO,szBuffer);
        }
        else
    	{
        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_FAILED_TO_UPDATE_PASSWORD,IDS_ERROR,getErrorString(error),
        		IDS_USER,szUser);
        	error = ERROR_UPDATE_PASSWORD_FILE;
			printMessages(LOGERR,szBuffer);
	    }

UPDATE_NIS:
    

    // Update NIS is necessary

    if( error == ERROR_SUCCESS )
    {
        if( Globals::instance() -> use_NIS_ )
        {
            if ( CurrNISChilds >= MAX_CONC_NIS_CHILDS )
            {
                printMessages(LOGWARN,IDS_TOO_MANY_NIS_CHILDREN_ARE_ACTIVE_CURRENTLY);
            }
            else if( update_NIS() == -1 )
            {
                // @@ Note:  This is not the proper error number 

                error = ERROR_CANNOT_MAKE_MAPS;
                printMessages(LOGERR,IDS_UNABLE_TO_UPDATE_NIS_PASSWORDS);
            }
        }
    }
    

    // delete dynamically created packet

    //delete packet;

RESPOND:

    response.set_error( error );
    response.set_version_number( MEPP_VERSION );

    if( response.send_packet( Globals::instance() -> recv_sock_ ) == -1 )
    {
    	printMessages(LOGERR,IDS_UNABLE_TO_COMPLETE_TRANSMISSION_OF_RESPONSE_PACKET); 
    }
    
    shutdown( Globals::instance() -> recv_sock_, 2 );
    close( Globals::instance() -> recv_sock_ );

}
    

void
reap_children( int sig )
{
    wait( 0 );
    if (Globals::instance() -> use_NIS_)
    {
        CurrNISChilds--;
    }
}

void
reread_config_file(int sig)
{
	printMessages(LOGINFO,IDS_RECEIVED_SIGNAL_TO_REREAD_CONF_FILE); 
    read_configuration = TRUE;
}

void
cleanup( void* sock )
{
//    shutdown( *(int*) sock, 2 );
    close( *(int*) sock );
}


/*--------------------------------------------------------------------*/


int
main( int argc, char** argv )
{
    int ret = FAILURE;
    int val = 0;
    
 	char szBuffer[MAX_BUFFER_SIZE + 1];

    // Parse command line arguments.
    
    if (getuid() != 0)
    {
	printMessages(COUT,IDS_SSOD_CAN_ONLY_BE_RUN_BY_ROOT);
        cout << endl;
        goto Error;
    }

    if( parse_args( argc, argv) == -1)
    {
        goto Error;
    }

    // Initialize system log for this program

    openlog( "ssod:", LOG_PID, LOG_DAEMON );

    // Ignore SIGPIPE - happens when client prematurely closes its end of the socket

   
    signal( SIGPIPE, SIG_IGN );

    // Initialize globals
    //gethostname(szHostname, sizeof(szHostname));

    // Create a socket.
    
    Globals::instance() -> accept_sock_ = socket( PF_INET, SOCK_STREAM, 0);
    
    if( Globals::instance() -> accept_sock_ == -1 )
    {
        printMessages(LOGERR,IDS_UNABLE_TO_CREATE_SOCKET);
        goto Error;
    }

    // Create the addressing structure.

    struct sockaddr_in in_addr;                             
	
    #ifdef aix42
    size_t addrLen;
    #else
    int addrLen;
    #endif

    memset( (void*) &in_addr, 0, sizeof in_addr );
    in_addr.sin_family = AF_INET;
    in_addr.sin_port = htons(Globals::instance() ->dwPortNumber);

    // Set the socket option to SO_REUSEADDR to FALSE so that any joe
    // app cannot bind to the same socket with specific IP address and get
    // our packet.

    val=0;
    if(setsockopt(Globals::instance() -> accept_sock_,
                SOL_SOCKET,
                SO_REUSEADDR,
                (char *)&val,
                sizeof(val)) !=0)
    {
        close( Globals::instance() -> accept_sock_ ); 
        cerr << "ssod:" << getpid() << ":Unable to turn off socket option SO_REUSEADDR" << endl;
        snprintf(szBuffer, sizeof(szBuffer),"%s %s %d",IDS_UNABLE_TO_SETSOCKOPT,IDS_PORT_NUMBER,Globals::instance() ->dwPortNumber);
        printMessages(LOGCRIT,szBuffer);
        goto Error;
    }
    
    // bind the socket to the requested port

    if( bind( Globals::instance() -> accept_sock_, (struct sockaddr *) &in_addr, sizeof in_addr ) == -1 )
    {
        close( Globals::instance() -> accept_sock_ ); 
        cerr << "ssod:" << getpid() << ":Unable to bind to specified port" << endl;
        snprintf(szBuffer, sizeof(szBuffer),"%s %s %d",IDS_UNABLE_TO_BIND,IDS_PORT_NUMBER,Globals::instance() ->dwPortNumber);
        printMessages(LOGCRIT,szBuffer);
        goto Error;
    }

    // setup the socket for listening

    if( listen( Globals::instance() -> accept_sock_, 25 ) == -1 )
    {
        close( Globals::instance() -> accept_sock_ );
        snprintf(szBuffer, sizeof(szBuffer),"%s %s %d",IDS_UNABLE_TO_LISTEN,IDS_PORT_NUMBER,Globals::instance() ->dwPortNumber);
        printMessages(LOGCRIT,szBuffer);
        goto Error;
    }
 

    // Initialize as a daemon process.

    daemon_init( 1, SIGTERM_handler, cleanup, (void*) &(Globals::instance()->accept_sock_) );

    sleep(1); //Allow parent to die


    // Reap child processes

    struct sigaction act, oact;
    sigset_t s;

    sigemptyset(&s);
    act.sa_handler = reap_children;
    act.sa_mask = s;
    //act.sa_flags = SA_RESTART;
    act.sa_flags = SA_NOCLDWAIT;
    sigaction( SIGCHLD, &act, &oact );
    
    sigemptyset(&s);
    act.sa_handler = reread_config_file;
    act.sa_mask = s;
    //act.sa_flags = SA_RESTART;
    act.sa_flags = 0x10000000;
    sigaction( SIGHUP, &act, &oact );
    

    // Loop until SIGTERM_Handler alerts us that we're done

    while( !(Globals::instance() -> done_) )
    {
        // Block until a request comes
        addrLen = sizeof(in_addr);

        #ifdef linux 
        Globals::instance() -> recv_sock_ = accept( Globals::instance() -> accept_sock_, 
                                                    (struct   sockaddr  *)&in_addr, 
                                                    (socklen_t *)&addrLen
                                                    );
        #else
        Globals::instance() -> recv_sock_ = accept( Globals::instance() -> accept_sock_, 
                                                    (struct   sockaddr  *)&in_addr, 
                                                    (socklen_t *)&addrLen
                                                    );
        #endif

        if( Globals::instance() -> done_ )
            break;


        // check to see if socket is valid

        if( Globals::instance() -> recv_sock_ == -1 )
        {
              // Check to see if accept failed due to SIGTERM signal

            if( Globals::instance() -> done_ )
            {
                break;
            }
        }
        else
        {
            int _childpid;
            char    szIpOfInHost[32];

            if (read_configuration)
            {
                if (getConfiguration(Globals::instance()) != SUCCESS)
                {
                    printMessages(LOGERR,IDS_ERROR_REREADING_CONFIGURATION_FILE);
                }
 #ifndef aix42
 #ifndef hp10
                else
                {
 					printMessages(LOGINFO,IDS_CONFIGURATION_FILE_REREAD_SUCCESSFULLY);

                }
 #endif
 #endif
                read_configuration = FALSE;
            }

            // check to see that we got this request from a trusted host


            strlcpy(szIpOfInHost,inet_ntoa(in_addr.sin_addr), sizeof(szIpOfInHost));

            if (!isTrustedHost(szIpOfInHost))
            {
            	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_NT_HOST_NOT_TRUSTED,IDS_NTHOST,szIpOfInHost);
            	printMessages(LOGERR,szBuffer);
                close( Globals::instance() -> recv_sock_ );
            }
            else
            {
#define FFR_NODAEMON 0
#if FFR_NODAEMON
                    request_handler();
                    close( Globals::instance() -> recv_sock_ );
#else
                if ( ( _childpid = fork() ) < 0 )
                {
                    printMessages(LOGERR,IDS_CANT_FORK_CHILD_PROCESS_TOHANDLE_PASSWORD_PROPAGATION);
                    close( Globals::instance() -> recv_sock_ );
                }
                else if ( _childpid == 0 )
                {
                    // child, we go ahead and handle the request.
                    
                    close( Globals::instance() -> accept_sock_ );
                    request_handler();
                    _exit(0);
                }
                else
                {
                    // parent, close the recv_sock.
                    close( Globals::instance() -> recv_sock_ );
                }
#endif
           } 
        }
    }

    shutdown( Globals::instance() -> accept_sock_, 2 );
    close( Globals::instance() -> accept_sock_ );

    closelog();


    ret = SUCCESS;
 Error:   

 	
    return ret;
}

BOOL
isTrustedHost(const char* pszAddrIP)
{

    BOOL fRet = FALSE;
    struct hostent *hp;
    char **ppszAddr;
    HOST_LIST *pHost = Globals::instance() ->pHostList;
    char    szIPOfInHost[32];
    char    szIPOfAllowedHost[32];

    strlcpy(szIPOfInHost,pszAddrIP, sizeof(szIPOfInHost));

    for ( ; pHost; pHost = pHost->pNext )
    {
        if (!strcmp(pHost->pszHostName, szIPOfInHost))
        {
            fRet = TRUE;
        }
        else
        {
            hp = gethostbyname(pHost->pszHostName);
            if (hp)
            {
                struct in_addr in;

                // The list hp->h_addr_list may contain more than one IP addr. Need to check for all.

                if ((ppszAddr = hp->h_addr_list) && (*ppszAddr != NULL) )
                {
                    (void) memcpy(&in.s_addr, *ppszAddr, sizeof (in.s_addr));

                    strlcpy(szIPOfAllowedHost,inet_ntoa(in), sizeof(szIPOfAllowedHost));
                    if (!strcmp(szIPOfAllowedHost,  szIPOfInHost))
                    {
                        fRet = TRUE;
                    }
                }
            }
        }
    }

    return fRet;
}



unsigned int    lookUpUnixUser(    const char *szNTUser,
                                    char* szUnixUser,
                                    const char *szPasswordFile, 
                                    unsigned int fCaseIgnore)
{
    unsigned int ret = ERROR_NO_USER_ENTRY;

    FILE     *fpPasswordFile;
    char     szLine[MAX_PW_ENTRY_LEN], // holds one line from /etc/passwd file 
            *szPtr = NULL;            // temp pointer
       
    if ( NULL == ( fpPasswordFile = fopen(szPasswordFile,"r")) )
    {
        printMessages(LOGERR,IDS_CANNOT_OPEN_PASSWORD_FILE);
        ret = ERROR_CANNOT_OPEN_FILE;
        goto Error;
    }

    // 
    // Parse the /etc/passwd file

    while ( fgets(szLine, sizeof(szLine), fpPasswordFile))
    {
        if (!strchr(szLine, '\n'))
        {
            printMessages(LOGERR,IDS_BAD_PASSWORD_FILE);
            ret = ERROR_BAD_PASSWORD_FILE;
            goto Done;
        }

        //
        // Skip blank and comment lines

        for (szPtr = szLine; *szPtr != '\n'; szPtr++)
            if (*szPtr != ' ' && *szPtr != '\t')
                break;

        if (!(szPtr = strchr(szLine, ':')))
        {
            printMessages(LOGERR,IDS_BAD_PASSWORD_FILE);
            ret = ERROR_BAD_PASSWORD_FILE;
            goto Done;
        }
        *szPtr = '\0';
        // username in NT and UNIX could differ in case.
        // use the config file directive to compare

        
        if (fCaseIgnore)
        {
 
            if (!strcasecmp(szLine, szNTUser))
            {
                // copy the UnixUser into szUnixUser
                strcpy(szUnixUser, szLine);
                ret = ERROR_SUCCESS;
                break;
            }
        }
        else
        {
            if (!strcmp(szLine, szNTUser))
            {
                // copy the UnixUser into szUnixUser
                strcpy(szUnixUser, szLine);
                ret = ERROR_SUCCESS;
                break;
            }
        }
    }

Done:
    fclose(fpPasswordFile);
    
Error:
    
    return ret;
}

const char*    getErrorString(int errId)
{
    if (errId < 0 || errId > LAST_ERROR_NUMBER)
        return "UNDEFINED ERROR";
    else
        return "ERROR";
    
}
