/****************************************************************************/
/*                                                                          */
/*   ssopktrc.h                                                             */
/*   Error messages                                                         */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _SSOPKT_RC_H_
#define _SSOPKT_RC_H_

const char*	IDS_ERROR_VERIFYING_DECRYPTED_MESSAGE="Error verifying decrypted message. Verify Encryption key. Check for network configuration errors.";
const char*   IDS_ERROR_VERSION_NUMBER_MISMATCH="Version number mismatch. Version number of server should be equal to that of client";
const char*   IDS_VERSION_ON_NT="Version on NT : ";
const char*   IDS_VERSION_ON_UNIX="Version on UNIX : ";
const char*   IDS_NT_MACHINE="NT machine : ";

#endif // _SSOPKT_RC_H_
