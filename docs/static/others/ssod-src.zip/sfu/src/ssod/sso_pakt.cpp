/****************************************************************************/
/*                                                                          */
/*   SSO_Packet.cpp                                                         */
/*   Single Sign-On Packet containing classes                               */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/


//#include <winsock.h>
//#include <wincrypt.h>
#include <string.h>
#include <strings.h>
#if 0
#include <iostream.h>
#else
#include <iostream>
using namespace std;
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <syslog.h>
#include <stdio.h>
#include "password.h"

//#ifdef UNIX
//#undef recv
//#undef send
//#endif

#include "ssopktrc.h"

#include "../common/crypto.h"
#include "sso_pakt.h"

#include "../common/messages.h"

extern "C" void printMessages(int msgType, const char* str);
void generate_hash_for_verification(BYTE *hashval, DES3TABLE *KeyTable, DWORD dwVersion,
                                    DWORD dwMsgLength, DWORD dwMsgType,
                                    const char* username, const char* password);


// Method to send data across a sock.  Handles short writes.

int
send_n( SOCKET& sock, void* buf, size_t bufsize )
{
    size_t bytes_written;
    ssize_t n;
    char* char_buf = (char*) buf;

    for( bytes_written = 0 ;
	 bytes_written < bufsize ;
	 bytes_written += n )
    {
        if( (n = send( sock, &char_buf[bytes_written], bufsize - bytes_written, 0 ) ) == -1 )
	    return -1;
    }

    return bytes_written;
}


// SSO_Packet

SSO_Packet::SSO_Packet( DWORD type, DWORD size )
  : delete_buffer_( 0 ),
    message_type_( type ),
    message_size_( size )
{
}

SSO_Packet*
SSO_Packet::recv_packet( SOCKET sock, unsigned short bServer, char *secret )
{
    SSO_Packet* new_packet;
    DWORD version_number, message_size;
    char* buf;
    BYTE r1[RANDOM_VALUE_LEN];
    int   retVal;

    if ( bServer )
    {
        generate_random_value( r1, RANDOM_VALUE_LEN );

        send( sock, (char *)r1, RANDOM_VALUE_LEN, 0);
    }

    if((retVal =  receive_socket_data( sock, version_number, message_size, buf )) < 0 )
    {
        if( buf )
	        delete [] buf;
        
    	return 0;
    }

    // Parse out the message type and create appropriate type to finish processing

    if( parse_message_type( new_packet, buf, version_number ) == -1 )
    {    
        if( new_packet )
	    delete new_packet;

        return 0;
    }

    // Call virtual function to finish parsing data properly

    if( new_packet->recv_data( buf, message_size, r1, NULL, secret ) )
    {

        delete new_packet;
        return 0;
    }

    return new_packet;

}



int
SSO_Packet::receive_socket_data( SOCKET sock, 
				 DWORD& version_number,
				 DWORD& message_size,
				 char*& buf )
{
    int nlen = 0;

    buf = NULL;

    nlen = recv( sock, (char*) &version_number, sizeof( version_number ), 0 );

    if ( nlen == 0 || nlen == -1 )
    {
        return ERROR_RECEIVING;
    }
    version_number = ntohl( version_number );

    nlen = recv( sock, (char*) &message_size, sizeof( message_size ), 0 );
    
    if ( nlen ==0 || nlen == -1 )
    {
        return ERROR_RECEIVING;
    }

    message_size = ntohl( message_size );

    if((message_size + 1) <= (2 * sizeof( DWORD ))) return ERROR_RECEIVING;
    buf = new char[message_size + 1 - 2 * sizeof( DWORD )];
    buf[message_size - 2 * sizeof( DWORD )] = '\0';

    if( recv( sock, (char*) buf, message_size - 2 * sizeof( DWORD), 0 ) == -1 )
    {
        return ERROR_RECEIVING;
    }

    return SUCCESS_RECEIVING;
}

int
SSO_Packet::parse_message_type( SSO_Packet*& packet, char* buf, DWORD version_number )
{
    // Parse out the message type and create appropriate type to finish processing

    if( ntohl(*(DWORD*) buf ) == 0 )
    {
        packet = new SSO_Request_Packet();
    }
    else
    {
        packet = new SSO_Response_Packet();
    }

    if( packet == 0 )
    {
	return -1;
    }

    // Remember version number and pointer to allocated buffer (so we can delete it
    // at time of destruction).

    packet->delete_buffer_ = buf;
    packet->version_number_ = htonl(version_number);

    return 0;

}


       
void
SSO_Packet::set_version_number( DWORD version_number )
{
    version_number_ = htonl( version_number );
}

DWORD
SSO_Packet::get_version_number()
{
    return ntohl( version_number_ );
}

DWORD
SSO_Packet::get_message_size()
{
    return ntohl( message_size_ );
}
    
DWORD
SSO_Packet::get_message_type()
{
    return ntohl(message_type_);
}

SSO_Packet::~SSO_Packet()
{
    if( delete_buffer_ )
    {
        delete [] delete_buffer_;
    }
}



//
// SSO_Request_Packet
//

SSO_Request_Packet::SSO_Request_Packet()
  : SSO_Packet( 0, htonl( sizeof( DWORD ) + 2 * sizeof( char* ) ) )
{
    decrypted_buffer_ = NULL;
}

SSO_Request_Packet::~SSO_Request_Packet()
{
    if ( decrypted_buffer_ )
        delete [] decrypted_buffer_;
}

int
SSO_Request_Packet::send_packet( SOCKET sock )
{
    size_t bufsize =  3 * sizeof( DWORD )
		      + strlen( username_ ) + 1
		      + strlen( password_ ) + 1;

    char* buf = new char[bufsize];

    char* current_position = buf;

    *(DWORD*)current_position = version_number_;
    current_position += sizeof( DWORD );
    *(DWORD*)current_position = message_size_;
    current_position += sizeof( DWORD );
    *(DWORD*)current_position = message_type_;
    current_position += sizeof( DWORD );
    strcpy( current_position, username_ );
    current_position += strlen( username_ ) + 1;
    strcpy( current_position, password_ );
    if( send_n( sock, buf, bufsize ) == -1 )
    {
        return -1;
    }
    
    delete [] buf;

    return 0;
}



void
SSO_Request_Packet::set_username( char* str )
{
    username_ = str;

    calculate_message_size();
}

#ifndef _DOMAIN_
void
SSO_Request_Packet::set_domain( char* str )
{
    domain_ = str;

    calculate_message_size();
}
#endif

void
SSO_Request_Packet::set_password( char* str )
{
    password_ = str;

    calculate_message_size();
}

void
SSO_Request_Packet::calculate_message_size()
{
    message_size_ = htonl( 3 * sizeof( DWORD ) +
                           strlen( username_ ) + 1 +
                           strlen( password_ ) + 1 );
}


char*
SSO_Request_Packet::get_username()
{
    return username_;
}

#ifndef _DOMAIN_
char*
SSO_Request_Packet::get_domain()
{
    return domain_;
}
#endif

char*
SSO_Request_Packet::get_password()
{
    return password_;
}

// we no longer know, who is initiating the password change, admin or the user himself
// so this funtion is not being called anywhere in the code
BOOL
SSO_Request_Packet::is_admin()
{
    return FALSE;
}

int
SSO_Request_Packet::recv_data( char* buf, size_t message_size,  BYTE *r1, char *peer_name, char *secret )
{
    BYTE ourhash[24];          // 3 * DES_BLOCKLEN
    DES3TABLE KeyTable;
    size_t ulSkipSize = 0;

    message_size_ = htonl( message_size );
    ulSkipSize =  3 * sizeof( DWORD );
    if(message_size <= ulSkipSize) return ERROR_DECRYPTING;
    size_t ulDecryptedBufSize = message_size - ulSkipSize;
    
    DWORD message_size_check = 0;

    decrypted_buffer_ = decrypt_received_buffer(buf + sizeof(DWORD), ulDecryptedBufSize, r1, peer_name, secret, &KeyTable );

    username_ = decrypted_buffer_;

    message_size_check += (strlen( username_ ) + 1);

#ifdef _DOMAIN_

    domain_ = &decrypted_buffer_[message_size_check];

    message_size_check += (strlen( domain_ ) + 1);

#endif

    password_ = &decrypted_buffer_[message_size_check];

    message_size_check += (strlen( password_ ) + 1);
    
    // need to use the network order for the message integrity check.
    for ( size_t i = 0 ;  i < sizeof(DES3TABLE)/sizeof(DWORD); i++ )
        ((DWORD *)&KeyTable)[i] = htonl(((DWORD *)&KeyTable)[i]);

    generate_hash_for_verification(ourhash, &KeyTable, version_number_, message_size_, message_type_, username_ , password_);

    // Only first 20 bytes are sent along with the message

#ifndef NO_ENCRYPTION
    if (bcmp((BYTE *) ourhash, (BYTE *) &decrypted_buffer_[message_size_check], 20) != 0)
    {
        // Error
        printMessages(LOGERR,IDS_ERROR_VERIFYING_DECRYPTED_MESSAGE);

        return ERROR_DECRYPTING;
    }
#endif

    return 0;
}




//
// SSO_Response_Packet
//



SSO_Response_Packet::SSO_Response_Packet()
  : SSO_Packet( 1, htonl( 4 * sizeof( DWORD ) ) )
{
}

int
SSO_Response_Packet::send_packet( SOCKET sock )
{
    char buf[4*sizeof( DWORD ) ];

    *(DWORD*)buf = version_number_;
    *(DWORD*)(buf+sizeof( DWORD ) ) = message_size_;
    *(DWORD*)(buf+2*sizeof( DWORD ) ) = message_type_;
    *(DWORD*)(buf+3*sizeof( DWORD ) ) = error_;
        

    if( send_n( sock, buf, (4*sizeof( DWORD ) )) == -1 )
    {
        return -1;
    }

    return 0;

}



void
SSO_Response_Packet::set_error( DWORD error )
{
    error_ = htonl( error );
}

DWORD
SSO_Response_Packet::get_error()
{
    return ntohl( error_ );
}


int
SSO_Response_Packet::recv_data( char* buf, size_t message_size,  BYTE *r1, char *peer_name, char* secret )
{
    message_size_ = htonl( message_size );

    if( message_size != (4 * sizeof( DWORD ) ) )
        return -1;

    error_ = *(DWORD*) &buf[sizeof( DWORD )];
    
    return 0;
}


char*
SSO_Response_Packet::conv_err_to_str( DWORD error )
{
    // @@ Note: this is only a shell for now.

    char* buf = new char[15];
    sprintf( buf, "%u", error );
    return buf;
}


