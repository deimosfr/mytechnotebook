/****************************************************************************/
/*                                                                          */
/*   daemon_func.cpp                                                        */
/*   Generic function to create daemon process                              */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <signal.h>
#include <sys/param.h>
#include <errno.h>

#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>

//extern int errno;

#if BSD                    // BSD
#include <sys/file.h>
#include <sys/ioctl.h>
#endif


#if 0
#include <iostream.h>
#else
#include <iostream>
using namespace std;
#endif

#define MAX_FILES 64

#define err_sys( X )      // cerr << X << endl

#define FFR_NODAEMON 0
#define FFR_NOCLOSE  0

// Detach a daemon process from login session context.

void
daemon_init( int ignore_sigcld, void (*SIGTERM_handler)(int), void (*cleanup_func)(void*), void* arg )
{
    int fd;
    pid_t childpid;

    // if we are started by init, there is no need to detach the process.

    if(FFR_NODAEMON)
      return;

    if( getppid() == 1)
        goto FINISH;

    // Ignore the terminal stop signals

#ifdef SIGTTOU
    signal( SIGTTOU, SIG_IGN );
#endif

#ifdef SIGTTIN
    signal( SIGTTIN, SIG_IGN );
#endif

#ifdef SIGTSTP
    signal( SIGTSTP, SIG_IGN );
#endif


    // If not started in the background, fork and let the parent exit.

    if( (childpid = fork() ) < 0 )
    {
        err_sys( "Can't fork first child" );
    }
    else if( childpid > 0 )
    {	
        cleanup_func( arg );	
        exit( 0 );                             // parent
    }

 
    // Now in first child process

    // Disassociate from controlling terminal and process group.
    // Ensure the process can't reacquire a new controlling terminal.

#ifdef BSD              // BSD

    if( setpgrp( 0, getpid() ) == -1 )
    {
        err_sys( "Can't change process group" );
    }

    if( (fd = open("dev/tty", O_RDWR) ) >= 0 )
    {
        ioctl( fd, TIOCNOTTY, (char*) NULL );     // lose controlling tty
	close( fd );
    }

#else                   // SYSTEM V
  
    if( setpgrp() == -1 )
    {
        err_sys( "Can't change process group" );
    }
    
    signal( SIGHUP, SIG_IGN );                   // immune from pgrp leader death

#endif

FINISH:
#if FFR_NOCLOSE

    // Close any open files descriptors
    
	
    for( fd = 0; fd < 3 ; fd++ )
    {
        if( fd != *(int*) arg )
	    {
	        close( fd );
	    }
    }
        
    errno = 0;
    
    // Clear any inherited file mode creation mask

    umask( 0 );

    // See if caller isn't interested in the exit status of children

    if( ignore_sigcld )
    {
#ifdef BSD                            // BSD
        
        int sig_child();

	signal( SIGCLD, sig_child);

#else                                 // SYSTEM V

	//signal( SIGCLD, SIG_IGN);
	signal(SIGCLD, SIG_DFL);
#endif
    }

    // Set the handler for SIGTERM

    signal( SIGTERM, SIGTERM_handler );
#endif
    return;
}


