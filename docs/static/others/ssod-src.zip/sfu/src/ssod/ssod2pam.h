
/****************************************************************************/
/*                                                                          */
/*   ssod2pam.h                                                             */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _SSOD2PAM_H_
#define _SSOD2PAM_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include <security/pam_appl.h>
#include <security/pam_modules.h>


#ifdef LINUX
int PamConv( int cMsg, const struct pam_message **ppMessage,
		struct pam_response **ppResponse, void* pAppData);
#else
int PamConv( int cMsg, struct pam_message **ppMessage,
		struct pam_response **ppResponse, void* pAppData);
#endif
int SyncPasswordThruPAM(const char*	szUser, const char* szNewPassword);	

#define BAIL_ON_PAM_FAILURE(p) if ((p) != PAM_SUCCESS) {  goto Error; }
       

#ifdef __cplusplus
}
#endif

#endif

