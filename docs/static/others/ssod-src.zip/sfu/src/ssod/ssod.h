/****************************************************************************/
/*                                                                          */
/*   ssod.h                                                                 */
/*   Single Sign-On Daemon for Unix Platforms                               */
/*                                                                          */
/*   Copyright 1998-2000 Microsoft Corporation                              */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _SSOD_H_
#define _SSOD_H_

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <ctype.h>
#include <strings.h>

#ifndef hp10
#include <dlfcn.h>
#endif

#include <signal.h>

#include <sys/wait.h>
#include <sys/socket.h>
#if 0
#include <iostream.h>
#else
#include <iostream>
using namespace std;
#endif
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <string.h>
//#include <pthread.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netdb.h>

#include "dimonfnc.h"
#include "sso_pakt.h"
#include "password.h"

#define  SSOD_DEF

// version number

#include "../common/psyncver.h"
#include "../common/nttype.h"

// AIX  4.2 has no pam support
#ifndef aix42
#ifndef hp10
#include "ssod2pam.h"

#define  	SSOD2PAM_DLL  "/usr/bin/ssod2pam.so.1"
#define 	PAM_SUCCESS 0

typedef   	int (*PFSSOD2PAM)(char*, char*) ;

#endif
#endif



//-------------------- default values  and constants -------------------------------

#define DEFAULT_PORT  				 6677       // Default port for daemon to listen on.
#define DEFAULT_USE_SHADOW 			 0          // use passwd file
#define DEFAULT_CASE_IGNORE_NAME 1           // case insensitive compare with NT user name

#define DEFAULT_TEMP_PATH 			"/tmp/ptmp"   // Full path to dafault temp file location
#define DEFAULT_USE_NIS 			0            // Update local passwords
#define DEFAULT_PAM_SUPPORTED  	 1				 // ssod updates the /etc/password file directly, not thru PAM
#define DEFAULT_USE_TEMP			0            // what is the usage of this ?


# define SSOD_CONFIG_FILE		 "/etc/sso.conf"
# define SSOD_PASSLENGTH_FILE "/etc/default/passwd"
# define SSOD_CFG_ERROR_MSG   "Error in config file /etc/sso.conf: "

# define MAXLINELENGTH    		280 // PATH_MAX=255 + 25 app
# define MAXPATHLENGTH    		256 // Including null
# define MAX_CONC_NIS_CHILDS  8

# define MAX_BUFFER_SIZE        512 // Including null
# define MAXSECRETLEN           22  // including null
# define MINSECRETLEN           16  // NOT including null
#define  MAXUSERNAMELENGTH     256  // including NULL

#ifndef MAXHOSTNAMELEN
# define MAXHOSTNAMELEN         65  //including null
#endif

# define SUCCESS  0
# define FAILURE  -1
# define ERROR    -1


// These bit flags are used for the mandatory set of options from conf file 
# define FILE_PATH_SET                0x0001u
# define TEMP_FILE_PATH_SET           0x0002u
# define ENCRYPT_KEY_SET              0x0004u
# define NIS_UPDATE_PATH_SET          0x0008u
# define SYNC_USERS_SET               0x0010u
# define SYNC_HOSTS_SET               0x0020u
//# define USE_SHADOW_SET              0x00040u
//# define USE_NIS_SET                   0x00080u
//# define PORT_NUMBER_SET              0x0100u
//# define CASE_IGNORE_NAME_SET        0x00200u

// define ALL_SET which should indicate that all are set
// excluding NIS_UPDATE_PATH_SET which is not mandatory
# define ALL_SET (FILE_PATH_SET | TEMP_FILE_PATH_SET | ENCRYPT_KEY_SET | SYNC_USERS_SET | SYNC_HOSTS_SET) 

//-------------------- global variables -------------------------------

unsigned int read_configuration = FALSE;

int  CurrNISChilds = 0;

char szHostname[256];


typedef struct _host_list
{
    char*                   pszHostName;
    unsigned char*          pszEncryptionKey;
    DWORD                   dwPort;
    struct _host_list*      pNext;
} HOST_LIST;

typedef struct _sync_user_list
{
    char*                   pszSyncObjName;
    BOOL                    fSync;
    struct _sync_user_list* pNext;
} SYNC_OBJ_LIST;

class Globals
//  TITLE
//    Singleton class to hold all globals needed in this program.
{
public:
    static Globals* instance();      // singleton

    int 	accept_sock_;
    int 	recv_sock_;

    int 	done_;
    int 	use_shadow_;
    int 	use_temp_;
    int 	caseignore_name_;
    int 	use_NIS_;
    int	 	pam_supported_;
    char* 	file_path_;
    char* 	temp_path_;
    char* 	NIS_update_path_;
    char* 	NIS_update_make_;
    
    
#ifndef aix42
#ifndef hp10
	PFSSOD2PAM pfSsod2Pam_;
    void*	lib_handle_ssod2pam_;
#endif
#endif

    HOST_LIST*      pHostList;
    SYNC_OBJ_LIST*  pSyncObjList;

    unsigned char szEncryptionKey[MAXSECRETLEN];
    unsigned int dwPortNumber;

private:
    Globals();

    static Globals* instance_;
};

Globals* Globals::instance_ = 0;

Globals::Globals()
  : done_( 0 )
{
}

Globals*
Globals::instance()
{
    if( instance_ == 0 )
    {
        instance_ = new Globals();

        instance_->pHostList = NULL;
        instance_->pSyncObjList = NULL;
        instance_->file_path_ = NULL;
        instance_->temp_path_ = NULL;
        instance_->NIS_update_path_ = NULL;
        instance_->NIS_update_make_ = NULL;
        
#ifndef aix42
#ifndef hp10
        instance_->pfSsod2Pam_ = NULL;
        instance_->lib_handle_ssod2pam_ = NULL;
#endif
#endif
}

    return instance_;
}

//-------------------- local functions -------------------------------
void SIGTERM_handler( int );
void usage();
int  parse_args( int argc, char** argv );
int  update_NIS();
void request_handler( );
void reap_children( int sig );
void reread_config_file(int sig);
void cleanup( void* sock );
BOOL isTrustedHost(const char* pszAddrIP);

#ifndef aix42
#ifndef hp10

BOOL  loadSsod2PamDll (void** phSSOD2PAM, PFSSOD2PAM* ppfSsod2Pam );

#endif
#endif

unsigned int	lookUpUnixUser(	const char *szNTUser,
									char* szUnixUser,
									const char *szPasswordFile, 
									unsigned int fCaseIgnore);
//-------------------- end local functions -------------------------------

#endif

