/****************************************************************************/
/*                                                                          */
/*   ssod2pam.cpp                                                           */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#include "sso2pmrc.h"
#include "ssod2pam.h"
#include "../common/messages.h"

extern "C" size_t strlcpy(char *dst, const char *src, size_t siz);
extern "C" void printMessages(int msgType,const char* str);

#define 	PAM_SSOD_MAX_USER_LEN 8 + 1
#define  	PAM_SSOD_MAX_PWD_LEN 8 + 1 

/* Static variables used to communicate between the conversation function
* and the server_login function
*/


#define FFR_DONTUSEGLOBAL 1
#if FFR_DONTUSEGLOBAL
// FFR
typedef struct {	
	const char *szUser;
	const char *szPwd;
	} UserData;
#else
static char g_szUser[PAM_SSOD_MAX_USER_LEN];
static char g_szPassword[PAM_SSOD_MAX_PWD_LEN];
#endif

// PAM conversation function

#ifdef LINUX
int PamConv (int cMsg,
				const struct pam_message **ppMessage,
				struct pam_response **ppResponse,
				void *pAppdata) 
#else
int PamConv (int cMsg,
				struct pam_message **ppMessage,
				struct pam_response **ppResponse,
				void *pAppdata) 
#endif
{
	int replies = 0;
	struct pam_response *reply = NULL;
#if FFR_DONTUSEGLOBAL
        UserData *ud=(UserData *)pAppdata;
#endif

	reply = (struct pam_response*) malloc(sizeof(struct pam_response) * cMsg);

	if (!reply) 
		return PAM_CONV_ERR;

	for (replies = 0; replies < cMsg; replies++) 
	{
		switch (ppMessage[replies]->msg_style) 
		{
			case PAM_PROMPT_ECHO_ON:
				reply[replies].resp_retcode = PAM_SUCCESS;
#if FFR_DONTUSEGLOBAL
				reply[replies].resp=strdup(ud->szPwd);
#else
				reply[replies].resp =  (char*) malloc(strlen(g_szPassword)+1);
				
				if (reply[replies].resp)
					strcpy(reply[replies].resp, g_szPassword);
#endif				
				   /* PAM frees resp */
				 break;
			case PAM_PROMPT_ECHO_OFF:
				reply[replies].resp_retcode = PAM_SUCCESS;
#if FFR_DONTUSEGLOBAL
				reply[replies].resp = strdup(ud->szPwd);
#else
				reply[replies].resp =  (char*) malloc(strlen(g_szPassword)+1);
				
				if (reply[replies].resp)
					strcpy(reply[replies].resp, g_szPassword);
#endif				
				   /* PAM frees resp */
				 break;
			case PAM_TEXT_INFO:
			 	/* fall through */
			case PAM_ERROR_MSG:
				/* ignore it, but pam still wants a NULL response... */
				reply[replies].resp_retcode = PAM_SUCCESS;
				reply[replies].resp = NULL;
			 	break;
			default:
				/* Must be an error of some sort... */
				free (reply);
				return PAM_CONV_ERR;
		}
	}
	*ppResponse = reply;
	
	return PAM_SUCCESS;
}

static struct pam_conv conv = 
{
	PamConv,
	NULL
};

 /* A dummy function
  */
  
 void CleanUp (pam_handle_t* pamh, void* data_name, int pam_status)
 {
 }

 /* Server log in
  * Accepts: user name string
  *	    password string
  * Returns: PAM_SUCCESS if password validated, other PAM error code otherwise
  */ 
  
 int SyncPasswordThruPAM(const char *szUser, const char *szNewPassword)
 {
	pam_handle_t *pamh=NULL;
	char  szSsodCalledPam[6];
	int ret = PAM_SYSTEM_ERR;
	int ret1 = PAM_SYSTEM_ERR;
	szSsodCalledPam[0]=0;

	printMessages(LOGDEBUG,IDS_SSOD_CHANGING_PASSWORD_THRU_PAM);
	
	if ( !(szUser  && strlen(szUser) && szNewPassword) )
		BAIL_ON_PAM_FAILURE(ret = PAM_USER_UNKNOWN);

	// copy the use and password info to static file global variable for 
	// access by fnPamConv function called from PAM modules.
	
#if FFR_DONTUSEGLOBAL
        UserData ud;
	ud.szUser=szUser;
	ud.szPwd=szNewPassword;
	conv.appdata_ptr=&ud;
#else
	strlcpy(g_szUser, szUser, sizeof(g_szUser));
	strlcpy(g_szPassword, szNewPassword, sizeof(g_szPassword));
#endif
	 
	// initialize PAM service 


    #ifdef solaris
    ret = pam_start("passwd", szUser, &conv, &pamh);
    BAIL_ON_PAM_FAILURE(ret);

	//#else 
	//#ifdef hp11 
    //ret = pam_start("ssod1", szUser, &conv, &pamh);
    //BAIL_ON_PAM_FAILURE(ret);

    #else 
    ret = pam_start("ssod", szUser, &conv, &pamh);
    //#endif
    #endif

    #ifndef LINUX
    // since Red Hat 7.1+ does not support pam_set_item(), so excluding the following code. (only for Linux). Linux does not need call to this
    // function to set the password. It is taken care by conversation function.
    
	// authentication os not required as root is trying to change password
	
	ret = pam_acct_mgmt(pamh, 0);
	BAIL_ON_PAM_FAILURE(ret);
 
	
	//set the new password
	ret = pam_set_item(pamh, PAM_AUTHTOK, szNewPassword);
	BAIL_ON_PAM_FAILURE(ret);

	// Inorder to break the loop of PAM_SSO asking NT to change password again,
	// We will set an environment variable SSOD_PASSWD_CHRQ (password change request from ssod)
	// i.e SSOD_PSSWD_CHRQ=TRUE
	// IN PAM_SSO module, we will check this value for this env variable and if found,
	// we will not send password sync request to NT
	// Since linux has different pam conf. file, for ssod and password, following call to pam_set_data is not req.

	
	strcpy(szSsodCalledPam,"TRUE");
	ret = pam_set_data(pamh, "SSOD_PASSWD_CHRQ", (void *)szSsodCalledPam, CleanUp);
	BAIL_ON_PAM_FAILURE(ret);

	ret = pam_setcred(pamh, PAM_REFRESH_CRED); 
    #endif // LINUX

	// now change password
	ret = pam_chauthtok(pamh, 0);   
	//ret = pam_chauthtok(pamh, PAM_SILENT);   

Error:

    #ifndef LINUX	
    // Since linux has different pam conf. file, for ssod and password, following call to pam_set_data is not req.
	strcpy(szSsodCalledPam,"FALSE");
	ret1 = pam_set_data(pamh, "SSOD_PASSWD_CHRQ", (void *)szSsodCalledPam, CleanUp);
    #endif // LINUX	
    
	if (pamh) 
		ret1 = pam_end(pamh, ret1) ; 
 	
	
	 pamh = NULL;
	 
    if (ret1 != PAM_SUCCESS)
 		ret = ret1; 
 	
	return  ret;
 }

