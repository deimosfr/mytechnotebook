// Crypto headers
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <strings.h>
#include "../common/crypto.h"

#include <fcntl.h>
#include <stdlib.h>

extern char* szHostname;

#ifdef NO_ENCRYPTION

typedef struct _MsgHeader {
    DWORD   dwVersion;
    DWORD   dwMsgLen;
} MsgHeader;

typedef struct _MsgData {
    MsgHeader  Header;
    DWORD   dwMsgType;  // 0 - Request; 1 - Response
    //BYTE    databytes[ UserName.Length + Domain.Length + Password.Length];
} MsgData;

#endif

void generate_random_value( BYTE *r1, size_t len)
{

FILE * fp = fopen ("/dev/urandom" , "rb" );

if ( NULL == fp )
        {
                srandom ( time (NULL) );

                for ( size_t count = 0 ; count < len ; count += sizeof(DWORD), r1 = r1 + sizeof(DWORD) )
                        *(DWORD *)r1 = (*(DWORD *)r1)*43 + time(NULL) + (random()>>16);
        }
else
        {
                // read random number from the urandom device

                for ( size_t count = 0 ; count < len ; count += sizeof(DWORD) , r1 = r1 + sizeof(DWORD) )
                        fread ( (DWORD *) r1 , sizeof (DWORD )  , 1 , fp);
        }
}


void make_hash(BYTE *hashval, BYTE *r1, BYTE *r2, DWORD ourIP, DWORD peerIP, const char* secret)
{
    SHA1_CTX  hash_ctx;

    SHA1Init(&hash_ctx);

    SHA1Update(&hash_ctx, r1, RANDOM_VALUE_LEN);
    SHA1Update(&hash_ctx, (const BYTE *)secret, strlen(secret));
    SHA1Update(&hash_ctx, r2, RANDOM_VALUE_LEN);
    SHA1Update(&hash_ctx, (const BYTE *)&peerIP, sizeof(DWORD));
    SHA1Update(&hash_ctx, (const BYTE *)&ourIP, sizeof(DWORD));

    SHA1Final(hashval, &hash_ctx);
}

// the hash value is not long enough so we must expand it
void extend_hash_forkey(BYTE *hashval)
{
    SHA1_CTX h1, h2;
    BYTE rgbBuff1[64], rgbBuff2[64];

    // set up the two buffers to be hashed
    SHA1Init(&h1);
    SHA1Init(&h2);

    memset(rgbBuff1, 0x36, sizeof(rgbBuff1));
    memset(rgbBuff2, 0x5C, sizeof(rgbBuff2));
    for (int i=0;i<20;i++)
    {
        rgbBuff1[i] ^= hashval[i];
        rgbBuff2[i] ^= hashval[i];
    }

    // hash the two buffers
    SHA1Update(&h1, rgbBuff1, sizeof(rgbBuff1));
    SHA1Update(&h2, rgbBuff2, sizeof(rgbBuff2));

    // finish the hashes and copy them into BaseVal
    memset(rgbBuff1, 0, sizeof(rgbBuff1));
    SHA1Final(rgbBuff1, &h1);

    memset(rgbBuff2, 0, sizeof(rgbBuff2));
    SHA1Final(rgbBuff2, &h2);

    // A_SHA gives only a 20 byte buffer.
    memcpy(hashval, rgbBuff1, 20);
    memcpy(hashval+20, rgbBuff2, 4);
}

// The hash value function that is used and sent along with the data
void generate_hash_for_verification(BYTE *hashval, DES3TABLE *KeyTable, DWORD dwVersion, 
                                    DWORD dwMsgLength, DWORD dwMsgType,
                                    const char* username, const char* password)
{
    SHA1_CTX hash_ctx;

    SHA1Init(&hash_ctx);
    SHA1Update(&hash_ctx, (BYTE *) KeyTable, sizeof(DES3TABLE));
    SHA1Update(&hash_ctx, (BYTE *) &dwVersion, sizeof(DWORD));
    SHA1Update(&hash_ctx, (BYTE *) &dwMsgLength, sizeof(DWORD));
    SHA1Update(&hash_ctx, (BYTE *) &dwMsgType, sizeof(DWORD));
    SHA1Update(&hash_ctx, (BYTE *) username, strlen(username));
    SHA1Update(&hash_ctx, (BYTE *) password, strlen(password));

    SHA1Final(hashval, &hash_ctx);
}

#ifdef NO_ENCRYPTION

char*
decrypt_received_buffer( const char* encrypted_buffer, size_t buf_size, BYTE * r1, const char *peer_name, const char* secret, DES3TABLE *KeyTable)
{
    return (encrypted_buffer);
}

#else

char*
decrypt_received_buffer( const char* encrypted_buffer, size_t buf_size, BYTE * r1, const char *peer_name, const char* secret, DES3TABLE *KeyTable
)
{
    BYTE KeyIn[3 * DES_BLOCKLEN];
    if(0 == buf_size) return (char*)0;
    char *decrypted_buffer = new char[ buf_size ];
    if(NULL == decrypted_buffer) return (char*)0;

    make_hash(KeyIn, r1, (BYTE *)encrypted_buffer, 0, 0, secret);
    extend_hash_forkey(KeyIn);

    // skip past the R2 value.
    encrypted_buffer += RANDOM_VALUE_LEN;
    if(buf_size < RANDOM_VALUE_LEN) buf_size = 0;
    else
	    buf_size -= RANDOM_VALUE_LEN;

    tripledes3key( KeyTable, KeyIn );

    for ( size_t count = 0 ; count < buf_size ; count += 8 )
    {
        BYTE *pOut = (BYTE *)decrypted_buffer + count;
        BYTE *pIn = (BYTE *)encrypted_buffer + count;
        tripledes(pOut, pIn, KeyTable, DECRYPT);
    }

    return decrypted_buffer;
}

#endif
