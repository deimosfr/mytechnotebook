
/****************************************************************************/
/*                                                                          */
/*   sso2pmrc.hc                                                            */
/*   Error messages                                                         */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _SSO2PM_RC_H_
#define _SSO2PM_RC_H_

const char*	IDS_SSOD_CHANGING_PASSWORD_THRU_PAM="Ssod changing password thru PAM";

#endif // _SSO2PM_RC_H_
