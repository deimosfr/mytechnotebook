/****************************************************************************/
/*                                                                          */
/*   crptpcrc.h                                                             */
/*                                                                          */
/*   Error messages                                                         */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _CRPTPC_RC_H_
#define _CRPTPC_RC_H_

char* 	IDS_UNKNOWN_HOST="Unknown host";
char*	IDS_HOST="Host: ";
char*	IDS_ERROR_CONNECTING_HOST="Error in connecting to host";
char* 	IDS_ERROR="Error: ";
char*	IDS_ERROR_RECEIVING_NT_HOST_DATA="Error receiving NT host data";
char*	IDS_ERROR_SENDING_ENCODED_BUFFER="Error sending encoded buffer";
char*	IDS_USER_UNKNOWN_ON_NT_HOST="User unknown on NT host";
//char*	IDS_USER="User: ";
extern  char*	IDS_USER;
char*	IDS_WINDOWS_PASSWORD_MISMATCH="Windows password mismatch";
char*	IDS_WINDOWS_PASSWORD_DOESNT_CONFORM_TO_PASSWORD_POLICY="Windows password doesn\'t conform to password po";
char*	IDS_WINDOWS_PASSWORD_IS_SET_TO_CANT_CHANGE="Windows password is set to can\'t change";
char*	IDS_WINDOWS_PASSWORD_HAS_EXPIRED="Windows password has expire";
char*	IDS_SYNCING_PASSWORD_ON_WINDOWS_DISALLOWED="Syncing password for windows disallowed";
char*	IDS_PACKET_DECRYPT_ERROR="Error verifying decrypted message, Verify encryption key and check for network configuration errors.";
char*	IDS_PASSWORD_UPDATE_IS_DISABLED="Password update is disabled";
char*	IDS_PASSWORD_FAILED="Password update failed";
char*	IDS_MEMORY_ALLOCATION_ERROR_FOR_ENCRYPT_DATA="Memory allocation error for encrypt data";
char*   IDS_ERROR_VERSION_NUMBER_MISMATCH="Version number mismatch. Version number of server should be equal to that of client";
char*   IDS_VERSION_ON_NT="Version on NT : ";
char*   IDS_VERSION_ON_UNIX="Version on UNIX : ";
char*   IDS_NT_MACHINE="NT machine : ";

#endif // _CRPTPC_RC_H_
