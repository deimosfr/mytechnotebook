/****************************************************************************/
/*                                                                          */
/*   pswdsync.h                                                             */
/*                                                                          */
/*   Error codes return from NT while changing a user's password            */
/*                                                                          */
/*   Copyright 1998 Microsoft Corporation                                   */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/



#if !defined( PSWDSYNC_H )
#define PSWDSYNC_H

#define SSO_ERROR_SUCCESS        0
#define SSO_ERROR_FILE_NOT_FOUND 1
#define SSO_ERROR_LOCK_VIOLATION 2
#define SSO_ERROR_CANNOT_OPEN_FILE 3
#define SSO_ERROR_PASSWORD_NOT_UPDATED 4
#define SSO_ERROR_PROTOCOL 5
#define SSO_ERROR_BAD_USER_NAME 6
#define SSO_ERROR_DECRYPTING 7
#define SSO_ERROR_VERSION_NOT_SUPPORTED 8
#define SSO_ERROR_BAD_PASSWORD 9
#define SSO_ERROR_CANNOT_MAKE_MAPS 10
#define SSO_ERROR_WRITE_FAULT 11
#define SSO_ERROR_NO_USER_ENTRY  12
#define SSO_ERROR_USER_LOGIN_DISABLED 13
#define SSO_ERROR_USER_REFUSED 14
#define SSO_ERROR_PASSWORD_EXPIRED 15
#define SSO_ERROR_PASSWORD_CANT_CHANGE 16
#define SSO_ERROR_HISTORY_CONFLICT 17
#define SSO_ERROR_TOO_SHORT 18
#define SSO_ERROR_TOO_RECENT 19
#define SSO_ERROR_VERSION_NUMBER_MISMATCH 20

//#define  TRACE_ON

#ifdef TRACE_ON

#define TRACE(x) { \
     fprintf(stderr, "[%s:%s(%d)]", __FILE__, __FUNCTION__, __LINE__) ; \
     fprintf(stderr, "\t%s\n", x) ; \
     fflush(stderr); \
}

#define TRACEN(x) { \
     fprintf(stderr, "[%s:%s(%d)]", __FILE__, __FUNCTION__, __LINE__) ; \
     fprintf(stderr, "\t%d\n", x) ; \
     fflush(stderr); \
}

#define TRACEV(fmt,val) { \
     fprintf(stderr, "[%s:%s(%d)]", __FILE__, __FUNCTION__, __LINE__) ; \
     fprintf(stderr, fmt, val) ; \
     fprintf(stderr, "\n") ; \
     fflush(stderr); \
}
#else
#define TRACE(x)
#define TRACEN(x)
#define TRACEV(fmt,val)
#endif

#endif //PSWDSYNC_H
