/****************************************************************************/
/*                                                                          */
/*   pam_sso.cpp                                                            */
/*                                                                          */
/*   Error codes return from NT while changing a user's password            */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#include "string.h"
#include "pamssorc.h"
#include "pam_sso.h"
#include "../common/messages.h"

//extern "C" char *strdup(const char *s1);
extern "C" void printMessages(int msgType,const char* str);

char * strdup(const char *s1)
{  
	char *s2;

	if ((s2 = (char*) malloc(strlen(s1)+1)) != 0)
		strcpy(s2, s1);
	return s2;
}



//    Singleton class to hold all globals needed in this program.

class Globals
{
public:
    static Globals* Instance();      // singleton

    int dwAcceptSock;
    int dwReceiveSock;

    unsigned char szEncryptionKey[MAXSECRETLEN];
    unsigned int dwPortNumber;

    HOST_LIST*		pHostList;
    SYNC_OBJ_LIST*	pSyncObjList;
	unsigned int	nSyncRetries;
	unsigned int	nSyncDelay;
    BOOL fDone;

    BOOL fPrelimCheck;
    BOOL fUpdatePass;
    BOOL fChangeExpiredPass;
    BOOL fQuiet;

    BOOL fDebug;
    BOOL fNoWarn;
    BOOL fTryFirstPass;
    BOOL fUseFirstPass;
    BOOL fIgnorePropErrors;

    unsigned int fReadConfig;

    ~Globals() ;

private:
    Globals() {};

};

Globals::~Globals()
{
	free(pSyncObjList);
	free(pHostList);
}

static Globals* instance_ = 0;


Globals*
Globals::Instance()
{
    if	(instance_ == 0 )
	{
		instance_ 	= new Globals();

		instance_->fReadConfig = TRUE;

		instance_->fIgnorePropErrors = FALSE;

		instance_->pSyncObjList = NULL;

		instance_->pHostList = NULL;

	}

    return instance_;
}

#include "../common/config.cpp"

static struct  
{
    const char*	arg;
    BOOL 	fValue;        // TRUE means specified; FALSE otherwise
} s_rgArgsSupported[] =  
	{
		{"debug", 			FALSE},
		{"nowarn", 			FALSE},
		{"use_first_pass", 	FALSE},
		{"try_first_pass", 	FALSE},
        {"read_config", 	FALSE}
	};

static int s_cArgsAccepted = 
	    	sizeof(s_rgArgsSupported) / sizeof(*s_rgArgsSupported);

int processFlagsAndArgs(Globals* pInstance, int flags, int argc, const char **argv);


/*-------------------------------------------------------------------------------*/

// PAM framework looks for this entry-point to pass control to the
// password changing modules.

// pamh is the one which will be used to get all the relevant information pertinent
// to the current password change. Flags and arguments define certain behavior of
// the module

extern 
int pam_sm_chauthtok(pam_handle_t* 	pamh, 
					int 			flags,
					int 			argc, 
					const char**	argv
					)
{
    int ret = PAM_SUCCESS;
    char	szSsodCalledPam[5];// = {'\0'};
    char*   pszSsodCalledPam = szSsodCalledPam;
    HOST_LIST *pHost;

    TRACE(("entered."));

    memset(szSsodCalledPam, 0, 5);

    //
    // Check the flags, arguments and set the appropriate variables
    //
	instance_ = Globals::Instance();

	if (ret = processFlagsAndArgs(instance_, flags, argc, argv) != PAM_SUCCESS)
    {
        // Bail out ?

        TRACE("Invalid arguments\n");
		return(ret);
    }

    // Get the configuration into globals
    if ((ret = getConfiguration(instance_)) != PAM_SUCCESS)
    {
    	ret = PAM_SERVICE_ERR;
    	printMessages(LOGERR,IDS_ERROR_READING_CONF_FILE);
        // Error reading configuration file
        return(ret);
    }

	TRACEV("FLAG = %d",flags);
  
	// if this module is called because ssod wanted to sync password,
	// we dont have to do anything - prelim check or sync password with NT
	// just return PAM_SUCCESS.
	// Whenever SSOD calls for password change, it sets the pam environment variable
	// SSOD_PASSWD_CHRQ=TRUE. 
	// If this env variable is not set, do prelim check and sync password with NT.

       #ifdef HPUX
       if (PAM_SUCCESS == pam_get_data(pamh, "SSOD_PASSWD_CHRQ",(void**)&pszSsodCalledPam) )
       {
               printMessages(LOGDEBUG,IDS_BREAKING_THE_PASSWD_SYNC_LOOP);
               if (!strcmp(pszSsodCalledPam, "TRUE")) {
                                  return PAM_SUCCESS;
               }
       }
       #endif
    #ifdef AIX
	if (PAM_SUCCESS == pam_get_data(pamh, "SSOD_PASSWD_CHRQ",(PAM_ARG_VOIDPPTR)&pszSsodCalledPam) )
	{
		printMessages(LOGDEBUG,IDS_BREAKING_THE_PASSWD_SYNC_LOOP);
 		if (!strcmp(pszSsodCalledPam, "TRUE")) {
				return PAM_SUCCESS;
		}				
	} 
   #endif
    #ifndef HPUX	
	#ifndef hp10
	#ifndef AIX
	if (PAM_SUCCESS == pam_get_data(pamh, "SSOD_PASSWD_CHRQ",(PAM_ARG_CONSTVOIDPTR)&pszSsodCalledPam) )
	{
		printMessages(LOGDEBUG,IDS_BREAKING_THE_PASSWD_SYNC_LOOP);
 		if (!strcmp(pszSsodCalledPam, "TRUE")) {
				return PAM_SUCCESS;
		}				
	} 
	#endif
	#endif
	#endif

	if (flags & PAM_PRELIM_CHECK)
	{
	    int nStoreSyncTries;
	
	    for(pHost = Globals::Instance()->pHostList; pHost != NULL; pHost = pHost->pNext)
	        pHost->fHostToBeSynced = FALSE;

        nStoreSyncTries = Globals::Instance()->nSyncRetries;
	    while ( ( (ret = SSOChangeAuthTok (pamh, TRUE))  != PAM_SUCCESS) && 
					nStoreSyncTries >0 
		      )
		{
			nStoreSyncTries--;

			TRACEV("retry = %d",nStoreSyncTries);

			sleep(Globals::Instance()->nSyncDelay);

		}
		
        if (ret != PAM_SUCCESS && FALSE == Globals::Instance()->fIgnorePropErrors)
            return PAM_TRY_AGAIN;

		TRACE("Returning from Prelim Check; Success");

        g_fPrelimCheckSucceeded = TRUE;

		return PAM_SUCCESS;


	}

	// do this only if prelim check succeeded

	if (g_fPrelimCheckSucceeded)
	{
		TRACE("Trying actual password change on NT\n");

		while ( ( (ret = SSOChangeAuthTok (pamh, FALSE))  != PAM_SUCCESS) && 
					Globals::Instance()->nSyncRetries >0 
		      )
		{
			Globals::Instance()->nSyncRetries--;

			TRACEV("retry = %d",Globals::Instance()->nSyncRetries);

			sleep(Globals::Instance()->nSyncDelay);

		}
	}
    return ret;
}

 
// Parse the flags and arguments and store them in the Global object

int processFlagsAndArgs(Globals* pInstance, int flags, int argc, const char **argv)
{


	TRACE("entered.");

	TRACEV("flags = %x",flags)
	TRACEV("argc = %d",argc)

	for (int i = argc; i-- > 0;)
		TRACEV("argv=%s",*argv);


	int ret = PAM_SUCCESS;

    if (flags & ~PAM_ALL_FLAGS)
    {
        // 
        // We seem to have unknown flags, so, log error
        // 

		printMessages(LOGERR,IDS_UNKNOWN_FLAG_FOUND); 

        return ERROR;
    }

    if (flags & PAM_PRELIM_CHECK)
    {
        //
        // We just need to check if we can connect to one of the Windows
        // boxes. If so, we return SUCCESS;
        //
		pInstance->fPrelimCheck = TRUE;
    }

	if (flags & PAM_UPDATE_AUTHTOK)
		pInstance->fUpdatePass = TRUE;

	if (flags & PAM_CHANGE_EXPIRED_AUTHTOK)
		pInstance->fChangeExpiredPass = TRUE;

    if (flags & PAM_SILENT)
        pInstance->fQuiet = TRUE;
    else
        pInstance->fQuiet = FALSE;

    for ( ; argc-- > 0; ++argv)
    {
		int i;

		for (i=0; i<s_cArgsAccepted; i++) 
		{
		    if (strcmp(*argv, s_rgArgsSupported[i].arg) == 0) 
			{
                s_rgArgsSupported[i].fValue = TRUE;
				break;
		    }
		   // else
		    //{
		//	s_rgArgsSupported[i].fValue = FALSE;
		 //   }
		}


		if (i >= s_cArgsAccepted)
		{
			// Log error about unknown option
			//

			printMessages(LOGERR,IDS_UNKNOWN_OPTION);

			return(ERROR);
		}
	}

    //
    // set the appropriate flags in the globals like fDebug, fNoWarn etc.
    //

	pInstance->fDebug 			= s_rgArgsSupported[IDX_DEBUG].fValue;
	pInstance->fNoWarn			= s_rgArgsSupported[IDX_NOWARN].fValue;
	pInstance->fTryFirstPass	= s_rgArgsSupported[IDX_TRYFIRSTPASS].fValue;
	pInstance->fUseFirstPass	= s_rgArgsSupported[IDX_USEFIRSTPASS].fValue;

	// if both try_first_pass and use_first_pass is given, try_first_pass overrides 
	// if neither try_first_pass and use_first_pass is given, try_first_pass is default 

	if (!pInstance->fTryFirstPass && !pInstance->fUseFirstPass)
		pInstance->fTryFirstPass = TRUE;

	// set logmask so that all debug,warning and errors captured

	// if both debug and nowarn mentioned, debug ovverrides and it is warning

	if (pInstance->fNoWarn)
		setlogmask(LOG_UPTO(LOG_ERR));
	else
		if (pInstance->fDebug)
			setlogmask(LOG_UPTO(LOG_DEBUG));
		else 
			setlogmask(LOG_UPTO(LOG_WARNING));



	TRACE("flags debug, warn, try, use");
	TRACEV("pInstance->fDebug=%d", pInstance->fDebug);
	TRACEV("pInstance->fNoWarn=%d", pInstance->fNoWarn);
	TRACEV("pInstance->fTryFirstPass=%d", pInstance->fTryFirstPass);
	TRACEV("pInstance->fTryFirstPass=%d", pInstance->fUseFirstPass);

	TRACEV("ret = %d", ret);

	return ret;
}

// Do the actual work; It could be just a preliminary check or a real 
// password change. All information is obtained from the handle. 
//

int 
SSOChangeAuthTok (pam_handle_t *pamh, BOOL fPrelimCheck)
{
    TRACE("entered.");

    int ret = PAM_SUCCESS;

    const char *szPrompt = "Username: "; char *pszUser = NULL;
    

//    static char szTemp[] = "temppass";

    const char *szOldPassword ;
    const char *szNewPassword="temppass";//szTemp;

    //
    // Set the global settings from the config file; it should set 
    // attributes such as the list of servers and port numbers etc
    // 

    // TRACE("Preliminary password update");

    // the following lines are changed to use get_item for getting 
    // user name. HP pam library does not have a get_user function. 
    // SUN and Linux have.

	// ret = pam_get_user(pamh, &pszUser, szPrompt);
    // BAIL_ON_PAM_FAIL(ret);

	ret = pam_get_item(pamh, PAM_USER, (PAM_ARG_VOIDPPTR)&pszUser);
    BAIL_ON_PAM_FAIL(ret);

    TRACEV("user=%s", pszUser);

	// if the is disallowed for sync, just log it and
	// return PAM_SUCCESS

	if ((ret = syncThisUser(pszUser)) == ERROR) 
	{
		ret = PAM_SUCCESS;
		goto Error;
	}

    //
    // Get the Old password 
    // Not necessary for now
    // 
//////////// ADD get new Password TBD


    // ret = getPassword(pamh, TRUE, &szOldPassword);
    // BAIL_ON_PAM_FAIL(ret);


    // TRACEV(" Old passwd=%s", szOldPassword);

    //
    // Check the validity of the old password
    //

    // ret = checkOldPassword(pamh, pszUser, szOldPassword);
    // BAIL_ON_PAM_FAIL(ret);

    // 
    // TBD: check if you can contact the remote machine
    // 

    if (Globals::Instance()->fPrelimCheck)
    {
        // Check if one of the DCs is accessible. The best way to do that
        // probably is to try and connect to that machine. we can hold on to 
        // that socket as we will get the real request soon anyway. 

        // Don't bother for now. 

        // prelim check is a separate call
    }

    // Now we have to do the real password change
    //

    //
    // Get the New password 
    // 

    if (!fPrelimCheck)
    {
        ret = getPassword(pamh, FALSE,&szNewPassword);
        BAIL_ON_PAM_FAIL(ret);

        TRACEV("New passwd=%s", szNewPassword);
    }

    // TBD: Now set the new password
    //

	// this should change the unix password and also send crypted change requst to 
	// NT. Looks like this code is NT only
	//
    ret = SecureChangePassword(pszUser, szOldPassword, szNewPassword, fPrelimCheck, pamh);

Error: 

	TRACEV("ret=%d",ret);

    return ret;
}


//
// Gets the password (old or new) from the handle. If it can't obtain from the 
// handle, it obtains it directly by prompting the user. The prompting function
// is a callback given by the application which called PAM. This has to be done 
// only if use_first_pass is not set in the arguments. 
//
#if defined (HPUX) || defined (SOLARIS)
int 
getPassword( pam_handle_t *pamh, BOOL fIsOldPassword, const char ** ppszPassword)
{
#else
int
getPassword( pam_handle_t *pamh, BOOL fIsOldPassword,PAM_ARG_CHARPPTR ppszPassword)
{
#endif
	TRACE("entered");
	int	ret = PAM_SUCCESS;

	struct pam_message msg[2];

    PAM_ARG_CONST struct pam_message *pmsg[2] = {&msg[0], &msg[1]};

	struct pam_response *resp = NULL;

	struct pam_conv *conv = NULL;

    if (Globals::Instance()->fTryFirstPass || Globals::Instance()->fUseFirstPass)
    {

        ret = pam_get_item(
                  pamh, 
                  fIsOldPassword ? PAM_OLDAUTHTOK : PAM_AUTHTOK, 
                  (PAM_ARG_VOIDPPTR)ppszPassword);

        BAIL_ON_PAM_FAIL(ret);
    }
    
    if (*ppszPassword == NULL)
    {
		TRACE("passwd = NULL");

        if (Globals::Instance()->fUseFirstPass)
        {
            return PAM_AUTHTOK_RECOVERY_ERR;       
        }
        else 
        {

            //
            // get the password from the user directly using the 
            // conversation functions. 

            ret = pam_get_item( pamh, PAM_CONV, (PAM_ARG_VOIDPPTR)&conv ) ; 
            BAIL_ON_PAM_FAIL(ret = PAM_AUTHTOK_RECOVERY_ERR);

            if (fIsOldPassword)
            {
                msg[0].msg_style = PAM_PROMPT_ECHO_OFF;
                msg[0].msg = "Old Password: ";
    
                ret = conv->conv(1, pmsg, &resp, conv->appdata_ptr);
                BAIL_ON_PAM_FAIL(ret);
    
                if (resp != NULL)
                {
                    BAIL_ON_PAM_FAIL( ret = PAM_AUTHTOK_RECOVERY_ERR);
                }
    
                *ppszPassword = (char*)strdup(resp[0].resp);
    
                if (*ppszPassword == NULL)
                {
                    BAIL_ON_PAM_FAIL( ret = PAM_AUTH_ERR);
                }
            }
            else 
            {
                msg[0].msg_style = PAM_PROMPT_ECHO_OFF;
                msg[0].msg = "New Password: ";
    
                msg[1].msg_style = PAM_PROMPT_ECHO_OFF;
                msg[1].msg = "New Password (Again): ";
    
                ret = conv->conv(2, pmsg, &resp, conv->appdata_ptr);
                BAIL_ON_PAM_FAIL(ret);
    
                if (resp != NULL)
                {
                    BAIL_ON_PAM_FAIL( ret = PAM_AUTHTOK_RECOVERY_ERR);
                }
    
                *ppszPassword = (char*)strdup(resp[0].resp);
    
                if (*ppszPassword == NULL)
                {
                    BAIL_ON_PAM_FAIL( ret = PAM_AUTH_ERR);
                }

            }

			// if the passwords are obtained successfully, set them back using
			// pam_set_item
			//
			// TBD
        }
    }


Error:
 
	for (int i=0; i<2; i++)
	{
		if (pmsg[i] && pmsg[i]->msg)
		{
			// TBD
			// shall we delete this
			//_pam_delete(resp[i].resp);
		}
		//TBD 
		//	free(pmsg);
	}
    return ret;
}

// Check the old password for its validity. Don't bother for now, as we are 
// always stacked below the Unix authentication module. 
//

int 
checkOldPassword( pam_handle_t *pamh, char *szUser, char *szPassword)
{
	return PAM_SUCCESS;
}


// 
// Do the password change for the specified user. 
int 
SecureChangePassword(	char *pszUserName,
						const char *pszOldPassword,
						const char *pszNewPassword,
						BOOL fPrelimCheck,
						pam_handle_t *pamh
)
{
	char szBuffer[MAX_BUFFER_SIZE + 1];
	
	TRACE ("entered");

	int ret = PAM_SUCCESS;

	DWORD	dwResult;

	unsigned char*	pszSecret;

	HOST_LIST* pHost;

	//CSecurePswdSync SecurePswdSync;

	Globals *pInstance = Globals::Instance();

	TRACE ("after globals initialization");

	if (pInstance->pHostList == NULL)
	{
		// Nothing do do 
		ret = PAM_SUCCESS;
		goto Done;
	}

	// Do the sync to all machine in the hostlist
	//

	for(pHost = pInstance->pHostList; pHost != NULL; pHost = pHost->pNext)
	{
	    if ((TRUE == fPrelimCheck && FALSE == pHost->fHostToBeSynced) ||
	        (FALSE == fPrelimCheck && TRUE == pHost->fHostToBeSynced))
	    {
    		//
    		// If the secret for this host is NULL, we just take the global secret
    		//

    		pszSecret = pHost->pszEncryptionKey ? 
    						pHost->pszEncryptionKey : pInstance->szEncryptionKey; 

    		//
    		// call the function that encrypts and sends it to the remote host. 
    		//

    		TRACEV("pInstance->szEncryptionKey=%s", pInstance->szEncryptionKey);
    		TRACEV("pszSecret=%s", pszSecret);


    		dwResult = MEPPPasswordChange(
    					  pHost->pszHostName,
    					  pszUserName,
    					  pszNewPassword,
    					  pHost->dwPort,
    					  pszSecret,
    				          fPrelimCheck,
    					  pamh,
    					  pInstance->fIgnorePropErrors
    					);

    		if (dwResult != SSO_ERROR_SUCCESS)
    		{
    			snprintf(szBuffer, sizeof(szBuffer), "%s %s %s",IDS_PASSWORD_FOR_USER_FAILED_TO_SYNC,IDS_USER,pszUserName);
    			printMessages(LOGERR,szBuffer);
    			if (SSO_ERROR_PROTOCOL == dwResult)
    			    ret |= ERROR;
    		}
    		else
    		{
			if (TRUE != fPrelimCheck)
			{
    				snprintf(szBuffer, sizeof(szBuffer), "%s %s %s",IDS_PASSWORD_FOR_USER_SYNCED_SUCCESSFULLY,IDS_USER,pszUserName);
    				printMessages(LOGINFO,szBuffer);
			}
    			if (TRUE == fPrelimCheck)
    			    pHost->fHostToBeSynced = TRUE;
    			else
    			    pHost->fHostToBeSynced = FALSE;
    		}
		}
	}

	if (ret != PAM_SUCCESS)
		ret = PAM_AUTHTOK_ERR;

	Done:
	Error:

	TRACEV("ret = %d",ret);

    return  ret;
}

/****************************************************************************/


/*--------------------------------------------------------------------*/
int pam_sso_message(pam_handle_t *pamh, char* pMessage)
{
       char    szBuffer[MAX_BUFFER_SIZE];

       int     ret = PAM_SUCCESS;

       struct pam_message msg[2];

       PAM_ARG_CONST struct pam_message *pmsg[2] = {&msg[0], &msg[1]};

       struct pam_conv *conv = NULL;

       struct pam_response *resp = NULL;

       ret = pam_get_item( pamh, PAM_CONV, (PAM_ARG_VOIDPPTR)&conv ) ;
       BAIL_ON_PAM_FAIL(ret);

       msg[0].msg_style = PAM_ERROR_MSG;

       snprintf(szBuffer, sizeof(szBuffer), "Password sync failure : %s", pMessage);

       msg[0].msg = szBuffer;


       ret = conv->conv(1, pmsg, &resp, (PAM_ARG_VOIDPPTR)conv->appdata_ptr);
       BAIL_ON_PAM_FAIL(ret);
Error:
	return ret;
}
