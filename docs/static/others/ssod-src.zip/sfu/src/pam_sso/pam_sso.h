/****************************************************************************/
/*                                                                          */
/*   pam_sso.h                                                              */
/*   Error codes return from NT while changing a user's password            */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _PAM_SSO_H_
#define	_PAM_SSO_H_

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <syslog.h>
#include <pwd.h>
#include <fcntl.h>
#include <ctype.h>

#include <unistd.h>


#include <arpa/inet.h>

#ifdef HPUX
#include <netinet/in.h>
#endif

#include <netdb.h>

#include <time.h>
#include <string.h>
#include <strings.h>


#include <signal.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#if 0
#include <iostream.h>
#else
#include <iostream>
using namespace std;
#endif
#include <syslog.h>
#include <errno.h>
#include <fcntl.h>


#ifdef HPUX
#define PAM_ARG_CHARPPTR char **
#else
#ifdef AIX
#define PAM_ARG_CHARPPTR char **
#else
#ifdef SOLARIS
#define PAM_ARG_CHARPPTR char **
#else
#define PAM_ARG_CHARPPTR const char **
#endif
#endif
#endif

#ifdef HPUX
#define PAM_ARG_VOIDPPTR void **
#else
#ifdef AIX
#define PAM_ARG_VOIDPPTR void **
#else
#ifdef SOLARIS
#define PAM_ARG_VOIDPPTR void **
#else
#define PAM_ARG_VOIDPPTR const void **
#endif
#endif
#endif

#ifdef HPUX
#define PAM_ARG_CONST
#else
#ifdef AIX
#define PAM_ARG_CONST
#else
#ifdef SOLARIS
#define PAM_ARG_CONST
#else
#define PAM_ARG_CONST const
#endif
#endif
#endif

#define PAM_ARG_CONSTVOIDPTR	const void **





#ifdef LINUX
	extern "C"
	{
#endif

#include <security/pam_appl.h>
#include <security/pam_modules.h>

#ifdef LINUX
	}
#endif

#include "../common/nttype.h"
#include "pswdsync.h"
#include "cryptpc.h"

#define PAM_DEF

#define INVALID_SOCKET  (SOCKET)(~0)
#define SOCKET_ERROR            (-1)
#define	SD_BOTH 0x02

#define INADDR_NONE             	     0xffffffff

#define WSAEADDRINUSE                    10048L
#define WSAECONNREFUSED                  10061L
#define WSAETIMEDOUT                     10060L

#ifdef LINUX
#define PAM_AUTHTOK_RECOVERY_ERR 	PAM_AUTHTOK_RECOVER_ERR
#endif

#define BAIL_ON_PAM_FAIL(p) {if (p) {  goto Error; }} 

#define SSO_DEFAULT_PORT  6677                                 // Default port for daemon to listen on.
#define SSO_DEFAULT_ENCRYPTION_KEY "ABCDZ#efgh$12345"
#define SSOD_CONFIG_FILE      	"/etc/sso.conf"

# define MAXLINELENGTH    		280 // PATH_MAX=255 + 25 app
# define MAXPATHLENGTH    		256 // Including null
# define MAXSECRETLEN      		22  // including null
# define MINSECRETLEN      		16  // NOT including null
# define MAX_BUFFER_SIZE    	512 // Including null

#ifndef MAXHOSTNAMELEN
# define MAXHOSTNAMELEN    		65  //including null
#endif

# define SUCCESS 				0
# define ERROR 				   -1

# define SYNC_HOSTS_SET        0x0001u
# define SYNC_USERS_SET       0x0002u
# define ENCRYPT_KEY_SET      0x0004u
# define PORT_NUMBER_SET      0x0008u
# define SYNC_RETRIES_SET     0x0010u
# define SYNC_DELAY_SET       0x0020u

#define CONF_ALL_SET	(SYNC_HOSTS_SET | SYNC_USERS_SET | ENCRYPT_KEY_SET | PORT_NUMBER_SET | SYNC_RETRIES_SET | SYNC_DELAY_SET )

#define MUST_PAMSSO_SET	(SYNC_HOSTS_SET | SYNC_USERS_SET | SYNC_RETRIES_SET | SYNC_DELAY_SET )

#define	PAM_ALL_FLAGS	(PAM_SILENT | PAM_CHANGE_EXPIRED_AUTHTOK | PAM_PRELIM_CHECK | PAM_UPDATE_AUTHTOK)

// flag indexes to access the  array s_rgArgsSupported
//
#define	IDX_DEBUG			0
#define	IDX_NOWARN			1
#define	IDX_TRYFIRSTPASS	2
#define	IDX_USEFIRSTPASS	3


typedef struct _host_list 
{
    char*					pszHostName;
    unsigned char*			pszEncryptionKey;
    DWORD					dwPort;
    BOOL                    fHostToBeSynced;
    struct _host_list*		pNext;
} HOST_LIST;

typedef struct _sync_user_list 
{
    char*					pszSyncObjName;
    BOOL 					fSync;
    struct _sync_user_list*	pNext;
} SYNC_OBJ_LIST;



static BOOL g_fPrelimCheckSucceeded = FALSE;

/*--------------------------------- functuin prototypes -------------------------*/
extern
int  pam_sm_chauthtok(pam_handle_t* 	pamh, 
					int 			flags,
					int 			argc, 
					const char**	argv
					);

extern
DWORD  MEPPPasswordChange(	LPCSTR Host,
							LPCSTR UserName,
							LPCSTR Password,
							DWORD  PortNumber,
							BYTE*  Secret,
							BOOL   fPrelimCheck,
							pam_handle_t*     pamh,
							BOOL   fIgnoreErrors
						);


int SSOChangeAuthTok (pam_handle_t *pamh, BOOL fPrelimCheck);

int getPassword(pam_handle_t *pamh, BOOL fIsOldPassword, const char **ppszPassword);

int checkOldPassword( pam_handle_t *pamh, char *szUser, char *szPassword);

int pam_sso_message(pam_handle_t *pamh, char* pMessage);

int 
SecureChangePassword(	char *pszUserName,
						const char *pszOldPassword,
						const char *pszNewPassword,
						BOOL fPrelimCheck,
						pam_handle_t *pamh
					);


#endif //_PAM_SSO_H_
