/****************************************************************************/
/*                                                                          */
/*   cryptpc.cpp                                                            */
/*   PAM Single Sign-On from Unix to NT                                     */
/*                                                                          */
/*   Copyright 1998-1999 Microsoft Corporation                              */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/
#include <stdlib.h>
#include "crptpcrc.h"
#include "pam_sso.h"
#include "../common/messages.h"

#define MAX_ATTEMPTS 5
#define RANDOM_VALUE_LEN 8

#define MAX_SECRET_SIZE  21
#define MAX_BUFFER_SIZE  512

static DWORD RandomData = 0x3245a596;

#define MEPP_UPDATE_PASSWORD   0
#define MEPP_RESPONSE	       1
#define MEPP_PRELIM_CHECK      2

#define ENCRYPT     1
#define closesocket 	close

#define MEPP_VERSION   0
//-------------------- externs ---------------------------------------------

extern "C" long random(void);
extern "C" void srandom(unsigned);
extern "C" size_t strlcpy(char *dst, const char *src, size_t siz);
extern "C" int  snprintf(char *,size_t,const char*,...);
extern "C" void printMessages(int msgType,const char* str);
extern int  pam_sso_message(pam_handle_t *pamh, char* pMessage);

//--------------------------------------------------------------------------

size_t strlcpy(char *dst, const char *src, size_t siz)
{
        char *d = dst;
        const char *s = src;
	size_t n = siz;

	if (n != 0 && --n != 0) {
		do {
			if ((*d++ = *s++) == 0)
				break;
                   } while (--n != 0);
        }

        if (n == 0) {
	        if (siz != 0)
		        *(d) = '\0';
                while (*s++)
	                ;
        }
        return(s - src - 1);
}

// SOCKET  rresvport(unsigned short & port, unsigned short MaxPort);

class CSecurePswdSync
{
public:
    CSecurePswdSync() { m_pSendBuffer = NULL; m_s = INVALID_SOCKET;} ;
    ~CSecurePswdSync()
    {
        if ( m_pSendBuffer )
            free(m_pSendBuffer);
        if ( m_s != INVALID_SOCKET )
        {
            shutdown(m_s, SD_BOTH);
            closesocket(m_s);
        }
    }

    // Connect to host.
    DWORD Connect(LPCSTR, DWORD);

    // Execute the protocol.
    DWORD DoProtocol(LPCSTR UserName, LPCSTR Password, LPCSTR Host, BOOL fPrelimCheck, pam_handle_t*     pamh, BOOL fIgnoreErrors);

    // Stuff specific to Encrypted Propagation
    BYTE Key[MAX_SECRET_SIZE+1];

private:

    SOCKET m_s;

    //BYTE m_R1[RANDOM_VALUE_LEN+1];
    //BYTE m_R2[RANDOM_VALUE_LEN+1];

    DWORD m_R1[3];
    DWORD m_R2[3];

    LPBYTE m_pSendBuffer;
    DWORD m_dwSendBufferSize;

    DWORD BuildMessageBuffer(LPCSTR UserName, LPCSTR Password, BOOL fPrelimCheck);

    void make_hash(BYTE *hashval, LPBYTE R1, LPBYTE R2, unsigned long ourIP, unsigned long peerIP);
    void GenerateHashForSending(BYTE *hashval, 
                                DES3TABLE *KeyTable,
                                DWORD   dwVersion,
                                DWORD   dwMsgLength,
                                DWORD   dwMsgType,
                                LPCSTR UserName, 
                                LPCSTR Password);

    DWORD EncryptData(LPCSTR UserName, LPCSTR Password, LPBYTE &lpBuffer, DWORD *dwBufferLen, UINT uiMsgType);
};

typedef struct _MsgHeader {
    DWORD   dwVersion;
    DWORD   dwMsgLen;
} MsgHeader;

typedef struct _MsgData {
    MsgHeader  Header;
    DWORD   dwMsgType;  // 0 - Request; 1 - Response ; 2 - Prelim Check
    //BYTE    databytes[ UserName.Length + Domain.Length + Password.Length];
} MsgData;

typedef struct _ResponseMsg {
    MsgHeader Header;
    DWORD dwMsgType;    // is set to 1
    DWORD dwResult;
} ResponseMsg;

BOOL isRoot(void)
{
    if (getuid() == 0)
        return TRUE;
    return FALSE;
}

DWORD 
CSecurePswdSync::BuildMessageBuffer(
    LPCSTR UserName,
    LPCSTR Password,
    BOOL fPrelimCheck
    )
{
    MsgData *pMsg;
    UINT     uiMsgType ;

    fPrelimCheck ? uiMsgType = MEPP_PRELIM_CHECK : uiMsgType = MEPP_UPDATE_PASSWORD; 
    m_dwSendBufferSize = sizeof(MsgData);
    if ( EncryptData(UserName, Password, m_pSendBuffer, &m_dwSendBufferSize, uiMsgType))
        return 0;

    pMsg = (MsgData *)m_pSendBuffer;

    pMsg->Header.dwVersion = htonl(MEPP_VERSION);
    pMsg->Header.dwMsgLen = htonl(m_dwSendBufferSize);

    pMsg->dwMsgType = htonl(uiMsgType);

    return m_dwSendBufferSize;
}

DWORD
CSecurePswdSync::Connect(LPCSTR Host, DWORD PortNumber)
{
    int timo = 100;
    int attempts = 0;
    struct sockaddr_in sin;
    struct hostent *hp;
    unsigned long ulNonBlocked = 1;
    int ret = 0;
    unsigned short port = 0;
    char szBuffer[MAX_BUFFER_SIZE + 1];

    TRACE("entered");

    sin.sin_family = AF_INET;
    if ( (sin.sin_addr.s_addr = inet_addr(Host)) == INADDR_NONE) {
        hp = gethostbyname(Host);
        if ( hp == NULL ) {

        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_UNKNOWN_HOST,IDS_HOST,Host);
        	printMessages(LOGERR,szBuffer);
        	
            //LogError(MSG_ERROR_UNKNOWN_HOST, Host);
            return 0;
        }

        sin.sin_family = (short) hp->h_addrtype;
        memcpy(&sin.sin_addr, hp->h_addr, hp->h_length);
    }

retry:

    m_s = socket(PF_INET, SOCK_STREAM, 0);
    if (m_s == INVALID_SOCKET)
    {
        //LogError(MSG_ERROR_CONNECTING_HOST, Host, strerror(errno));

        snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_ERROR_CONNECTING_HOST,IDS_HOST,Host,IDS_ERROR,strerror(errno));
        printMessages(LOGERR,szBuffer);
        
        return 0;
    }

    sin.sin_port = htons((short)PortNumber);

    if ( connect(m_s, (const struct sockaddr *) &sin, sizeof (sin)) < 0) 
    {
        DWORD errorCode = errno;

        (void) closesocket(m_s);
        if ( (errorCode == WSAEADDRINUSE || errorCode == WSAECONNREFUSED || errorCode == WSAETIMEDOUT) && (attempts < MAX_ATTEMPTS))
        {
            sleep(timo);
            timo *= 2;
            attempts++;
            port++; // we need to go to the next port as well.
            goto retry;
        }
		snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_ERROR_CONNECTING_HOST,IDS_HOST,Host,IDS_ERROR,strerror(errno));
        printMessages(LOGERR,szBuffer);

        //LogError(MSG_ERROR_CONNECTING_HOST, Host, errorCode);
        return 0;
    }

    return 1;
}

/*
    DoProtocol(LPCSTR UserName, LPCSTR Password, LPCSTR Host, BOOL fPrelimCheck, pam_handle_t*     pamh)

    Execute the Protocol.

    1) Receive the Random Value from the Unix Side.

    2) Generate Hash on which the Session Key is based on.
            Hash is based on
                    Konstant.
                    R1 from Unix Side,
                    R2 generated on this machine.
                    name of Unix machine.
                    name of this Machine.

    3) Generate the Session Key based on above Hash.

    4) Generate another Hash which forms part of the encrypted data.
            This hash is based on
                    Username, Password,
                    R1 from Unix Side,
                    R2 generated on this machine.
                    name of Unix machine.
                    name of this Machine.
    5) Encrypt data using Key from 3)
            The data is
                    UserName, Password.
                    Hash generated in 4).
    6) Send data to Unix Side.
            The data is
                    R2 
                    Encryted Data from Step 5).

    7) Receive the response from the UNIX side.

    Steps 2) to 5) are done by the BuildMessageBuffer function.

    Returns TRUE if all steps were successful and also the UNIX side
    says the password change was successful.

    FALSE otherwise.

    Side effects:  Logs Events to the Eventlog.
*/

DWORD 
CSecurePswdSync::DoProtocol(LPCSTR UserName, LPCSTR Password, LPCSTR Host, BOOL fPrelimCheck, pam_handle_t* pamh, BOOL fIgnoreErrors)
{
    DWORD dwMsgLen;
    char  szBuffer[MAX_BUFFER_SIZE + 1];
    DWORD retVal;

    do 
    {
        if ( (dwMsgLen = recv(m_s, (char *)m_R1, RANDOM_VALUE_LEN, 0)) != RANDOM_VALUE_LEN )
        {
	    	snprintf(szBuffer, sizeof(szBuffer), "Error receiving NT host data.");

	    	pam_sso_message(pamh, szBuffer);
	    	printMessages(LOGERR,IDS_ERROR_RECEIVING_NT_HOST_DATA);

            return SSO_ERROR_PROTOCOL;
        }

        dwMsgLen = BuildMessageBuffer(UserName, Password, fPrelimCheck);
        

        if ( dwMsgLen == 0 )
        {
            break;
        }

        if ( (DWORD)send(m_s, (const char *)m_pSendBuffer, dwMsgLen, 0) != (dwMsgLen) )
        {
            // Error in sending. Log the error and fail.
            //LogError(MSG_ERROR_SENDING_ENC_BUFFER, strerror(errno));

			printMessages(LOGERR,IDS_ERROR_SENDING_ENCODED_BUFFER);
			
            break;
        }

        // now wait for the return value.  SendBuffer is overloaded to receive the data

        dwMsgLen = recv(m_s, (char *)m_pSendBuffer, dwMsgLen, 0);

        if ( dwMsgLen == SOCKET_ERROR || dwMsgLen == 0)
        {
            // Error in Receiving. Log the error and fail the
            // operation.
            // LogError(MSG_ERROR_RECEIVING, strerror(errno));

	    	snprintf(szBuffer, sizeof(szBuffer), "Error receiving NT host data.");

	    	pam_sso_message(pamh, szBuffer);

	    	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_RECEIVING_NT_HOST_DATA,IDS_ERROR,strerror(errno));
			printMessages(LOGERR,szBuffer);
			
            break;
        }
        else
        {
            // crack the return code and log it.
            ResponseMsg *pData = (ResponseMsg *)m_pSendBuffer;

            // ASSERT(pData->dwMsgType == ntohl(1);
            pData->dwResult = ntohl(pData->dwResult);
            switch ( pData->dwResult )
            {
            case SSO_ERROR_SUCCESS:
                // that is success;
                return pData->dwResult;
                break;
            case SSO_ERROR_NO_USER_ENTRY: 

                //User not present is not considered as an error. 
                //So we are not logging the error or printing it on the screen either.
	        	//snprintf(szBuffer, sizeof(szBuffer), "User %s unknown on NT host %s.",UserName, Host);

	        	//pam_sso_message(pamh, szBuffer);

				//snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_USER_UNKNOWN_ON_NT_HOST,IDS_USER,UserName,IDS_HOST,Host);
				//printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_NO_USER_ENTRY;

                break;

            case SSO_ERROR_BAD_PASSWORD: 

                if (!fIgnoreErrors)
                {
    				snprintf(szBuffer, sizeof(szBuffer),"Windows password mismatch for user %s on %s.",UserName, Host);
    				pam_sso_message(pamh, szBuffer);
				}

				snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_WINDOWS_PASSWORD_MISMATCH,IDS_USER,UserName,
					IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_PROTOCOL;
				
                break;

            case SSO_ERROR_HISTORY_CONFLICT: 
            case SSO_ERROR_TOO_RECENT: 
            case SSO_ERROR_TOO_SHORT: 
                
                if (!fIgnoreErrors)
                {
    				snprintf(szBuffer, sizeof(szBuffer),"Windows password doesn't conform to password policy for user %s on %s.",UserName, Host);
    	        	pam_sso_message(pamh, szBuffer);
                }
    
				snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_WINDOWS_PASSWORD_DOESNT_CONFORM_TO_PASSWORD_POLICY,
					IDS_USER,UserName,IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);	
				retVal = SSO_ERROR_PROTOCOL;
	        	
                break;

            case SSO_ERROR_PASSWORD_CANT_CHANGE: 

                if (!fIgnoreErrors)
                {    			
    				snprintf(szBuffer, sizeof(szBuffer), "Windows password is set to CAN'T_CHANGE for user %s on %s.",UserName, Host);
    				pam_sso_message(pamh, szBuffer);
				}

				snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_WINDOWS_PASSWORD_IS_SET_TO_CANT_CHANGE,
					IDS_USER,UserName,IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_PROTOCOL;
				
                break;

            case SSO_ERROR_PASSWORD_EXPIRED: 

                if (!fIgnoreErrors)
                {
    				snprintf(szBuffer, sizeof(szBuffer), "Windows password has expired for user %s on %s.",UserName, Host);
    	        	pam_sso_message(pamh, szBuffer);
	        	}

	        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_WINDOWS_PASSWORD_HAS_EXPIRED,
					IDS_USER,UserName,IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_PROTOCOL;

                break;

            case SSO_ERROR_USER_REFUSED: 

                if (!fIgnoreErrors)
                {
    				snprintf(szBuffer, sizeof(szBuffer), "syncing password on Windows disallowed for user %s on %s.",UserName, Host);
    	        	pam_sso_message(pamh, szBuffer);
	        	}

	        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_SYNCING_PASSWORD_ON_WINDOWS_DISALLOWED,
					IDS_USER,UserName,IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_PROTOCOL;
				
                break;

            case SSO_ERROR_PROTOCOL: 

                if (!fIgnoreErrors)
                {
    				snprintf(szBuffer, sizeof(szBuffer), "Error verifying decrypted message. Verify encryption key and check for network configuration errors for Host: %s.", Host);
    	        	pam_sso_message(pamh, szBuffer);
	        	}

	        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_PACKET_DECRYPT_ERROR,
					IDS_USER,UserName,IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_PROTOCOL;
				
                break;

            case SSO_ERROR_USER_LOGIN_DISABLED: 

                if (!fIgnoreErrors)
                {
    				snprintf(szBuffer, sizeof(szBuffer), "Password update is disabled for %s on %s.",UserName, Host);
    	        	pam_sso_message(pamh, szBuffer);
	        	}

	        	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_PASSWORD_UPDATE_IS_DISABLED,
					IDS_USER,UserName,IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_PROTOCOL;

                break;

            default:

                if (!fIgnoreErrors)
                {
    				snprintf(szBuffer, sizeof(szBuffer), "Password update for %s failed on %s.",UserName, Host);
    	       		pam_sso_message(pamh, szBuffer);
    	       	}

	       		snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_PASSWORD_FAILED,
					IDS_USER,UserName,IDS_HOST,Host);
				printMessages(LOGERR,szBuffer);
				retVal = SSO_ERROR_PROTOCOL;

                break;
            }
        }
    } while ( FALSE );

    return retVal;
}


DWORD 
MEPPPasswordChange(
    LPCSTR Host,
    LPCSTR UserName, 
    LPCSTR Password,
    DWORD  PortNumber,
    BYTE*  Secret,
    BOOL   fPrelimCheck,
    pam_handle_t*     pamh,
    BOOL   fIgnoreErrors
    )
{
    CSecurePswdSync SecurePswdSync;
    DWORD          retVal;

    TRACE("entered");

    TRACEV("secret=%s", Secret);

    // Copy the secret 
    memcpy(SecurePswdSync.Key, Secret, MAX_SECRET_SIZE);

    // Null the last byte
    SecurePswdSync.Key[MAX_SECRET_SIZE] = '\0';

    if ( !SecurePswdSync.Connect(Host, PortNumber) )
        return SSO_ERROR_PROTOCOL;

    TRACE("Connect done");

    retVal = SecurePswdSync.DoProtocol(UserName, Password, Host, fPrelimCheck, pamh, fIgnoreErrors);

    TRACE("DoProtocol done");

    return retVal;
}

#ifndef NO_ENCRYPTION

void 
CSecurePswdSync::make_hash(BYTE *hashval, BYTE *r1, BYTE *r2, unsigned long ourIP, unsigned long peerIP)
{
    SHA1_CTX  hash_ctx;

    SHA1Init(&hash_ctx);

    SHA1Update(&hash_ctx, r1, RANDOM_VALUE_LEN);
    SHA1Update(&hash_ctx, Key, strlen((char*) Key));
    SHA1Update(&hash_ctx, r2, RANDOM_VALUE_LEN);
    SHA1Update(&hash_ctx, (BYTE *)&ourIP, sizeof(unsigned long));
    SHA1Update(&hash_ctx, (BYTE *)&peerIP, sizeof(unsigned long));

    SHA1Final(hashval, &hash_ctx);
}

void
CSecurePswdSync::GenerateHashForSending(
        BYTE *hashval, 
        DES3TABLE *KeyTable,
        DWORD   dwVersion,
        DWORD   dwMsgLength,
        DWORD   dwMsgType,
        LPCSTR UserName, 
        LPCSTR Password)
{
    SHA1_CTX  hash_ctx;

    SHA1Init(&hash_ctx);
   
    SHA1Update(&hash_ctx, (BYTE *)KeyTable, sizeof(DES3TABLE));
    SHA1Update(&hash_ctx, (BYTE *)&dwVersion, sizeof(DWORD));
    SHA1Update(&hash_ctx, (BYTE *)&dwMsgLength, sizeof(DWORD));
    SHA1Update(&hash_ctx, (BYTE *)&dwMsgType, sizeof(DWORD));
    SHA1Update(&hash_ctx, (BYTE *)UserName, strlen(UserName));
    SHA1Update(&hash_ctx, (BYTE *)Password, strlen(Password));

    SHA1Final(hashval, &hash_ctx);
}

// the hash value is not long enough so we must expand it
void extend_hash_forkey(BYTE *hashval)
{
    SHA1_CTX h1, h2;
    BYTE rgbBuff1[64], rgbBuff2[64];

    // set up the two buffers to be hashed
    SHA1Init(&h1);
    SHA1Init(&h2);

    memset(rgbBuff1, 0x36, sizeof(rgbBuff1));
    memset(rgbBuff2, 0x5C, sizeof(rgbBuff2));
    for (int i=0;i<20;i++)
    {
        rgbBuff1[i] ^= hashval[i];
        rgbBuff2[i] ^= hashval[i];
    }

    // hash the two buffers
    SHA1Update(&h1, rgbBuff1, sizeof(rgbBuff1));
    SHA1Update(&h2, rgbBuff2, sizeof(rgbBuff2));

    // finish the hashes and copy them into BaseVal
    memset(rgbBuff1, 0, sizeof(rgbBuff1));
    SHA1Final(rgbBuff1, &h1);

    memset(rgbBuff2, 0, sizeof(rgbBuff2));
    SHA1Final(rgbBuff2, &h2);

    // SHA1 gives only a 20 byte buffer.
    memcpy(hashval, rgbBuff1, 20);
    memcpy(hashval+20, rgbBuff2, 4);
}

void generate_random_value( BYTE *r1, size_t len)
{

	FILE * fp = fopen ("/dev/urandom" , "rb" );

	if ( NULL == fp )
		{
			srandom ( time (NULL) );

			for ( int count = 0 ; count < len ; count += 4, r1 = r1 + 4 )
				*(DWORD *)r1 = (*(DWORD *)r1)*43 + time(NULL) + (random()>>16);
		}
	else
		{
			for ( int count = 0 ; count < len ; count += 4 , r1 = r1 + 4 )
				fread ( (DWORD*) r1, sizeof(DWORD), 1, fp);
		}

}

DWORD 
CSecurePswdSync::EncryptData(
    LPCSTR UserName,
    LPCSTR Password,
    LPBYTE &lpBuffer,
    DWORD *dwCurrentBufferLen,
    UINT   uiMsgType
)
{
    BYTE KeyIn[3*DES_BLOCKLEN];
    DES3TABLE KeyTable;
    DWORD dwErr = 0;
    LPBYTE lpData;
    DWORD dwEncryptDataLen;
    DWORD dwBufferLen;
    UINT count; BYTE *pOut, *pIn;
    char szBuffer[MAX_BUFFER_SIZE + 1];

    generate_random_value( (BYTE*)m_R2, RANDOM_VALUE_LEN);

    make_hash(KeyIn, (BYTE*)m_R1, (BYTE*)m_R2, 0, 0);
    extend_hash_forkey(KeyIn);

    tripledes3key( &KeyTable, KeyIn );

    // total size of the buffer to encrypt.
    dwEncryptDataLen =  strlen(UserName) + 1 +     // The User Name
                        strlen(Password) + 1 +     // The password
                        20;                 // The Hash Value to verify the Encryption.

    dwEncryptDataLen += (8 - (dwEncryptDataLen) % 8 );  // round it off to 8 byte boundaries.

    dwBufferLen = dwEncryptDataLen + RANDOM_VALUE_LEN;       // The R2 value
                   
    lpBuffer = (LPBYTE)calloc((unsigned int)(*dwCurrentBufferLen + dwBufferLen), sizeof(BYTE) );
    if ( lpBuffer == NULL )
    {
        //LogError(MSG_MEMORY_ERROR, "EncryptData");

		snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_MEMORY_ALLOCATION_ERROR_FOR_ENCRYPT_DATA,IDS_ERROR,strerror(errno));
		printMessages(LOGERR,szBuffer);
		
        return errno;
    }

    memcpy(lpBuffer + *dwCurrentBufferLen, (BYTE*)m_R2, RANDOM_VALUE_LEN);

    BYTE *pTemp;

    lpData = (LPBYTE)calloc(dwEncryptDataLen,sizeof(BYTE));
    if ( lpData == NULL )
    {
        free(lpBuffer);
        lpBuffer = NULL;
        //LogError(MSG_MEMORY_ERROR, "EncryptData");
		snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_MEMORY_ALLOCATION_ERROR_FOR_ENCRYPT_DATA,IDS_ERROR,strerror(errno));
		printMessages(LOGERR,szBuffer);
		
        return errno;
    }

    // now do the encryption for real
    pTemp = lpData;
    strlcpy((char *)pTemp, UserName, dwEncryptDataLen);
    pTemp += strlen(UserName) +1;
    strlcpy((char *)pTemp, Password, dwEncryptDataLen-strlen(UserName));
    pTemp += strlen(Password) +1;

    // Convert KeyTable to network order of bytes 
    DES3TABLE TempTable;
    for ( count = 0; count < sizeof(DES3TABLE)/sizeof(unsigned long) ; count++ )
        ((unsigned long *)&TempTable)[count] = htonl(((unsigned long *)&KeyTable)[count]);

    GenerateHashForSending(pTemp, &TempTable, htonl(MEPP_VERSION), htonl(*dwCurrentBufferLen + dwBufferLen), htonl(uiMsgType), UserName, Password);

    for ( count = 0, 
          pOut = lpBuffer + *dwCurrentBufferLen + RANDOM_VALUE_LEN,
          pIn = lpData; 
            
            count < dwEncryptDataLen ; 

            count += 8, pOut += 8, pIn += 8 )
    {
        tripledes(pOut, pIn, &KeyTable, ENCRYPT);
    }

    free(lpData);

    // update the current buffer len
    *dwCurrentBufferLen += dwBufferLen;
    return 0;
}

#else 

DWORD 
CSecurePswdSync::EncryptData(	
    LPCSTR UserName,
    LPCSTR Password,
    LPBYTE &lpBuffer,
    DWORD *dwCurrentBufferLen,
    UINT   uiMsgType
)
{
    DWORD dwBufLen = strlen(UserName) + strlen(Password) + 2;

    char szBuffer[MAX_BUFFER_SIZE + 1];
                   
    lpBuffer = (LPBYTE)calloc(*dwCurrentBufferLen + dwBufLen, sizeof(BYTE));
    if ( lpBuffer == NULL )
    {
        //LogError(MSG_MEMORY_ERROR, "EncryptData");
        
        snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_MEMORY_ALLOCATION_ERROR_FOR_ENCRYPT_DATA,IDS_ERROR,strerror(errno));
		printMessages(LOGERR,szBuffer);
		
        return errno;
    }

    strlcpy((LPSTR) lpBuffer + *dwCurrentBufferLen, UserName, dwBufLen);
    strlcpy((LPSTR) lpBuffer + *dwCurrentBufferLen + strlen(UserName) + 1, Password, dwBufLen-strlen(UserName));

    (*dwCurrentBufferLen)+= dwBufLen;

    return 0;
}

#endif // NO_ENCRYPTION
