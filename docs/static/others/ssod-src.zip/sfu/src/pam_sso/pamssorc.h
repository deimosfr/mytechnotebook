/****************************************************************************/
/*                                                                          */
/*   pamssorc.h                                                             */
/*   Error messages                                                         */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _PAMSSO_RC_H_
#define _PAMSSO_RC_H_

const char*	IDS_ERROR_READING_CONF_FILE="Error reading confog file";
const char*	IDS_BREAKING_THE_PASSWD_SYNC_LOOP="Breaking the password sync loop from NT to UNIX";
const char* 	IDS_UNKNOWN_FLAG_FOUND="Unknown flag found";
const char*	IDS_UNKNOWN_OPTION="Unknown option";
const char* 	IDS_PASSWORD_FOR_USER_FAILED_TO_SYNC="Password for user failed to sync";
const char*   IDS_PASSWORD_FOR_USER_SYNCED_SUCCESSFULLY="Password for user synced successfully";

#endif // _PAMSSO_RC_H
