/****************************************************************************/
/*                                                                          */
/*   configrc.h                                                             */
/*   Error messages                                                         */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _CONFIG_RC_H_
#define _CONFIG_RC_H_

const char* 	IDS_FILE_NOT_FOUND="Files not found";
const char* 	IDS_UNKNOWN_ERROR_OCCURED="Unknown error occurred";
const char* 	IDS_NOT_ALL_ELEMENTS_SET="Not all elements set";
const char*	IDS_NIS_UPDATE_PATH_REQUIRED="Nis update path required";
const char*	IDS_FULL_PATH_REQUIRED_FOR_NIS_UPDATE_FIELD="Full path required for nis update field";
const char*	IDS_SHADOW_OPTION_NOT_SUPPORTED_ON_HPUX="Shadow option not supported on HP-UX";
const char*	IDS_LINE_TOO_LONG="Line too long";
const char*	IDS_INCORRECT_SYNTAX_FOR_FILE_PATH="Incorrect syntax for file path";
const char*	IDS_FILE_PATH_VALUE_TOO_LONG="File path value too long";
const char*	IDS_ERROR_READING_FILE_PATH_VALUE="Error reading file path value";
const char*	IDS_ERROR_LOCATING_FILE="Error locating file";
const char*	IDS_INCORRECT_SYNTAX_FOR_USE_SHADOW="Incorrect syntax for use shadow";
const char* 	IDS_ERROR_READING_SHADOW_TYPE="Error reading shadow type";
const char*	IDS_INCORRECT_SYNTAX_FOR_CASE_IGNORE_NAME="Incorrect syntax for case ignore name";
const char*	IDS_ERROR_READING_CASE_SENSITIVE_TYPE="Error reading case sensitive type";
const char*	IDS_INCORRECT_SYNTAX_FOR_PORT_NUMBER="Incorrect syntax for port number";
const char*	IDS_ERROR_READING_PORT_NUMBER="Error reading port number";
const char*	IDS_INCORRECT_SYNTAX_FOR_USE_NIS="Incorrect syntax for use nis";
const char* 	IDS_ERROR_READING_NIS_TYPE="Error reading nis type";
const char*	IDS_USE_NIS_NEED_BE_DEFINED_BEFORE_NIS_UPDATE_PATH_VARIABLE="Use nis need be defined before nis update path variable";
const char*	IDS_INCORRECT_SYNTAX_FOR_NIS_UPDATE_PATH="Incorrect syntax for nis update path variable";
const char*	IDS_NIS_UPDATE_PATH_VALUE_TOO_LONG="Nis update path value too long";
const char*	IDS_ERROR_READING_NIS_UPDATE_PATH="Error reading nis update path";
const char*	IDS_ERROR_LOCATING_NIS_UPDATE_FILE="Error locating nis update file";
const char*	IDS_INCORRECT_SYNTAX_FOR_TEMP_FILE_PATH="Incorrect syntax for temp file path";
const char*	IDS_TEMP_FILE_PATH_VALUE_TOO_LONG="Temp file path value too long";
const char*	IDS_ERROR_READING_TEMP_FILE_PATH="Error reading temp file path";
const char*	IDS_ERROR_LOCATING_TEMP_FILE_PATH="Error locating temp file path";
const char*	IDS_INCORRECT_SYNTAX_FOR_ENCRYPT_KEY="Incorrect syntax for encryption key";
const char*	IDS_INCORRECT_CHARACTERS_IN_ENCRYPT_KEY="Incorrect characters in encryption key";
const char* 	IDS_ENCRYPTION_KEY_LENGTH_WRONG="Encryption key length should be between 16 and 21";
const char*	IDS_ERROR_READING_ENCRYPTION_KEY="Error reading encryption key";
const char*	IDS_INCORRECT_SYNTAX_FOR_SYNC_HOSTS="Incorrect syntax for syntax hosts";
const char*	IDS_ERROR_READING_SYNC_HOSTS="Error reading sync hosts";
const char*	IDS_INCORRECT_SYNTAX_FOR_SYNC_USERS="Incorrect syntax for sync users";
const char*	IDS_ERROR_READING_SYNC_USERS="Error reading sync users";
const char*	IDS_INCORRECT_SYNTAX_FOR_SYNC_RETRIES="Incorrect syntax for sync retries";
const char*	IDS_ERROR_READING_SYNC_RETRIES="Error reading sync retries";
const char*	IDS_INCORRECT_SYNTAX_FOR_SYNC_DELAY="Incorrect syntax for sync delay";
const char*	IDS_ERROR_READING_SYNC_DELAY="Error reading sync delay";
const char*	IDS_INVALID_LEFT_BRACE_FOUND_IN_SYNC_HOSTS_VALUES="Invalid \'(\' found in sync hosts values";
const char*	IDS_INVALID_RIGHT_BRACE_FOUND_IN_SYNC_HOSTS_VALUES="Invalid \')\' found in sync hosts values";
const char*	IDS_INVALID_COMMA_FOUND_IN_SYNC_HOSTS_VALUES="Invalid \',\' found in sync hosts values";
const char*	IDS_INVALID_CHARACTERS_FOUND_IN_SYNC_HOSTS_VALUES="Invalid characters found in sync hosts values";
const char* 	IDS_MISSING_RIGHT_BRACE_IN_SYNC_HOSTS_VALUES="Missing \')\' in sync hosts values";
const char*	IDS_EXTRA_PARAMETERS_AFTER_ENCRYPTION_KEY_IN_SYNC_HOSTS_VALUES="Extra parameters after encryption key in sync hosts values";
const char*	IDS_EMPTY_SYNC_USERS_LIST_FOUND="Empty sync users list found";
const char*	IDS_ILLEGAL_SYNC_USERS_FOUND="Illegal sync users found";
const char*	IDS_PASSWORD_SYNC_FOR_USER_DISALLOWED_BY_SYSTEM_ADMIN="Password sync for user disallowed by system admin. Add this user to the /etc/sso.conf file";
const char*	IDS_ENCRYPTION_KEY_LENGTH_SHOULD_BE_BETWEEN_THE_FOLLOWING_VALUES="Encryption key length should be between the following values: ";
const char*	IDS_USER="User: ";
const char*	IDS_MAX="Max: ";
const char*	IDS_MIN="Min: ";
const char*	IDS_ENCRYPTION_KEY_MUST_CONTAIN_CHARACTERS_FROM_AT_LEAST_THREE_OF_THE_FOLL_FOUR_GROUPS="Encryption key must contain characters from at least three of the follwing four groups: ";
const char*	IDS_UPPERCASE="1) Upper-case English letters (A, B...Z),\n";
const char*	IDS_LOWERCASE="2) Lower-case English letters (a, b...z),\n";
const char*	IDS_NUMERALS="3) Westernized Arabic numerals (0, 1, 2...9),\n";
const char*	IDS_PUNC_SYMBOLS="4) Punctuation symbols ( ` ~ ! @ # $ % ^ & * _ - + = | \\ { } [ ] : ; \" ' < > , . ? )\n";
const char*	IDS_LINE="Line: ";
const char*	IDS_PATH="Path: ";
const char*   IDS_PASSWORD_LENGTH_LESSER_THAN_REQUIRED="Password length lesser than required. Check the /etc/default/passwd file";
const char*   IDS_INCORRECT_SYNTAX_FOR_PASSLENGTH="Incorrect syntax for passlength";
const char*   IDS_INCORRECT_SYNTAX_FOR_IGNORE_PROPAGATION_ERRORS="Incorrect syntax for ignore propgatation errors flag. Please look in the sample sso.conf file.";

#endif // _CONFIG_RC_H_


