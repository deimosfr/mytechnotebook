/****************************************************************************/
/*                                                                          */
/*   rotlr.cpp                                                              */
/*                                                                          */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef _MESSAGES_H_
#define _MESSAGES_H_

#include <stdio.h>
#include <syslog.h>

#define COUT      0
#define CERR      1
#define LOGERR    2
#define LOGINFO   3
#define LOGDEBUG  4
#define LOGWARN   5
#define LOGCRIT   6
#ifdef AIX
size_t strlcpy(char *dst, const char *src, size_t siz);
#endif

#endif // _MESSAGES_H_
