/****************************************************************************/
/*                                                                          */
/*   config.cpp                                                             */
/*   Reads configuration file                                               */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#include "configrc.h"
#include "config.h"
#include "messages.h"
#include<stdio.h>

extern "C" int strcasecmp(const char *s1, const char *s2);
extern "C" size_t strlcpy(char *dst, const char *src, size_t siz);
extern "C" void printMessages(int msgType,const char* str);
#ifndef aix42
#if defined(__linux__) && defined(__GNUG__) && defined(__amd64__) && \
    (defined __USE_BSD || defined __USE_ISOC99 || defined __USE_UNIX98)
#else
extern "C" int snprintf (char * , unsigned int num,const char *,...); 
#endif
#endif
#ifdef AIX
size_t
strlcpy(char *dst, const char *src, size_t siz)
{
         char *d = dst;
         const char *s = src;
         size_t n = siz;


        if (n != 0 && --n != 0) {
                do {
                        if ((*d++ = *s++) == 0)
                                break;
                } while (--n != 0);
        }


        if (n == 0) {
                if (siz != 0)
                        *(d) = '\0';
                while (*s++)
                        ;
        }
        return(s - src - 1);
}
#endif
#ifdef SSOD_DEF
BOOL conformToPassLength(BOOL fAdmin, int nPassLength)
{

    char   line[MAXLINELENGTH], *pstr;
    FILE*   fp;

    int retVal = TRUE;
    //char szBuffer[MAX_BUFFER_SIZE + 1];

    if (fAdmin == TRUE) // overrides default
        return TRUE;
    
    if ((fp = fopen(SSOD_PASSLENGTH_FILE, "r")) == NULL)
    {
    	printMessages(LOGERR,IDS_FILE_NOT_FOUND);
        return FALSE;
    }

    while (TRUE)
    {
        if (fgets(line, MAXLINELENGTH, fp) == NULL)
        { 
			
            if (!feof(fp))
            {
            	printMessages(LOGERR,IDS_UNKNOWN_ERROR_OCCURED);
                retVal = FALSE;
                break;
            }

            break;
        }


		line[strlen(line)-1] = '\0';
        pstr = line;
        

        while (*pstr == ' ' || *pstr == '\t') pstr++;
        if (*pstr == '#' || *pstr == '\n' || *pstr == '\r' || *pstr == '\0') continue;
		
        if (strncmp(pstr, "PASSLENGTH", strlen("PASSLENGTH")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printMessages(LOGERR,IDS_INCORRECT_SYNTAX_FOR_PASSLENGTH);
                retVal = FALSE;
                break;
            }

            pstr++;

            if (atoi(pstr) > 0 && nPassLength < atoi(pstr))
            {
                printMessages(LOGERR,IDS_PASSWORD_LENGTH_LESSER_THAN_REQUIRED);
                retVal = FALSE;
                break;
            }

        }
    }


    fclose(fp);
    return retVal;

}
#endif

int
getConfiguration(Globals* p_instance)
{

	
    char   line[MAXLINELENGTH], *pstr;
    FILE*   fp;

	#ifdef SSOD_DEF
    char   file_path[MAXPATHLENGTH], temp_file_path[MAXPATHLENGTH]; 
    char   szEncryptionKey[MAXSECRETLEN], nis_update_path[MAXPATHLENGTH];
    unsigned int  use_shadow    = DEFAULT_USE_SHADOW, 
                port_number    = DEFAULT_PORT,
                fCaseIgnore    = DEFAULT_CASE_IGNORE_NAME,
                fPamSupported  = DEFAULT_PAM_SUPPORTED ;
    
    int          use_nis        = -1; 
	#endif
	
    unsigned int  flag=0;
    unsigned int  line_number=0;

	#ifdef PAM_DEF
    int          cFields=-1;
	#endif
    
	char *pLeftBr,*pComma,*pRightBr;
    int retVal = SUCCESS;

    char szBuffer[MAX_BUFFER_SIZE + 1];

	#ifdef PAM_DEF
	TRACE("entered");
	#endif

	#ifdef PAM_DEF
    if (p_instance->fReadConfig == FALSE)
    {
        //
        // Configuration already read, already, so, don't bother
        //
        return PAM_SUCCESS;
    }
    
	// set these defaults
       
    strlcpy((char*)p_instance->szEncryptionKey, SSO_DEFAULT_ENCRYPTION_KEY, sizeof(p_instance->szEncryptionKey));

   	TRACEV("p_instance->szEncryptionKey=%s", p_instance->szEncryptionKey);

    p_instance->dwPortNumber = SSO_DEFAULT_PORT;

	#endif

    // This is required since multiple SYNC_HOST
    // entries will be present in the sso.conf file.
    p_instance->pHostList = NULL;

    // This is required since multiple SYNC_USERS
    // entries will be present in the sso.conf file.
    p_instance->pSyncObjList = NULL;

	
    if ((fp = fopen(SSOD_CONFIG_FILE, "r")) == NULL)
    {
    	printMessages(LOGERR,IDS_FILE_NOT_FOUND);
        return ERROR;
    }

    while (TRUE)
    {
        if (fgets(line, MAXLINELENGTH, fp) == NULL)
        { 
			
            if (!feof(fp))
            {
            	printConfigurationErrorMessages(IDS_UNKNOWN_ERROR_OCCURED);
                retVal = ERROR;
                break;
            }

			#ifdef SSOD_DEF
            if ((flag & ALL_SET) != ALL_SET)
            {
                printConfigurationErrorMessages(IDS_NOT_ALL_ELEMENTS_SET);
                retVal = FALSE;
                break;
            }
            #endif

            #ifdef PAM_DEF
            if ((flag & MUST_PAMSSO_SET) != MUST_PAMSSO_SET)
			{
                    printConfigurationErrorMessages(IDS_NOT_ALL_ELEMENTS_SET);
					retVal = FALSE;
    				break;
			}
			#endif

			retVal = SUCCESS;
            
			#ifdef SSOD_DEF
			
            if (use_nis == 1)
            {
                if ((flag & NIS_UPDATE_PATH_SET) != NIS_UPDATE_PATH_SET)
                {
                    printConfigurationErrorMessages(IDS_NIS_UPDATE_PATH_REQUIRED);
                    retVal = FALSE;
                    break;
                }

                if (strchr(nis_update_path, '/') == NULL)
                {
                    printConfigurationErrorMessages(IDS_FULL_PATH_REQUIRED_FOR_NIS_UPDATE_FIELD);
                    retVal = FALSE;
                    break;
                }
            }

            #ifdef hp700_ux10

            if (use_shadow == 1)
            {
                printConfigurationErrorMessages(IDS_SHADOW_OPTION_NOT_SUPPORTED_ON_HPUX);
                retVal = ERROR;
                break;
            }

			#endif // hp700_ux10

            // Update the actual formal parameters now
            p_instance->file_path_ = new char [strlen(file_path)+1];
            strcpy(p_instance->file_path_, file_path);
            p_instance->temp_path_ = new char [strlen(temp_file_path)+1];
            strcpy(p_instance->temp_path_, temp_file_path);
            strlcpy((char*)p_instance->szEncryptionKey, szEncryptionKey, sizeof(p_instance->szEncryptionKey));
            p_instance->use_shadow_  = use_shadow;
            p_instance->caseignore_name_ = fCaseIgnore;
            p_instance->pam_supported_ = fPamSupported;
            p_instance->use_NIS_ = (use_nis == 1);
            p_instance->dwPortNumber = port_number;

            if (use_nis == 1)
            {
                // copy the NIS update path string
                p_instance->NIS_update_path_ = new char [strlen(nis_update_path)+1];
                strcpy(p_instance->NIS_update_path_, nis_update_path);
            }

            //retVal = TRUE;

			#endif
			
            break;
        }

    	line_number++;

        if (line[strlen(line)-1] != '\n')
        {
        	snprintf(szBuffer, sizeof(szBuffer), "%s %s %d",IDS_LINE_TOO_LONG,IDS_LINE,line_number);
        	printConfigurationErrorMessages(szBuffer);
            retVal = ERROR;
            break;
        }

		line[strlen(line)-1] = '\0';
        pstr = line;
        

        while (*pstr == ' ' || *pstr == '\t') pstr++;
        if (*pstr == '#' || *pstr == '\n' || *pstr == '\r' || *pstr == '\0') continue;

		#ifdef SSOD_DEF
		
        if (strncmp(pstr, "FILE_PATH", strlen("FILE_PATH")) == 0)
        {
            struct stat mystat;

            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_FILE_PATH);
                retVal = ERROR;
                break;
            }

            pstr++;

            if (strlen(pstr) > MAXPATHLENGTH)
            {
                printConfigurationErrorMessages(IDS_FILE_PATH_VALUE_TOO_LONG);
                retVal = ERROR;
                break;
            }

            if (sscanf(pstr, "%s", file_path) <= 0)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_FILE_PATH_VALUE);
                retVal = ERROR;
                break;
            }

            if (stat(file_path, &mystat) != 0)
            {
            	snprintf(szBuffer, sizeof(szBuffer), "%s %s %s",IDS_ERROR_LOCATING_FILE,IDS_PATH,file_path);
                printConfigurationErrorMessages(szBuffer);
                retVal = ERROR;
                break;
            }

            flag |= FILE_PATH_SET;
            continue;
        }

        if (strncmp(pstr, "USE_SHADOW", strlen("USE_SHADOW")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_USE_SHADOW);
                retVal = ERROR;
                break;
            }

            pstr++;
            if (sscanf(pstr, "%d", &use_shadow) <= 0 || use_shadow > 1)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_SHADOW_TYPE);
                retVal = ERROR;
                break;
            }

            continue;
        }

        // CASE_IGNORE_NAME == 1 => case insensitive. 0=> case sensitive.
        // default is 1 (case insensitive).
        //

        if (strncmp(pstr, "CASE_IGNORE_NAME", strlen("CASE_IGNORE_NAME")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
     			printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_CASE_IGNORE_NAME);
                retVal = ERROR;
                break;
            }

            pstr++;
            if (sscanf(pstr, "%d", &fCaseIgnore) <= 0 || fCaseIgnore > 1)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_CASE_SENSITIVE_TYPE);
                retVal = ERROR;
                break;
            }

            continue;
        }

        if (strncmp(pstr, "PORT_NUMBER", strlen("PORT_NUMBER")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_PORT_NUMBER);
                retVal = ERROR;
                break;
            }

            pstr++;
            if (sscanf(pstr, "%d", &port_number) <= 0)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_PORT_NUMBER);
                retVal = ERROR;
                break;
            }
            continue;
        }

        if (strncmp(pstr, "USE_NIS", strlen("USE_NIS")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
            	printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_USE_NIS);
                retVal = ERROR;
                break;
            }

            pstr++;
            if (sscanf(pstr, "%d", &use_nis) <= 0 || use_nis > 1)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_NIS_TYPE);
                retVal = ERROR;
                break;
            }

            continue;
        }

        if (strncmp(pstr, "NIS_UPDATE_PATH", strlen("NIS_UPDATE_PATH")) == 0)
        {
            struct stat mystat;

            // We require USE_NIS to be defined before the NIS_UPDATE_PATH, this is
            // because this value is dependent upon USE_NIS being set to 0 or 1.
            if ( use_nis == -1 )
            {
                printConfigurationErrorMessages(IDS_USE_NIS_NEED_BE_DEFINED_BEFORE_NIS_UPDATE_PATH_VARIABLE);
                retVal = ERROR;
                break;
            }

            if ( use_nis == 0 )
            {
                // we don't care about the NIS_UPDATE_PATH.
                continue;
            }

            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_NIS_UPDATE_PATH);
                retVal = ERROR;
                break;
            }

            pstr++;

            if (strlen(pstr) > MAXPATHLENGTH)
            {
                printConfigurationErrorMessages(IDS_NIS_UPDATE_PATH_VALUE_TOO_LONG);
                retVal = ERROR;
                break;
            }

            if (sscanf(pstr, "%s", nis_update_path) <= 0)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_NIS_UPDATE_PATH);
                retVal = ERROR;
                break;
            }

            if (stat(nis_update_path, &mystat) != 0)
            {
            	snprintf(szBuffer, sizeof(szBuffer), "%s %s %s",IDS_ERROR_LOCATING_NIS_UPDATE_FILE,IDS_PATH,nis_update_path);
                printConfigurationErrorMessages(szBuffer);
                retVal = ERROR;
                break;
            }

            flag |= NIS_UPDATE_PATH_SET;
            continue;
        }

        if (strncmp(pstr, "TEMP_FILE_PATH", strlen("TEMP_FILE_PATH")) == 0)
        {
            struct stat mystat;

            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_TEMP_FILE_PATH);
                retVal = ERROR;
                break;
            }

            pstr++;

            if (strlen(pstr) > MAXPATHLENGTH)
            {
                printConfigurationErrorMessages(IDS_TEMP_FILE_PATH_VALUE_TOO_LONG);
                retVal = ERROR;
                break;
            }

            if (sscanf(pstr, "%s", temp_file_path) <= 0)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_TEMP_FILE_PATH);
                retVal = ERROR;
                break;
            }

            if (stat(temp_file_path, &mystat) != 0)
            {
            	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_ERROR_LOCATING_TEMP_FILE_PATH,IDS_PATH,temp_file_path);
                printConfigurationErrorMessages(szBuffer);
                retVal = ERROR;
                break;
            }

            flag |= TEMP_FILE_PATH_SET;
            continue;
        }
        #endif

        if (strncmp(pstr, "ENCRYPT_KEY", strlen("ENCRYPT_KEY")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
            	printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_ENCRYPT_KEY);
                retVal = ERROR;
                break;
            }

            pstr++;

            pLeftBr = strchr(pstr,'(');
            pComma = strchr(pstr,',');
            pRightBr = strchr(pstr,')');

            if (pLeftBr != NULL || pComma != NULL || pRightBr != NULL)
            {
            	printConfigurationErrorMessages(IDS_INCORRECT_CHARACTERS_IN_ENCRYPT_KEY);
                retVal = ERROR;
                break;
            }
		

            if (strlen(pstr) >= MAXSECRETLEN || strlen(pstr) < MINSECRETLEN)
            {
            	snprintf(szBuffer, sizeof(szBuffer),"%s",IDS_ENCRYPTION_KEY_LENGTH_WRONG);
            	printConfigurationErrorMessages(szBuffer);
                retVal = ERROR;
                break;
            }

	    #ifdef SSOD_DEF
            if (sscanf(pstr, "%s", szEncryptionKey) <= 0)
	    #else
            if (sscanf(pstr, "%s", p_instance->szEncryptionKey) <= 0)
	    #endif
            {
            	printConfigurationErrorMessages(IDS_ERROR_READING_ENCRYPTION_KEY);
                retVal = ERROR;
                break;
            }

            // check that encrypt key follows the required restrictions on
            // length and character set
            //

            if (!isValidSyntaxEncryptKey(pstr))
            {
                retVal = ERROR;
                break;
            }

            flag |= ENCRYPT_KEY_SET;
            continue;
        }

        if (strncmp(pstr, "SYNC_HOSTS", strlen("SYNC_HOSTS")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
            	printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_SYNC_HOSTS);
                retVal = ERROR;
                break;
            }

            pstr++;

            //
            //    parse for sync hosts
            //

            if (getSyncHosts(p_instance, pstr) == ERROR)
            {
            	printConfigurationErrorMessages(IDS_ERROR_READING_SYNC_HOSTS);
                retVal = ERROR;
                break;
            }

            flag |= SYNC_HOSTS_SET;
            continue;
        }

        if (strncmp(pstr, "SYNC_USERS", strlen("SYNC_USERS")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
            	printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_SYNC_USERS);
                retVal = ERROR;
                break;
            }

            pstr++;
            
            //
            //    parse sync users and prepare sync and nosync list
            //

            if (getSyncUsers(p_instance, pstr) == ERROR)
            {
            	printConfigurationErrorMessages(IDS_ERROR_READING_SYNC_USERS);
                retVal = ERROR;
                break;
            }

            flag |= SYNC_USERS_SET;
            continue;
        }

		#ifdef PAM_DEF
		
        if (strncmp(pstr, "PORT_NUMBER", strlen("PORT_NUMBER")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_PORT_NUMBER);
                retVal = ERROR;
                break;
            }

            pstr++;

            cFields = sscanf(pstr, "%d", &p_instance->dwPortNumber);
            if (cFields <= 0 || cFields == EOF )
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_PORT_NUMBER);
                retVal = ERROR;
                break;
            }

            flag |= PORT_NUMBER_SET;

            TRACEV("port number = %d",p_instance->dwPortNumber);

            continue;
        }

        if (strncmp(pstr, "SYNC_RETRIES", strlen("SYNC_RETRIES")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_SYNC_RETRIES);
                retVal = ERROR;
                break;
            }

            pstr++;

            cFields = sscanf(pstr, "%d", &p_instance->nSyncRetries);
            if (cFields != 1)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_SYNC_RETRIES);
                retVal = ERROR;
                break;
            }

            flag |= SYNC_RETRIES_SET;

            TRACEV("sync retries = %d",p_instance->nSyncRetries);

            continue;
        }

        if (strncmp(pstr, "SYNC_DELAY", strlen("SYNC_DELAY")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_SYNC_DELAY);
                retVal = ERROR;
                break;
            }

            pstr++;

            cFields = sscanf(pstr, "%d", &p_instance->nSyncDelay);
            if (cFields != 1)
            {
                printConfigurationErrorMessages(IDS_ERROR_READING_SYNC_DELAY);
                retVal = ERROR;
                break;
            }

            flag |= SYNC_DELAY_SET;

            TRACEV("sync delay = %d",p_instance->nSyncDelay);

            continue;
        }

        if (strncmp(pstr, "IGNORE_PROPAGATION_ERRORS", strlen("IGNORE_PROPAGATION_ERRORS")) == 0)
        {
            if ((pstr = strchr(pstr, '=')) == NULL)
            {
                printConfigurationErrorMessages(IDS_INCORRECT_SYNTAX_FOR_IGNORE_PROPAGATION_ERRORS);
                retVal = ERROR;
                break;
            }

            pstr++;

            if (!strcmp(pstr,"TRUE") || !strcmp(pstr,"1"))
                p_instance->fIgnorePropErrors = TRUE;

            TRACE("IGNORE_PROPAGATION_ERRORS flag set");

            continue;
        }

       	#endif



        // IGNORE all undefined types. may be used by other programs like PAM_SSO

        // Undefined type
        // cout << SSOD_CFG_ERROR_MSG << "undefined type is line " << line_number << endl;
        // retVal = ERROR;
        // break;
    } // end of while loop

    memset(line, 0, MAXLINELENGTH);

    //
    //    while building the list use the rules to add to the list or not
    //    if +ALL found, no +<user> is added
    //    some -<user> allowed, only if +ALL is found
    //    Alist can contain only these 4 types
    //    +ALL
    //    +ALL, -x,-y
    //    -ALL
    //    +x,+y,+z

    //     +ALL,+a+b   no error flagged for a,b . same as +ALL
    //    +ALL , -ALL error
    //    -ALL, +x,+y  equates to -ALL
    //    +a, -a is error

    if (retVal != ERROR)
        retVal = trimAndValidateSyncObjList(p_instance);
  

    #ifdef PAM_DEF

    p_instance->fReadConfig = FALSE;
    if (retVal == ERROR)
    {
    	// free all memory allocated
    	freeGlobalElements(p_instance);
    }
    #endif
    
    fflush(fp);
    fclose(fp);
    
    return retVal;
}


int
getSyncHosts(Globals* pInstance, const char*    pstr)
{
    
    BOOL    fLeftBraceFound = FALSE,
            fRightBraceFound = FALSE;

    BOOL    fHostNameFound = FALSE,
            fHostPortFound = FALSE,
            fHostKeyFound  = FALSE,
            fBreak = FALSE;

    char    szBuffer[MAX_BUFFER_SIZE + 1];

    HOST_LIST*    pHost = NULL;

	char    *pStr2    = NULL;
    char    *pComma = NULL;
    char	*pRightBr = NULL,*pRightBr2 = NULL;
    char	*pLeftBr  = NULL;

	int      ret = SUCCESS;
		
    while (*pstr == ' ' || *pstr == '\t') 
        pstr++;

    while (*pstr != '\n' && *pstr != '\r' && *pstr != '\0') 
    {
        pHost = new (HOST_LIST);
        if (NULL == pHost)
            break;        
        pHost->pNext = pInstance->pHostList;
        pInstance->pHostList = pHost;

        pHost->dwPort =  pInstance->dwPortNumber;
        pHost->pszEncryptionKey = NULL;

        while (TRUE) // get one host entry
        {
            while (*pstr == ' ' || *pstr == '\t') 
                pstr++;

            if (*pstr == '(')
            {
                if (fLeftBraceFound == TRUE)
                {
		    		printMessages(LOGERR,IDS_INVALID_LEFT_BRACE_FOUND_IN_SYNC_HOSTS_VALUES);
                    fBreak = TRUE;
                    break;
                }

                fLeftBraceFound = TRUE;

                fHostNameFound = FALSE,
                fHostPortFound = FALSE,
                fHostKeyFound  = FALSE;

                pstr++;
            }
            else if (*pstr == ')')
            {
                if (fLeftBraceFound == FALSE)
                {
		    		printMessages(LOGERR,IDS_INVALID_RIGHT_BRACE_FOUND_IN_SYNC_HOSTS_VALUES);
                    ret    = ERROR;
                    fBreak = TRUE;
                    break;
                }
                fLeftBraceFound = FALSE; // toggle the matching of last left brace

                pstr++;

                break; // one host entry found 
                       // find others

            }
            else if (*pstr == ',')
            {
                if (fLeftBraceFound == FALSE)
                {
		    		printMessages(LOGERR,IDS_INVALID_COMMA_FOUND_IN_SYNC_HOSTS_VALUES);
                    ret    = ERROR;
                    fBreak = TRUE;
                    break;
                }
                pstr++;
            }

            if (fLeftBraceFound == TRUE)
            {
                while (*pstr == ' ' || *pstr == '\t')  pstr++;

                if (*pstr == '\n' || *pstr == '\r' || *pstr == '\0') 
                    break;

                pComma      = strchr(pstr,',');
                pRightBr      = strchr(pstr,')');

                if (pRightBr == NULL) 
                {
		    		printMessages(LOGERR,IDS_MISSING_RIGHT_BRACE_IN_SYNC_HOSTS_VALUES);
                    ret    = ERROR;
                    fBreak = TRUE;
                    break;
                }

                if (fHostPortFound == TRUE) 
                {
                	pRightBr2 = NULL;
                	pStr2 = pRightBr+1;
                	pLeftBr = strchr(pstr,'(');
                	if (*pStr2 != '\0') 
                	{
                		pRightBr2 = strchr(pStr2,')');
                	}
                	if ((pComma != NULL && pComma < pRightBr) 
                	|| (pLeftBr   != NULL && pLeftBr < pRightBr)
                	|| (pRightBr2 != NULL && pRightBr2 < pLeftBr)
                	|| (pRightBr2 != NULL && pLeftBr == NULL))
                	{
		    			printMessages(LOGERR,IDS_INVALID_CHARACTERS_FOUND_IN_SYNC_HOSTS_VALUES);
                    	ret    = ERROR;
                    	fBreak = TRUE;
                    	break;
                    }
                }

                if (pComma  &&  (pComma < pRightBr))
                {
                    strncpy(szBuffer, pstr, pComma - pstr);
                    szBuffer[pComma - pstr] = '\0';
                    pstr = pComma;
                }
                else
                {
                    strncpy(szBuffer, pstr, pRightBr - pstr);
                    szBuffer[pRightBr - pstr] = '\0';
                    pstr = pRightBr;
                }

                //
                //    put the data found to appropriate host attribute
                //

                if (fHostNameFound == FALSE)
                {
                    fHostNameFound =TRUE;
                    pHost->pszHostName =new char[strlen(szBuffer) +1];
                    strcpy(pHost->pszHostName, szBuffer);
                }
                else if (fHostPortFound == FALSE)
                {
                    fHostPortFound = TRUE;

                    if (strlen(szBuffer))
                        sscanf(szBuffer, "%d", &pHost->dwPort);
                    else
                        pHost->dwPort = pInstance->dwPortNumber;
                }
                else if (fHostKeyFound == FALSE)
                {
                    fHostKeyFound = TRUE;

                    if (strlen(szBuffer))
                    {
	                   if (strlen(szBuffer) >= MAXSECRETLEN || strlen(szBuffer) < MINSECRETLEN)
                	   {
                            printMessages(LOGERR,IDS_ENCRYPTION_KEY_LENGTH_WRONG);
                            ret    = ERROR;
                            fBreak = TRUE;
                            break;
	                    }
                        pHost->pszEncryptionKey = new unsigned char[strlen(szBuffer) +1];
                        strcpy((char*)pHost->pszEncryptionKey, szBuffer);
                    }
                    else
                    {
                        pHost->pszEncryptionKey = new unsigned char[strlen((char*)pInstance->szEncryptionKey) +1];
                        strcpy((char*)pHost->pszEncryptionKey, (char*)pInstance->szEncryptionKey);
                    }
                }
                else
                {
		    		printMessages(LOGERR,IDS_EXTRA_PARAMETERS_AFTER_ENCRYPTION_KEY_IN_SYNC_HOSTS_VALUES);
                    ret    = ERROR;
                    fBreak = TRUE;
                    break;
                }
            }
        }

        while (*pstr == ' ' || *pstr == '\t') 
                pstr++;
                
        if (fBreak == TRUE)
        	break;
    }

	// if the user wants athe debug info
	// print the sync hosts
	//

	#ifdef PAM_DEF
	if (Globals::Instance()->fDebug)
	{
	 	pHost = pInstance->pHostList;

	    while (pHost)
	    {
	       	syslog(LOG_DEBUG,"HostName=%s", pHost->pszHostName);

	        syslog(LOG_DEBUG, "%d",pHost->dwPort);

	        if (pHost->pszEncryptionKey)
	          	syslog(LOG_DEBUG,"EncryptionKey=%s\n\n", (char*)pHost->pszEncryptionKey);
	        else
	            syslog(LOG_DEBUG, "EncryptionKey=%s\n\n", (char*)pInstance->szEncryptionKey);

	        pHost = pHost->pNext;
	      }
	}
	#endif
	
    return(ret);
}

int
getSyncUsers(Globals* pInstance, const char*    pstr)
{
    
    char    szBuffer[MAX_BUFFER_SIZE + 1];

    SYNC_OBJ_LIST*    pSyncObj = NULL;
    char*    pComma;
    char*    pTemp;
    int      Continue=1;
    
	int        ret = SUCCESS;

    memset(szBuffer, 0, MAX_BUFFER_SIZE);
	
    while (*pstr == ' ' || *pstr == '\t') 
        pstr++;

    while (*pstr != '\n' && *pstr != '\r' && *pstr != '\0' && Continue) 
    {   
        pSyncObj = new (SYNC_OBJ_LIST);
        if (NULL == pSyncObj)
            break;
        pSyncObj->pNext = pInstance->pSyncObjList;
        pInstance->pSyncObjList = pSyncObj;

        while (*pstr == ' ' || *pstr == '\t') 
            pstr++;

        if (*pstr == '-')
        {
        	while (*pstr == '+' || *pstr == '-') pstr++;
            pSyncObj->fSync = FALSE;
            //pstr++;
        }
        else if (*pstr == '+')
        {
        	while (*pstr == '+' || *pstr == '-') pstr++;
            pSyncObj->fSync = TRUE;
            //pstr++;
        }
        else
            pSyncObj->fSync = TRUE;

        pComma         = strchr(pstr,',');

        if (pComma)
        {
            strncpy(szBuffer, pstr, pComma - pstr);
            szBuffer[pComma - pstr] = '\0';

            // trim the white space  from the end from user name
            pTemp = strchr(szBuffer,' ');
            if (pTemp)
                *pTemp = '\0';

            pTemp = strchr(szBuffer,'\t');
            if (pTemp)
               *pTemp = '\0';

            pstr = pComma + 1;
        }
        else
        {
            strlcpy(szBuffer, pstr, sizeof(szBuffer));

            szBuffer[MAX_BUFFER_SIZE] = '\0';

            // trim the white space  from the end from user name
            pTemp = strchr(szBuffer,' ');
            if (pTemp)
                *pTemp = '\0';

            pTemp = strchr(szBuffer,'\t');
            if (pTemp)
               *pTemp = '\0';

            if (szBuffer[strlen(szBuffer) -1] == '\n' || szBuffer[strlen(szBuffer) -1] == '\r')
                szBuffer[strlen(szBuffer) -1] = '\0';
            pstr +=  strlen(szBuffer);

        // we have found the last user after last comma. No need to go further
	    Continue=0;
        }
            
        pSyncObj->pszSyncObjName = new char[strlen(szBuffer) +1];
        strcpy(pSyncObj->pszSyncObjName, szBuffer);
    }
    
    return(ret);
}

int
freeGlobalElements(Globals* pInstance)
{
    int    ret = SUCCESS;
    
    freeSyncObj(pInstance->pSyncObjList);
    pInstance->pSyncObjList = NULL;

    freeHostObj(pInstance->pHostList);
    pInstance->pHostList = NULL;

    return(ret);
}

int
trimAndValidateSyncObjList(Globals* pInstance)
{
    //
    //    while building the list use the rules to add to the list or not
    //    if +ALL found, no +<user> is added
    //    some -<user> allowed, only if +ALL is found
    //    Alist can contain only these 4 types
    //    +ALL
    //    +ALL, -x,-y
    //    -ALL
    //    +x,+y,+z

    //     +ALL,+a+b   no error flagged for a,b . same as +ALL
    //    +ALL , -ALL error
    //    -ALL, +x,+y  equates to -ALL
    //    +a, -a is error

    int    ret = SUCCESS;

    char szBuffer[MAX_BUFFER_SIZE + 1];

    BOOL    fPlusALLFound    =    FALSE;
    BOOL    fMinusALLFound    =    FALSE;

    SYNC_OBJ_LIST    
    		*pSync0,
            *pSync1, 
            *pSync1Prev  ; //prev pointer to pSync1;

    //    check there are no +x -x entries in the list
    //     remove if any duplicate found
	
    pSync0    =    pInstance->pSyncObjList;

    if (!pSync0)
    {
		printMessages(LOGERR,IDS_EMPTY_SYNC_USERS_LIST_FOUND);
        return(ERROR);
    }

    pSync1     =     pSync0->pNext;
    pSync1Prev =     pSync0;

    while (pSync0)
    {
        while(pSync1)
        {
            if ( !strcmp(pSync1->pszSyncObjName,pSync0->pszSyncObjName))
            {
                if (pSync1->fSync != pSync0->fSync)
                {
                    // illegal input +x and -x

					snprintf(szBuffer, sizeof(szBuffer),"%s %s +%s %s -%s",IDS_ILLEGAL_SYNC_USERS_FOUND,IDS_USER,pSync1->pszSyncObjName,
						IDS_USER,pSync1->pszSyncObjName);
		    		printMessages(LOGERR,szBuffer);

		    		// remove +foo. no point keeping him
		    		// disabling +foo in case +foo -foo is present

		    		if (TRUE == pSync0->fSync)
		    		    pSync0->fSync = FALSE;
		    		else pSync1->fSync = FALSE;
		    		
					// do not bail out. try other users
					//return(ERROR);

                }
                else
                {
                    // duplicate. free this

                    pSync1Prev->pNext = pSync1->pNext;

                    // free this node
                    pSync1->pNext = NULL ;
                    freeSyncObj(pSync1);

                    pSync1 = pSync1Prev->pNext;
                }
            }
            else
            {
                pSync1Prev = pSync1;
                pSync1 = pSync1->pNext;
            }
        }
       
        pSync0     = pSync0->pNext;
        pSync1Prev = pSync0;
        if (pSync0)
            pSync1     = pSync0->pNext;
    }

    
    // Validation is done. Now remove entries not necessary.

    pSync0 = NULL;
    pSync1 = pInstance->pSyncObjList;

    while(pSync1)
    {
        //    check if you found ALL
        if (!strcasecmp(pSync1->pszSyncObjName,"ALL") )
        {
            (pSync1->fSync == TRUE) ? fPlusALLFound = TRUE : fMinusALLFound = TRUE ;
        }
        pSync0 = pSync1; 
        pSync1 = pSync1->pNext;
    }



    //    if fPlusALLFound == TRUE, remove all entries where fSync == TRUE and  it is not 'ALL'

    if (fPlusALLFound)
    {
        pSync0 = NULL;
        pSync1 = pInstance->pSyncObjList->pNext;

        while(pSync1)
        {
                        // The node is not 'ALL'
            if ( (pSync1->fSync == TRUE) && 
                     strcasecmp(pSync1->pszSyncObjName,"ALL") )
            {
                if (!pSync0)
                {
                     pInstance->pSyncObjList->pNext = pSync1->pNext;

                    // free pSync1
                    pSync1->pNext = NULL;
                    freeSyncObj(pSync1);

                    pSync1 = pInstance->pSyncObjList->pNext;
                    pSync0 = NULL;
                }
                else
                {
                    pSync0->pNext = pSync1->pNext;

                    // free pSync1
                    // Just one node. so make next as null
                    pSync1->pNext = NULL ;
                    freeSyncObj(pSync1);

                    pSync1 = pSync0->pNext;
                }
            }
            else
            {
                pSync0 = pSync1;
                pSync1 = pSync1->pNext;
            }
        }
    }

    if (fMinusALLFound)
    {
        SYNC_OBJ_LIST* pSync1 = new (SYNC_OBJ_LIST);

        pSync1-> fSync = FALSE;
        pSync1->pszSyncObjName = new char [strlen("ALL") + 1];
        strcpy(pSync1->pszSyncObjName, "ALL");

        freeSyncObj(pInstance->pSyncObjList);
        pInstance->pSyncObjList = pSync1;
    }

    return SUCCESS;
}

int
freeSyncObj(SYNC_OBJ_LIST* pSync)
{
    int ret = SUCCESS;

    SYNC_OBJ_LIST   *pSyncObj1, *pSyncObj2;

    pSyncObj1 = pSync;

    while (pSyncObj1)
    {
        pSyncObj2 = pSyncObj1;
        pSyncObj1 = pSyncObj1->pNext;

        if ( pSyncObj2->pszSyncObjName)
            delete pSyncObj2->pszSyncObjName;

        pSyncObj2->pszSyncObjName = NULL;
        pSyncObj2 = NULL;
    }

    return(ret);
}
int
freeHostObj(HOST_LIST* pHost)
{
    int ret = SUCCESS;

    HOST_LIST        *pHost1, *pHost2;

    pHost1 = pHost;

    while (pHost1)
    {
        pHost2 = pHost1;
        pHost1 = pHost1->pNext;

        // free pHost2
        if ( pHost2->pszHostName)
            delete pHost2->pszHostName;

        if ( pHost2->pszEncryptionKey)
            delete pHost2->pszEncryptionKey;

        pHost2->pszHostName =  NULL;
        pHost2->pszEncryptionKey = (unsigned char *)NULL;
        pHost2 = NULL;
    }

    return(ret);
}

int 
syncThisUser(const char* pszUser)
{
    int ret = SUCCESS ;
    char szBuffer[MAX_BUFFER_SIZE + 1];
    BOOL fPlusAllFound = FALSE;

    #ifdef SSOD_DEF
    SYNC_OBJ_LIST *pSync = Globals::instance()->pSyncObjList;
    #else
    SYNC_OBJ_LIST *pSync = Globals::Instance()->pSyncObjList;
    #endif


	#ifdef PAM_DEF

	// check that this user is a valid unix user.
    // I dont unerstand how this check is not made pam lib of unix for a non existing user.
    // since pam infrastructure invokes pam modules sequentially.
    // We do the check for existence of the user.

    struct passwd*  pPasswdEntry = getpwnam((const char*)pszUser);

    if (pPasswdEntry == NULL)
   	{
        // user does not exist in /etc/passwd or NIS database, return  ERROR;
    	return ERROR;
    }
    #endif
	
    while (pSync)
    {
        
       	#ifdef PAM_DEF

        if ( !strcmp(pSync->pszSyncObjName, pszUser) )
        {
            if (pSync->fSync == TRUE)
                return SUCCESS;
            else
            {
            	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_PASSWORD_SYNC_FOR_USER_DISALLOWED_BY_SYSTEM_ADMIN,IDS_USER,
            		pszUser);
				printMessages(LOGERR,szBuffer);
				
                return ERROR;
            }
        }
        else

        #endif
        
        if ( !strcasecmp(pSync->pszSyncObjName, "all"))
        { 
            if (pSync->fSync == TRUE)
            {
                  // if "+all" found, The list could be all, -foo1, -foo2, -foo3
                  // so traverse the whole list until you find the user you are looking is not disallowed.
                  // user foo is allowed, if not disallowed. 

                  fPlusAllFound = TRUE;
            }
            else
            {
				snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_PASSWORD_SYNC_FOR_USER_DISALLOWED_BY_SYSTEM_ADMIN,IDS_USER,
            		pszUser);
				printMessages(LOGERR,szBuffer);
				
                return ERROR;
            }
        }

        #ifdef SSOD_DEF
        
        else if (Globals::instance()->caseignore_name_)
        {
            if ( !strcasecmp(pSync->pszSyncObjName, pszUser) )
            {
                if (pSync->fSync == TRUE)
                    return ERROR_SUCCESS;
                else
                {
                	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_PASSWORD_SYNC_FOR_USER_DISALLOWED_BY_SYSTEM_ADMIN,IDS_USER,
            		pszUser);
					printMessages(LOGERR,szBuffer);
					
                    return ERROR;
                }
            }
        }
           else // it is case sensitive compare 
        {
            if ( !strcmp(pSync->pszSyncObjName, pszUser) )
            {
                if (pSync->fSync == TRUE)
                    return ERROR_SUCCESS;
                else
                {
                	snprintf(szBuffer, sizeof(szBuffer),"%s %s %s",IDS_PASSWORD_SYNC_FOR_USER_DISALLOWED_BY_SYSTEM_ADMIN,IDS_USER,
            		pszUser);
					printMessages(LOGERR,szBuffer);

                    return ERROR;
                }
            }
        }

        #endif

        pSync = pSync->pNext;
    }

    if (fPlusAllFound)
        return SUCCESS;
    else
        return ERROR;
}

/*--------------------------------------------------------------------*/
BOOL
isValidSyntaxEncryptKey(const char* pKey)
{
    /*
    Encryption Key Requirements

    The encryption key must meet the following requirements: 

    a) It must be at least 12 characters long. 
       It must contain characters from at least three of the following four groups: 
    b1) Upper-case English letters (A, B...Z) 
    b2) Lower-case English letters (a, b...z) 
    b3) Westernized Arabic numerals (0, 1, 2...9) 
    b4) Punctuation symbols ( ` ~ ! @ # $ % ^ & * _ - + = | \ { } [ ] : ; \ " ' < > , . ? ) 
    */

    char szBuffer[MAX_BUFFER_SIZE + 1];
    const char *pEncryptKey = pKey;

    int     cUpper = 0;
    int     cLower = 0;
    int     cNumber = 0;
    int     cPunct  = 0;

    // check length

	
    if (strlen(pKey) >= MAXSECRETLEN ||
        strlen(pKey) < MINSECRETLEN
    )

    {
		snprintf(szBuffer, sizeof(szBuffer),"%s",IDS_ENCRYPTION_KEY_LENGTH_WRONG);
    
		printMessages(LOGERR,szBuffer);

        return FALSE;
    }



    while (*pEncryptKey)
    {
        if (isupper(*pEncryptKey))  cUpper |= 1;
        if (islower(*pEncryptKey))  cLower |= 1;
        if (isdigit(*pEncryptKey))  cNumber|= 1;
        if (ispunct(*pEncryptKey))  cPunct |= 1;

        pEncryptKey++;
    }

    if ((cUpper + cLower + cNumber + cPunct) <3)
    {
		snprintf(szBuffer, sizeof(szBuffer),"%s %s %s %s %s",IDS_ENCRYPTION_KEY_MUST_CONTAIN_CHARACTERS_FROM_AT_LEAST_THREE_OF_THE_FOLL_FOUR_GROUPS,
			IDS_UPPERCASE,IDS_LOWERCASE,IDS_NUMERALS,IDS_PUNC_SYMBOLS);

		printMessages(LOGERR,szBuffer);
		
        return FALSE;
    }

    return TRUE;
}
/*--------------------------------------------------------------------*/

void printConfigurationErrorMessages(const char *strMsg)
{
	#ifdef SSOD_DEF
		printMessages(COUT,strMsg);
		printMessages(COUT,"\n");
	#else
		printMessages(LOGERR,strMsg);
	#endif
}
