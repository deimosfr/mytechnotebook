/*------------------------------------------------------------------------------
** Copyright (c) Microsoft Corporation.  All rights reserved.
**
** File Name:    nttype.h
**
**------------------------------------------------------------------------------*/
#ifndef _NTTYPE_H_
#define _NTTYPE_H_

typedef const char* LPCSTR;
typedef char*       LPSTR;
typedef char        TCHAR;
typedef const TCHAR*   LPCTSTR;
typedef unsigned int SOCKET;
typedef unsigned char* LPBYTE;

typedef unsigned char BYTE, *PBYTE, UCHAR;
#ifndef DWORD_TYPE
#if defined(__amd64__)
#define DWORD_TYPE int
#else
#define DWORD_TYPE long
#endif
#endif
typedef unsigned DWORD_TYPE DWORD;
typedef unsigned DWORD_TYPE * DWORD_PTR;
typedef DWORD BOOL;
typedef unsigned int UINT;
typedef unsigned long ULONG;
typedef unsigned long* ULONG_PTR;

typedef void VOID;

#define TRUE                1
#define FALSE               0

#endif //_NTTYPE_H_

