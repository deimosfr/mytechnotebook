/****************************************************************************/
/*                                                                          */
/*   config.h                                                               */
/*   Reads configuration file                                               */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/
#include "nttype.h"

BOOL conformToPassLength(BOOL fAdmin, int nPassLength);

int getConfiguration(Globals*);

int getSyncHosts(Globals* pInstance, const char*    pStr);

int getSyncUsers(Globals* pInstance, const char*    pStr);

int freeGlobalElements(Globals* pInstance);

int trimAndValidateSyncObjList(Globals* pInstance);

int freeSyncObj(SYNC_OBJ_LIST* pSync);

int freeHostObj(HOST_LIST* pHost);

int syncThisUser(const char* pszUser);

BOOL isValidSyntaxEncryptKey(const char* pKey);

void printConfigurationErrorMessages(const char * strMsg);

