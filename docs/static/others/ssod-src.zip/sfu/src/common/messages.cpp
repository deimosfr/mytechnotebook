/****************************************************************************/
/*                                                                          */
/*   messages.cpp                                                           */
/*   Prints error messages                                                                       */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

extern "C"
{

#include "messages.h"

void printMessages(int msgType,const char *str)
{
	switch(msgType)
	{
		case COUT : fprintf(stdout,"%s",str);
			 break;
		case CERR : fprintf(stderr,"%s",str);
			 break;
		case LOGERR : syslog(LOG_ERR,"%s",str);
		     break;
		case LOGINFO : syslog(LOG_INFO,"%s",str);
		     break;
		case LOGDEBUG : syslog(LOG_DEBUG,"%s",str);
			 break;
		case LOGWARN : syslog(LOG_WARNING,"%s",str);
			 break;
		case LOGCRIT : syslog(LOG_CRIT,"%s",str);
			 break;
	}
}
}
