/****************************************************************************/
/*                                                                          */
/*   crypto.h                                                               */
/*                                                                          */
/*                                                                          */
/*   Copyright 1998-2000Microsoft Corporation                               */
/*   All rights reserved.                                                   */
/*                                                                          */
/****************************************************************************/

#ifndef __CRYPTO_H__
#define __CRYPTO_H__

#include "nttype.h"

typedef unsigned char BYTE, *PBYTE;

#include "sha1.h"
#include "des.h"
//#include "des3.h"
#include "tripldes.h"

#define RANDOM_VALUE_LEN    8
#define DECRYPT 0
#define ENCRYPT 1

DWORD get_crypt_capabilities(void);

void generate_random_value( BYTE *r1, size_t len);

char*
decrypt_received_buffer( const char* encrypted_buffer, size_t buf_size, BYTE* r1, const char *peer_name, const char *secret, DES3TABLE *KeyTable);

void generate_hash_for_verification(BYTE *hashval, DES3TABLE *KeyTable, DWORD dwVersion, 
                                    DWORD dwMsgLength, DWORD dwMsgType,
                                    const char* username, const char* password);

#endif

