extern "C"
{
	unsigned int _rotl(unsigned int value, int shift)
	{
		register unsigned hibit;
		register unsigned num = value&0xffffffffU;

		shift &= 0x1f;

		while (shift--)
		{
			hibit = num & 0x80000000;
			num = (num<<1)&0xffffffffU;
			if (hibit)
				num |= 1;
		}

		return num;
	}
	 
	unsigned int _rotr(unsigned int value, int shift)
	{
		register unsigned lobit;
		register unsigned num = value;

		shift &= 0x1f;

		while (shift--)
		{
			 lobit = num & 1;
			 num = (num&0xffffffff)>>1;
			 if (lobit)
				 num |= 0x80000000;
		}

		return num;
	}
}
