#ifndef _PSYNCVER_H_
#define _PSYNCVER_H_

// version 1.0

#define MEPP_VERSION 0

#endif // _PSYNCVER_H_
