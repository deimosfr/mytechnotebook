/*------------------------------------------------------------------------------
** Copyright (c) Microsoft Corporation.  All rights reserved.
**
** File Name:    rotlr.c
**
**------------------------------------------------------------------------------*/
#ifdef FFR
#include <stdio.h>
#include <stdlib.h>
#endif

    unsigned int _rotl(unsigned int value, int shift)
    {
        register unsigned hibit;
        register unsigned num = value&0xffffffffU;

        shift &= 0x1f;

        while (shift--)
        {
            hibit = num & 0x80000000;
            num = (num<<1)&0xffffffffU;
            if (hibit)
                num |= 1;
        }

        return num;
    }

    unsigned int _rotr(unsigned int value, int shift)
    {
        register unsigned lobit;
        register unsigned num = value&0xffffffffU;

        shift &= 0x1f;

        while (shift--)
        {
             lobit = num & 1;
             num = (num>>1)&0xffffffffU;
             if (lobit)
	    	 num |= 0x80000000;
        }

        return num;
    }

#ifdef FFR
int
main(int argc, const char *argv[])
{
 int a1=atoi(argv[1]),
     a2=atoi(argv[2]);
 printf("%x %x\n",_rotr(a1,a2), _rotl(a1,a2));
 printf("sizeof\n\tlong long=%u\n\tlong=%u\n\tint=%u\n\tshort=%u\n", sizeof(long long), sizeof(long), sizeof(int), sizeof(short));
 return 1;
}
#endif
