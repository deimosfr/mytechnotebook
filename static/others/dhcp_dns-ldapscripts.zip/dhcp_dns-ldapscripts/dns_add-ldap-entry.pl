#!/usr/bin/perl -w
#
# This script is to add DNS entry in LDAP
#


# Includes
use strict;
use Getopt::Long;
use AppConfig qw(:expand :argcount);
use Net::LDAP;

# Some values
my $version = "0.4";

# Some configurations
my $configFile = "/usr/local/etc/dhcp-dns_ldapscripts.conf";


# Get all configurations
my $config = AppConfig->new(
    'ldapserver'    => {ARGCOUNT => 1},
    'dhcpdn'        => {ARGCOUNT => 1},
    'dhcpadmin'     => {ARGCOUNT => 1},
    'dhcppasswd'    => {ARGCOUNT => 1},
    'dnsdn'         => {ARGCOUNT => 1},
    'dnsadmin'      => {ARGCOUNT => 1},
    'dnspasswd'     => {ARGCOUNT => 1},
    'debug'
	);
$config->file($configFile);

my $debug=$config->debug();

my $ldapServer=$config->ldapserver();

my $dnsDn=$config->dnsdn();
my $dnsAdmin=$config->dnsadmin();
my $dnsPasswd=$config->dnspasswd();

# If debug, just display all value from config file !
if($debug){
    print "LDAP server is $ldapServer\n";
    print "\n";
    print "DNS params:\n";
    print "\tDNS DN is $dnsDn\n";
    print "\tDNS Admin is $dnsAdmin\n";
    print "\tDNS Passwd is ... Check your config file !\n";
    print "\n";
}

# Params management
Getopt::Long::Configure('no_ignorecase');
my $optVersion = undef;
my $optHelp = undef;
my $optReverse = undef;
my $optName = undef;
my $optValue = undef;
my $optType = undef;
my $optDnsDomain = undef;
my $optDescription = undef;
GetOptions ("v"   => \$optVersion,	    "version"       => \$optVersion,
            "h"   => \$optHelp,		    "help"          => \$optHelp,
            "r"   => \$optReverse,	    "reverse"	    => \$optReverse,
            "n=s" => \$optName, 	    "name=s"	    => \$optName,
            "a=s" => \$optValue, 	    "value=s"	    => \$optValue,
            "t=s" => \$optType,         "type=s"      	=> \$optType,
            "d=s" => \$optDnsDomain,    "dnsdomain=s"  	=> \$optDnsDomain,
            "e=s" => \$optDescription,  "description=s" => \$optDescription);

# Display usage
sub printUsage() {
    print "Usage: dns_add-ldap-entry.pl [-n | --name name]\n";
    print "\t[-a | --value value] [-t | --type type]\n";
    print "\t[-d | --dnsdomain dns_domain_name] [-r | --reverse]\n";
    print "\t[-e | --description description]\n";
}

# Display legal mentions
sub printLegalMentions() {
    print "\n";
    print "dns_add-ldap-entry.pl script, version $version\n";
    print "\n";
    print "This script come with ABSOLUTELY NO WARRANTY.  You may redistribute\n";
    print "copies of the plugins under the terms of the GNU General Public License.\n";
    print "For more information about these matters, see the file named COPYING.\n";
    print "\n";
    print "Copyright (c) 2007 Guillaume LOHEZ <silencer\@free-4ever.net>\n";
    print "\n";
}

# Display help
sub printHelp() {
    print "This script is to create entry for DNS with an LDAP backend\n";
    printLegalMentions();
    printUsage();
    print "\n";
    print "Options:\n";
    print "\t-v, --version :\t\tDisplay version of this plugin\n";
    print "\t-h, --help :\t\tDisplay this help message\n";
    print "\t-n, --name :\t\tName of the object to add\n";
    print "\t-v, --value :\t\tValue for the object to add\n";
    print "\t-t, --type :\t\tType of the object, possible types are: A, CNAME and NS\n";
    print "\t-d, --dnsdomain :\tDNS domain name which will contain the object\n";
    print "\t-r, --reverse :\t\tGenerate reverse record for a type A record\n";
    print "\t-e, --description :\t\tDescription to use for the TXT record\n";
    print "\n";
    exit 0;
}
    
# Options checking
if (defined($optVersion)) {
    printLegalMentions();
    exit 0;
}

if (defined($optHelp)) {
    printHelp();
    exit 0;
}

if (!defined($optName)){
    print "To add an object, we need the hostname !\n";
    printUsage();
    exit 1;
}

if (!defined($optValue)){
    print "To add an object, we need a value !\n";
    printUsage();
    exit 1;
}

if (!defined($optType)){
    print "To add an object, we need a type !\n";
    printUsage();
    exit 1;
}

if ($optType !~ /\ba\b/ && $optType !~ /\bA\b/ && 
    $optType !~ /\bcname\b/ && $optType !~ /\bCNAME\b/ &&
    $optType !~ /\bns\b/ && $optType !~ /\bNS\b/ ){
    print "Only allowed types are: A, CNAME and NS !\n";
    printUsage();
    exit 1;
}

if (!defined($optDnsDomain)){
    print "To add an entry, we need the domain name\n";
    printUsage();
    exit 1;
}

if (defined($optReverse) && $optType !~ /\ba\b/ && $optType !~ /\bA\b/ ){
    print "Reverse option is only available for type A record !\n";
    printUsage();
    exit 1;
}

if (!defined($optDescription)){
    print "To add an entry, we need its description\n";
    printUsage();
    exit 1;
}


# Ok, we now a connection to LDAP server will be usefull now
# So, connect to ldap server
my $ldap = Net::LDAP->new($ldapServer) or die "$@";
 
# bind to directory with dn and password
my $res = $ldap->bind($dnsAdmin, password => $dnsPasswd);
 
if($res->is_error ){
	print "Bind to $ldapServer with $dnsAdmin and its password unsuccessfull\n";
	exit 1;
}
else{
	if($debug){
		print "Bind to $ldapServer with $dnsAdmin and its password successfull\n";
        print "\n";
	}
}
    
## Check if the zone exist or not in this DNS
$res = $ldap->search(	base   => $dnsDn,
                        scope  => 'sub',
                        filter => '(&(objectClass=dNSZone)(zoneName='.$optDnsDomain.'))'
			);
if(!$res->entries){
    print "The zone: $optDnsDomain does not exist on this server !\n";
    $ldap->unbind;
    exit 2;
}
    
    
## Type "A" entry
if($optType =~ /\ba\b/ || $optType =~ /\bA\b/){
    if($debug){
        print "Type A record to add:\n";
        print "\tHostname: $optName\n";
        print "\tIP: $optValue\n";
        print "\tDNS Domain: $optDnsDomain\n";
        if($optReverse){
            print "\tReverse object is requested !\n"
        }
        print "\n";
    }
    
    if ($optValue !~ /^[1-2]{0,1}[0-9]{0,2}\.[1-2]{0,1}[0-9]{0,2}\.[1-2]{0,1}[0-9]{0,2}\.[1-2]{0,1}[0-9]{0,2}$/){
         print "This IP address doesn't seem to have the right format !\n";
        printUsage();
        exit 1;
    }

    ## Some checks about the hostname
    # Check if the name is used in A record
    # In case of A record, it must not exist !
    # Disable this test if you want
    # - multiple hostname per IP
    # - zone which have also an IP
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName='.$optName.')(zoneName='.$optDnsDomain.'))'
   			);
    
    foreach my $aEntry ($res->entries){
        if($aEntry->get_value("aRecord")){
    	    print "The hostname: $optName is already used with IP: ".$aEntry->get_value("aRecord")." !\n";
        }
        else{
            if($aEntry->get_value("cNAMERecord")){
                print "The hostname: $optName is already used as a CNAME on the host: ".$aEntry->get_value("cNAMERecord")." !\n";
            }
            else{
                if(defined($aEntry->get_value("nSRecord"))){
                    print "The name: $optName is already used as a zone with delegation to : ".$aEntry->get_value("nSRecord")." !\n";
                }
            }
        }
        $ldap->unbind;
        exit 2;
    }
    
    # Check if the IP address is already inside the DNS or not
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(aRecord='.$optValue.')(zoneName='.$optDnsDomain.'))'
    			);  
    
    if($res->entries){
        my $ipEntry = $res->entry;
    	print "The IP: $optValue is already used with the name: ".$ipEntry->get_value("relativeDomainName")." !\n";
        $ldap->unbind;
        exit 2;
    }
    
    # Now, add the entry
    my $dn = "relativeDomainName=".$optName.",ou=".$optDnsDomain.",".$dnsDn;
    if($debug){
        print "Current DN to add: $dn\n";
        print "\n";
    }
    $res = $ldap->add( $dn	,
    			attrs => [
    				objectClass         => 'top',
    				objectClass         => 'dNSZone',
    				zoneName            => $optDnsDomain,
    				relativeDomainName  => $optName,
    				dNSTTL              => '1800',
       				dNSClass            => 'IN',
                    aRecord             => $optValue,
                    tXTRecord           => $optDescription
      			]
   		);
    
    if($res->is_error){
    	print "Problem while adding the A record: $optName => $optValue !\n";
    	$ldap->unbind;
    	exit 1;
    }
    else{
    	print "A record: $optName => $optValue has been created.\n";
    }

    # Update the serial of the zone
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$optDnsDomain.'))'
   			);
    my $temp = $res->entry->get_value("sOARecord");
    my @temp2 = split(/ /, $temp);
    my $serial = $temp2[2];

    my $cYear = substr($serial, 0, 4);
    my $cMonth = substr($serial, 4, 2);
    my $cDay = substr($serial, 6, 2);
    my $cNumber = substr($serial, 8, 3);

    if($debug){
        print "Extracted year is: $cYear\n";
        print "Extracted month is: $cMonth\n";
        print "Extracted day is: $cDay\n";
        print "Extracted number is: $cNumber\n";
    }

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    
    my $change = 0;

    if($cYear != ($year+1900)){
        $cYear = ($year+1900);
        $change = 1;
    }
    if($cMonth != ($mon+1)){
        $cMonth = ($mon+1);
        if($cMonth < 10 ){
            $cMonth = "0".$cMonth;
        }
        $change = 1;
    }
    if($cDay != $mday){
        $cDay = $mday;
        if($cDay < 10 ){
            $cDay = "0".$cDay;
        }
        $change = 1;
    }
    if($change){
        $cNumber = "001";
    }
    else{
        $cNumber++;
    }

    my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
    $temp2[2] = $newSerial;
    if($debug){
        print "New serial is: $newSerial\n";
    }

    my $newSoa = join(" ", @temp2);
    if($debug){
        print "New SOA is: $newSoa\n";
    }

    $res = $ldap->modify( "relativeDomainName=@,ou=".$optDnsDomain.",".$dnsDn,
                changes => [
                    replace => [ sOARecord => $newSoa ]
                ]
            );

    if($res->is_error){
        print "Problem updating: SOA of zone: $optDnsDomain with new serial: $newSerial !\n";
        $ldap->unbind;
        exit 1;
    }
    else{
        if($debug){
    	    print "Updating: SOA for zone $optDnsDomain with serial $newSerial.\n";
        }
    }


    # if option --reverse, we generate the reverse entry !
    if(defined($optReverse)){
        if($debug){
            print "Now working on reverse entry\n";
        }

        my @separetedIp = split(/\./, $optValue);
        my $last = pop(@separetedIp);
        my @reversedIp = reverse(@separetedIp);
        my $joinedIp = join(".", @reversedIp);
    
        if($debug){
            print "Type PTR record to add:\n";
            print "\tReverse Domain: $joinedIp.in-addr.apra\n";
            print "\tLast: $last\n";
            print "\n";
        }
    
        # Now, add the entry
        my $dn = "relativeDomainName=".$last.",ou=".$joinedIp.".in-addr.arpa,".$dnsDn;
        if($debug){
            print "Current DN to add: $dn\n";
            print "\n";
        }
        $res = $ldap->add( $dn	,
        			attrs => [
        				objectClass         => 'top',
        				objectClass         => 'dNSZone',
        				zoneName            => $joinedIp.".in-addr.arpa",
        				relativeDomainName  => $last,
                        pTRRecord           => $optName.".".$optDnsDomain.".",
                        tXTRecord           => $optDescription
        			]
       		);
       
        if($res->is_error){
        	print "Problem while adding the PTR record: $last => $optName !\n";
        	$ldap->unbind;
        	exit 1;
        }
        else{
           	print "PTR record: $last.$joinedIp.in-addr.arpa => $optName.$optDnsDomain. has been created.\n";
        }

        # Update the serial of the zone
        $res = $ldap->search(	base   => $dnsDn,
                                scope  => 'sub',
                                filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$joinedIp.'.in-addr.arpa))'
   	    		);
        my $temp = $res->entry->get_value("sOARecord");
        my @temp2 = split(/ /, $temp);
        my $serial = $temp2[2];
    
        my $cYear = substr($serial, 0, 4);
        my $cMonth = substr($serial, 4, 2);
        my $cDay = substr($serial, 6, 2);
        my $cNumber = substr($serial, 8, 3);
    
        if($debug){
            print "Extracted year is: $cYear\n";
            print "Extracted month is: $cMonth\n";
            print "Extracted day is: $cDay\n";
            print "Extracted number is: $cNumber\n";
        }
    
        my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
        
        my $change = 0;
    
        if($cYear != ($year+1900)){
            $cYear = ($year+1900);
            $change = 1;
        }
        if($cMonth != ($mon+1)){
            $cMonth = ($mon+1);
            if($cMonth < 10 ){
                $cMonth = "0".$cMonth;
            }
            $change = 1;
        }
        if($cDay != $mday){
            $cDay = $mday;
            if($cDay < 10 ){
                $cDay = "0".$cDay;
            }
            $change = 1;
        }
        if($change){
            $cNumber = "001";
        }
        else{
            $cNumber++;
        }
    
        my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
        $temp2[2] = $newSerial;
        if($debug){
            print "New serial is: $newSerial\n";
        }
    
        my $newSoa = join(" ", @temp2);
        if($debug){
            print "New SOA is: $newSoa\n";
        }
    
        $res = $ldap->modify( "relativeDomainName=@,ou=".$joinedIp.".in-addr.arpa,".$dnsDn,
                    changes => [
                        replace => [ sOARecord => $newSoa ]
                    ]
                );
    
        if($res->is_error){
            print "Problem updating: SOA of zone: $joinedIp.in-addr.apra with new serial: $newSerial !\n";
            $ldap->unbind;
            exit 1;
        }
        else{
            if($debug){
        	    print "Updating: SOA for zone $joinedIp.in-addr.apra with serial $newSerial.\n";
            }
        }
    
    }
}
   
## Type "CNAME" entry
if($optType =~ /\bcname\b/ || $optType =~ /\bCNAME\b/){
    if($debug){
        print "Type CNAME record to add:\n";
        print "\tAlias name: $optName\n";
        print "\tHostname: $optValue\n";
        print "\tDNS Domain: $optDnsDomain\n";
        print "\n";
    }
    
    # In case of Alias record, the hostname must exist !
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName='.$optValue.')(zoneName='.$optDnsDomain.'))'
	    		);
    
    if(!$res->entries){
    	print "The hostname: $optValue must exist to create an alias on it !\n";
        $ldap->unbind;
        exit 2;
    }
    
    # But not the alias
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName='.$optName.')(zoneName='.$optDnsDomain.'))'
    			);
    
    if($res->entries){
        my $cnameEntry = $res->entry;
        if(defined($cnameEntry->get_value("cNAMERecord"))){
    	    print "The alias: $optName is already used as a CNAME of the host: ".$cnameEntry->get_value("cNAMERecord")." !\n";
        }
        else{
            if(defined($cnameEntry->get_value("aRecord"))){
                print "The alias: $optName is already used with the IP: ".$cnameEntry->get_value("aRecord")." !\n";
            }
            else{
                if(defined($cnameEntry->get_value("nSRecord"))){
                    print "The name: $optName is already used as a zone with delegation to : ".$cnameEntry->get_value("nSRecord")." !\n";
                }
            }
        }
        $ldap->unbind;
        exit 2;
    }

    # Now, add the entry
    my $dn = "relativeDomainName=".$optName.",ou=".$optDnsDomain.",".$dnsDn;
    if($debug){
        print "Current DN to add: $dn\n";
        print "\n";
    }
    $res = $ldap->add(	$dn,
                attrs => [
   				    objectClass         => 'top',
       		        objectClass         => 'dNSZone',
       				zoneName            => $optDnsDomain,
       				relativeDomainName  => $optName,
       				dNSTTL              => '1800',
       				dNSClass            => 'CNAME',
                    cNAMERecord         => $optValue,
                    tXTRecord           => $optDescription
       			]
       		);
   
    if($res->is_error){
    	print "Problem while adding the CNAME record: $optName => $optValue !\n";
    	$ldap->unbind;
    	exit 1;
    }
    else{
    	print "CNAME record: $optName => $optValue has been created.\n";
    }

    # Update the serial of the zone
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$optDnsDomain.'))'
   			);
    my $temp = $res->entry->get_value("sOARecord");
    my @temp2 = split(/ /, $temp);
    my $serial = $temp2[2];

    my $cYear = substr($serial, 0, 4);
    my $cMonth = substr($serial, 4, 2);
    my $cDay = substr($serial, 6, 2);
    my $cNumber = substr($serial, 8, 3);

    if($debug){
        print "Extracted year is: $cYear\n";
        print "Extracted month is: $cMonth\n";
        print "Extracted day is: $cDay\n";
        print "Extracted number is: $cNumber\n";
    }

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    
    my $change = 0;

    if($cYear != ($year+1900)){
        $cYear = ($year+1900);
        $change = 1;
    }
    if($cMonth != ($mon+1)){
        $cMonth = ($mon+1);
        if($cMonth < 10 ){
            $cMonth = "0".$cMonth;
        }
        $change = 1;
    }
    if($cDay != $mday){
        $cDay = $mday;
        if($cDay < 10 ){
            $cDay = "0".$cDay;
        }
        $change = 1;
    }
    if($change){
        $cNumber = "001";
    }
    else{
        $cNumber++;
    }

    my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
    $temp2[2] = $newSerial;
    if($debug){
        print "New serial is: $newSerial\n";
    }

    my $newSoa = join(" ", @temp2);
    if($debug){
        print "New SOA is: $newSoa\n";
    }

    $res = $ldap->modify( "relativeDomainName=@,ou=".$optDnsDomain.",".$dnsDn,
                changes => [
                    replace => [ sOARecord => $newSoa ]
                ]
            );

    if($res->is_error){
        print "Problem updating: SOA of zone: $optDnsDomain with new serial: $newSerial !\n";
        $ldap->unbind;
        exit 1;
    }
    else{
        if($debug){
    	    print "Updating: SOA for zone $optDnsDomain with serial $newSerial.\n";
        }
    }

}

## Type "NS" entry
if($optType =~ /\bns\b/ || $optType =~ /\bNS\b/){
    if($debug){
        print "Type NS record to add:\n";
        print "\tZone name: $optName\n";
        print "\tHostname: $optValue\n";
        print "\tDNS Domain: $optDnsDomain\n";
        print "\n";
    }
    
    # In case of Alias record, the hostname must exist !
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName='.$optValue.')(zoneName='.$optDnsDomain.'))'
	    		);
    
    if(!$res->entries){
    	print "The hostname: $optValue must exist to create a zone delegation on it !\n";
        $ldap->unbind;
        exit 2;
    }
    
    # But not the zone
    # Disable this test if you want a zone to have a IP
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName='.$optName.')(zoneName='.$optDnsDomain.'))'
    			);
    
    if($res->entries){
        my $nsEntry = $res->entry;
        if(defined($nsEntry->get_value("cNAMERecord"))){
    	    print "The name: $optName is already used as a CNAME of the host: ".$nsEntry->get_value("cNAMERecord")." !\n";
        }
        else{
            if(defined($nsEntry->get_value("aRecord"))){
                print "The name: $optName is already used with the IP: ".$nsEntry->get_value("aRecord")." !\n";
            }
            else{
                if(defined($nsEntry->get_value("nSRecord"))){
                    print "The name: $optName is already used as a zone with delegation to : ".$nsEntry->get_value("nSRecord")." !\n";
                }
            }
        }
        $ldap->unbind;
        exit 2;
    }

    # Now, add the entry
    my $dn = "relativeDomainName=".$optName.",ou=".$optDnsDomain.",".$dnsDn;
    if($debug){
        print "Current DN to add: $dn\n";
        print "\n";
    }
    $res = $ldap->add(	$dn,
                attrs => [
   				    objectClass         => 'top',
       		        objectClass         => 'dNSZone',
       				zoneName            => $optDnsDomain,
       				relativeDomainName  => $optName,
       				dNSTTL              => '1800',
       				dNSClass            => 'NS',
                    nSRecord            => $optValue,
                    tXTRecord           => $optDescription
       			]
       		);
   
    if($res->is_error){
    	print "Problem while adding the NS record: $optName => $optValue !\n";
    	$ldap->unbind;
    	exit 1;
    }
    else{
    	print "NS record: $optName => $optValue has been created.\n";
    }

    # Update the serial of the zone
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$optDnsDomain.'))'
   			);
    my $temp = $res->entry->get_value("sOARecord");
    my @temp2 = split(/ /, $temp);
    my $serial = $temp2[2];

    my $cYear = substr($serial, 0, 4);
    my $cMonth = substr($serial, 4, 2);
    my $cDay = substr($serial, 6, 2);
    my $cNumber = substr($serial, 8, 3);

    if($debug){
        print "Extracted year is: $cYear\n";
        print "Extracted month is: $cMonth\n";
        print "Extracted day is: $cDay\n";
        print "Extracted number is: $cNumber\n";
    }

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    
    my $change = 0;

    if($cYear != ($year+1900)){
        $cYear = ($year+1900);
        $change = 1;
    }
    if($cMonth != ($mon+1)){
        $cMonth = ($mon+1);
        if($cMonth < 10 ){
            $cMonth = "0".$cMonth;
        }
        $change = 1;
    }
    if($cDay != $mday){
        $cDay = $mday;
        if($cDay < 10 ){
            $cDay = "0".$cDay;
        }
        $change = 1;
    }
    if($change){
        $cNumber = "001";
    }
    else{
        $cNumber++;
    }

    my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
    $temp2[2] = $newSerial;
    if($debug){
        print "New serial is: $newSerial\n";
    }

    my $newSoa = join(" ", @temp2);
    if($debug){
        print "New SOA is: $newSoa\n";
    }

    $res = $ldap->modify( "relativeDomainName=@,ou=".$optDnsDomain.",".$dnsDn,
                changes => [
                    replace => [ sOARecord => $newSoa ]
                ]
            );

    if($res->is_error){
        print "Problem updating: SOA of zone: $optDnsDomain with new serial: $newSerial !\n";
        $ldap->unbind;
        exit 1;
    }
    else{
        if($debug){
    	    print "Updating: SOA for zone $optDnsDomain with serial $newSerial.\n";
        }
    }

}

# close ldap connection
$ldap->unbind;

