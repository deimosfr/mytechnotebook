#!/usr/bin/perl -w
#
# This script is to search DNS entry in LDAP
#


# Includes
use strict;
use Getopt::Long;
use AppConfig qw(:expand :argcount);
use Net::LDAP;

# Some values
my $version = "0.4";

# Some configurations
my $configFile = "/usr/local/etc/dhcp-dns_ldapscripts.conf";


# Get all configurations
my $config = AppConfig->new(
    'ldapserver'    => {ARGCOUNT => 1},
    'dhcpdn'        => {ARGCOUNT => 1},
    'dhcpadmin'     => {ARGCOUNT => 1},
    'dhcppasswd'    => {ARGCOUNT => 1},
    'dnsdn'         => {ARGCOUNT => 1},
    'dnsadmin'      => {ARGCOUNT => 1},
    'dnspasswd'     => {ARGCOUNT => 1},
    'debug'
	);
$config->file($configFile);

my $debug=$config->debug();

my $ldapServer=$config->ldapserver();

my $dnsDn=$config->dnsdn();
my $dnsAdmin=$config->dnsadmin();
my $dnsPasswd=$config->dnspasswd();

# If debug, just display all value from config file !
if($debug){
    print "LDAP server is $ldapServer\n";
    print "\n";
    print "DNS params:\n";
    print "\tDNS DN is $dnsDn\n";
    print "\tDNS Admin is $dnsAdmin\n";
    print "\tDNS Passwd is ... Check your config file !\n";
    print "\n";
}

# Params management
Getopt::Long::Configure('no_ignorecase');
my $optVersion = undef;
my $optHelp = undef;
my $optName = undef;
my $optIp = undef;
my $optDescription = undef;
GetOptions ("v"   => \$optVersion,	    "version"       => \$optVersion,
            "h"   => \$optHelp,		    "help"          => \$optHelp,
            "n=s" => \$optName, 	    "name=s"	    => \$optName,
            "i=s" => \$optIp,           "ip=s"        	=> \$optIp,
            "e=s" => \$optDescription,  "description=s"	=> \$optDescription);

# Display usage
sub printUsage() {
    print "Usage: dns_search-ldap-entry.pl [-n | --name hostname]\n";
    print "\t[-i | --ip ip_address] [-e | --description description]\n";
}

# Display legal mentions
sub printLegalMentions() {
    print "\n";
    print "dns_search-ldap-entry.pl script, version $version\n";
    print "\n";
    print "This script come with ABSOLUTELY NO WARRANTY.  You may redistribute\n";
    print "copies of the plugins under the terms of the GNU General Public License.\n";
    print "For more information about these matters, see the file named COPYING.\n";
    print "\n";
    print "Copyright (c) 2007 Guillaume LOHEZ <silencer\@free-4ever.net>\n";
    print "\n";
}

# Display help
sub printHelp() {
    print "This script is to search entries for DNS with an LDAP backend\n";
    printLegalMentions();
    printUsage();
    print "\n";
    print "Options:\n";
    print "\t-v, --version :\t\tDisplay version of this plugin\n";
    print "\t-h, --help :\t\tDisplay this help message\n";
    print "\t-n, --name :\t\tName of the host to search\n";
    print "\t-i, --ip :\t\tIP address to search\n";
    print "\t-e, --description :\t\tDescription to search\n";
    print "\n";
    exit 0;
}
    
# Options checking
if (defined($optVersion)) {
    printLegalMentions();
    exit 0;
}

if (defined($optHelp)) {
    printHelp();
    exit 0;
}

if (!defined($optName) && !defined($optIp) && !defined($optDescription)){
    print "To search we need a hostname or an IP address !\n";
    printUsage();
    exit 1;
}

if ((defined($optName) && defined($optIp))||
    (defined($optName) && defined($optDescription))||
    (defined($optDescription) && defined($optIp))){
    print "We can only search for one type of entry in the same time !\n";
    printUsage();
    exit 1;
}


## Main prog

# Ok, we now a connection to LDAP server will be usefull now
# So, connect to ldap server
my $ldap = Net::LDAP->new($ldapServer) or die "$@";
 
# bind to directory with dn and password
my $res = $ldap->bind($dnsAdmin, password => $dnsPasswd);
 
if($res->is_error ){
	print "Bind to $ldapServer with $dnsAdmin and its password unsuccessfull\n";
	exit 1;
}
else{
	if($debug){
		print "Bind to $ldapServer with $dnsAdmin and its password successfull\n";
        print "\n";
	}
}

# We are looking for a hostname
if($optName){
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=*'.$optName.'*))'
    			);

    foreach my $nameEntry ($res->entries){
        my $currentRelativeDomainName = $nameEntry->get_value("relativeDomainName");
        if($nameEntry->get_value("aRecord")){
    	    print "Name: $currentRelativeDomainName found with IP: ".$nameEntry->get_value("aRecord")." with description: ".$nameEntry->get_value("tXTRecord")."\n";
        }
        else{
            if($nameEntry->get_value("cNAMERecord")){
                print "Name: $currentRelativeDomainName found as a CNAME on the host: ".$nameEntry->get_value("cNAMERecord")." with description: ".$nameEntry->get_value("tXTRecord")."\n";
            }
            else{
                if(defined($nameEntry->get_value("nSRecord"))){
                    print "Name: $currentRelativeDomainName found as a zone with delegation to : ".$nameEntry->get_value("nSRecord")." with description: ".$nameEntry->get_value("tXTRecord")."\n";
                }
            }
        }
    }
    print "\n";

}

# We are looking for an IP address
if($optIp){
    # First, the type A records
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(aRecord='.$optIp.'))'
    			);

    foreach my $ipEntry ($res->entries) {
        print "IP: ".$ipEntry->get_value('aRecord')." found with name: ".$ipEntry->get_value('relativeDomainName')." with description: ".$ipEntry->get_value("tXTRecord")."\n";
    }

    # Then the type PTR records
    my @separetedIp = split(/\./, $optIp);
    my $last = pop(@separetedIp);
    my @reversedIp = reverse(@separetedIp);
    my $joinedIp = join(".", @reversedIp);

    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName='.$last.')(zoneName='.$joinedIp.'.in-addr.arpa))'
    			);

    foreach my $reverseEntry ($res->entries) {
        print "Reverse IP: ".$reverseEntry->get_value('relativeDomainName').".".$reverseEntry->get_value('zoneName')." found with name: ".$reverseEntry->get_value('pTRRecord')." with description: ".$reverseEntry->get_value("tXTRecord")."\n";
    }
    print "\n";

}

# We are looking for a description
if($optDescription){
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(tXTRecord=*'.$optDescription.'*))'
    			);

    foreach my $descEntry ($res->entries){
        my $currentRelativeDomainName = $descEntry->get_value("relativeDomainName");
        if($descEntry->get_value("aRecord")){
    	    print "Description: ".$descEntry->get_value("tXTRecord")." found on A record with name: ".$currentRelativeDomainName." and IP: ".$descEntry->get_value("aRecord")."\n";
        }
        else{
            if($descEntry->get_value("cNAMERecord")){
                print "Description: ".$descEntry->get_value("tXTRecord")." found on CNAME record with name: ".$currentRelativeDomainName." and host: ".$descEntry->get_value("cNAMERecord")."\n";
            }
            else{
                if(defined($descEntry->get_value("nSRecord"))){
                    print "Description: ".$descEntry->get_value("tXTRecord")." found on NS record with name: ".$currentRelativeDomainName." and host: ".$descEntry->get_value("nSRecord")."\n";
                }
                else{
                    if(defined($descEntry->get_value("pTRRecord"))){
                        print "Description: ".$descEntry->get_value("tXTRecord")." found on PTR record with reverse IP: ".$currentRelativeDomainName.".".$descEntry->get_value("zoneName")." and host: ".$descEntry->get_value("pTRRecord")."\n";
                    }
                }
            }
        }
    }
    print "\n";

}


# close ldap connection
$ldap->unbind;
