#!/usr/bin/perl -w
#
# This script is to search DNS entry in LDAP
#


# Includes
use strict;
use Getopt::Long;
use AppConfig qw(:expand :argcount);
use Net::LDAP;

# Some values
my $version = "0.4";

# Some configurations
my $configFile = "/usr/local/etc/dhcp-dns_ldapscripts.conf";


# Get all configurations
my $config = AppConfig->new(
    'ldapserver'    => {ARGCOUNT => 1},
    'dhcpdn'        => {ARGCOUNT => 1},
    'dhcpadmin'     => {ARGCOUNT => 1},
    'dhcppasswd'    => {ARGCOUNT => 1},
    'dnsdn'         => {ARGCOUNT => 1},
    'dnsadmin'      => {ARGCOUNT => 1},
    'dnspasswd'     => {ARGCOUNT => 1},
    'debug'
	);
$config->file($configFile);

my $debug=$config->debug();

my $ldapServer=$config->ldapserver();

my $dnsDn=$config->dnsdn();
my $dnsAdmin=$config->dnsadmin();
my $dnsPasswd=$config->dnspasswd();

# If debug, just display all value from config file !
if($debug){
    print "LDAP server is $ldapServer\n";
    print "\n";
    print "DNS params:\n";
    print "\tDNS DN is $dnsDn\n";
    print "\tDNS Admin is $dnsAdmin\n";
    print "\tDNS Passwd is ... Check your config file !\n";
    print "\n";
}

# Params management
Getopt::Long::Configure('no_ignorecase');
my $optVersion = undef;
my $optHelp = undef;
my $optDomain = undef;
GetOptions ("v"   => \$optVersion,	    "version"       => \$optVersion,
            "h"   => \$optHelp,		    "help"          => \$optHelp,
            "d=s" => \$optDomain,       "domain=s"  	=> \$optDomain);

# Display usage
sub printUsage() {
    print "Usage: dns_search-ldap-entry.pl [-d | --domain dhcp_admin_domain]\n";
}

# Display legal mentions
sub printLegalMentions() {
    print "\n";
    print "dns_list-ldap-entry.pl script, version $version\n";
    print "\n";
    print "This script come with ABSOLUTELY NO WARRANTY.  You may redistribute\n";
    print "copies of the plugins under the terms of the GNU General Public License.\n";
    print "For more information about these matters, see the file named COPYING.\n";
    print "\n";
    print "Copyright (c) 2007 Guillaume LOHEZ <silencer\@free-4ever.net>\n";
    print "\n";
}

# Display help
sub printHelp() {
    print "This script is to list all entries for DNS with an LDAP backend\n";
    printLegalMentions();
    printUsage();
    print "\n";
    print "Options:\n";
    print "\t-v, --version :\t\tDisplay version of this plugin\n";
    print "\t-h, --help :\t\tDisplay this help message\n";
    print "\t-d, --domain :\t\tDNS domain name to list\n";
    print "\n";
    exit 0;
}
    
# Options checking
if (defined($optVersion)) {
    printLegalMentions();
    exit 0;
}

if (defined($optHelp)) {
    printHelp();
    exit 0;
}


## Main prog

# Ok, we now a connection to LDAP server will be usefull now
# So, connect to ldap server
my $ldap = Net::LDAP->new($ldapServer) or die "$@";
 
# bind to directory with dn and password
my $res = $ldap->bind($dnsAdmin, password => $dnsPasswd);
 
if($res->is_error ){
	print "Bind to $ldapServer with $dnsAdmin and its password unsuccessfull\n";
	exit 1;
}
else{
	if($debug){
		print "Bind to $ldapServer with $dnsAdmin and its password successfull\n";
        print "\n";
	}
}

# We are looking for all entries
# First, the type A records
if(defined($optDomain)){
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=*)(zoneName='.$optDomain.'))'
    			);
}
else{
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=*))'
    			);
}
if(!$res->entries){
    print "No entry found !\n";
}
else{
    foreach my $nameEntry ($res->entries){
        my $currentRelativeDomainName = $nameEntry->get_value("relativeDomainName");
        if($nameEntry->get_value("aRecord")){
    	    print "Name: $currentRelativeDomainName.".$nameEntry->get_value("zoneName")." found with IP: ".$nameEntry->get_value("aRecord")." with description: ".$nameEntry->get_value("tXTRecord")."\n";
        }
        else{
            if($nameEntry->get_value("cNAMERecord")){
                print "Name: $currentRelativeDomainName.".$nameEntry->get_value("zoneName")." found as a CNAME on the host: ".$nameEntry->get_value("cNAMERecord")." with description: ".$nameEntry->get_value("tXTRecord")."\n";
            }
            else{
                if(defined($nameEntry->get_value("nSRecord"))){
                    print "Zone: $currentRelativeDomainName.".$nameEntry->get_value("zoneName")." found as a zone with delegation to : ".$nameEntry->get_value("nSRecord")." with description: ".$nameEntry->get_value("tXTRecord")."\n";
                }
                else{
                    if(defined($nameEntry->get_value("pTRRecord"))){
                        print "IP: $currentRelativeDomainName.".$nameEntry->get_value("zoneName")." found as a reverse entry on : ".$nameEntry->get_value("pTRRecord")." with description: ".$nameEntry->get_value("tXTRecord")."\n";
                    }
                }
            }
        }
    }
    print "\n";

}


# close ldap connection
$ldap->unbind;
