#!/usr/bin/perl -w
#
# This script is to add DHCP entry in LDAP
#


# Includes
use strict;
use Getopt::Long;
use AppConfig qw(:expand :argcount);
use Net::LDAP;

# Some values
my $version = "0.4";

# Some configurations
my $configFile = "/usr/local/etc/dhcp-dns_ldapscripts.conf";


# Get all configurations
my $config = AppConfig->new(
    'ldapserver'    => {ARGCOUNT => 1},
    'dhcpdn'        => {ARGCOUNT => 1},
    'dhcpadmin'     => {ARGCOUNT => 1},
    'dhcppasswd'    => {ARGCOUNT => 1},
    'dnsdn'         => {ARGCOUNT => 1},
    'dnsadmin'      => {ARGCOUNT => 1},
    'dnspasswd'     => {ARGCOUNT => 1},
    'debug'
	);
$config->file($configFile);

my $debug=$config->debug();

my $ldapServer=$config->ldapserver();

my $dhcpDn=$config->dhcpdn();
my $dhcpAdmin=$config->dhcpadmin();
my $dhcpPasswd=$config->dhcppasswd();

# If debug, just display all value from config file !
if($debug){
    print "LDAP server is $ldapServer\n";
    print "\n";
    print "DHCP params:\n";
    print "\tDHCP DN is $dhcpDn\n";
    print "\tDHCP Admin is $dhcpAdmin\n";
    print "\tDHCP Passwd is ... Check your config file !\n";
    print "\n";
}

# Params management
Getopt::Long::Configure('no_ignorecase');
my $optVersion = undef;
my $optHelp = undef;
my $optName = undef;
my $optIp = undef;
my $optMac = undef;
my $optDomain = undef;
GetOptions ("v"   => \$optVersion,	    "version"       => \$optVersion,
            "h"   => \$optHelp,		    "help"          => \$optHelp,
            "n=s" => \$optName, 	    "name=s"	    => \$optName,
            "i=s" => \$optIp,           "ip=s"        	=> \$optIp,
            "m=s" => \$optMac,          "mac=s"    	    => \$optMac,
            "d=s" => \$optDomain,       "domain=s"  	=> \$optDomain);

# Display usage
sub printUsage() {
    print "Usage: dhcp_add-ldap-entry.pl [-n | --name hostname]\n";
    print "\t[-i | --ip ip_address] [-m | --mac mac_adress]\n";
    print "\t[-d | --domain dhcp_admin_domain]\n";
}

# Display legal mentions
sub printLegalMentions() {
    print "\n";
    print "dhcp_add-ldap-entry.pl script, version $version\n";
    print "\n";
    print "This script come with ABSOLUTELY NO WARRANTY.  You may redistribute\n";
    print "copies of the plugins under the terms of the GNU General Public License.\n";
    print "For more information about these matters, see the file named COPYING.\n";
    print "\n";
    print "Copyright (c) 2007 Guillaume LOHEZ <silencer\@free-4ever.net>\n";
    print "\n";
}

# Display help
sub printHelp() {
    print "This script is to create entry for DHCP with an LDAP backend\n";
    printLegalMentions();
    printUsage();
    print "\n";
    print "Options:\n";
    print "\t-v, --version :\t\tDisplay version of this plugin\n";
    print "\t-h, --help :\t\tDisplay this help message\n";
    print "\t-n, --name :\t\tName of the host to add\n";
    print "\t-i, --ip :\t\tIP address of the host to add\n";
    print "\t-m, --mac :\t\tMAC address of the host to add\n";
    print "\t-d, --domain :\t\tDHCP admin domain to create the host inside\n";
    print "\n";
    exit 0;
}
    
# Options checking
if (defined($optVersion)) {
    printLegalMentions();
    exit 0;
}

if (defined($optHelp)) {
    printHelp();
    exit 0;
}

if (!defined($optName)){
    print "To add an object, we need the hostname !\n";
    printUsage();
    exit 1;
}

if (!defined($optIp)){
    print "To add an object, we need the IP address !\n";
    printUsage();
    exit 1;
}

if ($optIp !~ /^[1-2]{0,1}[0-9]{0,2}\.[1-2]{0,1}[0-9]{0,2}\.[1-2]{0,1}[0-9]{0,2}\.[1-2]{0,1}[0-9]{0,2}$/){
     print "This IP address doesn't seem to have the right format !\n";
    printUsage();
    exit 1;
}

if (!defined($optMac)){
    print "To add an object, we need the MAC address !\n";
    printUsage();
    exit 1;
}

if ($optMac !~ /^[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}$/){
    print "This MAC address doesn't seem to have the right format !\n";
    printUsage();
    exit 1;
}

if (!defined($optDomain)){
    print "To add an object, we need the admin domain name !\n";
    printUsage();
    exit 1;
}


## Main prog

# Ok, we now a connection to LDAP server will be usefull now
# So, connect to ldap server
my $ldap = Net::LDAP->new($ldapServer) or die "$@";
 
# bind to directory with dn and password
my $res = $ldap->bind($dhcpAdmin, password => $dhcpPasswd);
 
if($res->is_error ){
	print "Bind to $ldapServer with $dhcpAdmin and its password unsuccessfull\n";
	exit 1;
}
else{
	if($debug){
		print "Bind to $ldapServer with $dhcpAdmin and its password successfull\n";
        print "\n";
	}
}

# Get the network    
my @separetedIp = split(/\./, $optIp);
my $last = pop(@separetedIp);
push (@separetedIp, "0");
my $joinedIp = join(".", @separetedIp);

## Check if the network exist or not
$res = $ldap->search(	base   => $dhcpDn,
                        scope  => 'sub',
                        filter => '(&(objectClass=dhcpSubnet)(cn='.$joinedIp.'))'
			);

if(!$res->entries){
    print "The network: $joinedIp does not exist on this server !\n";
    $ldap->unbind;
    exit 2;
}


## Some checks about IP, MAC addresses and name
# The IP must be unique
$res = $ldap->search(	base   => $dhcpDn,
                        scope  => 'sub',
                        filter => '(&(objectClass=dhcpHost)(dhcpStatements=fixed-address '.$optIp.'))'
			);

if($res->entries){
    print "The IP address: $optIp is already used on this DHCP server !\n";
    $ldap->unbind;
    exit 2;
}

# The MAC must be unique
$res = $ldap->search(	base   => $dhcpDn,
                        scope  => 'sub',
                        filter => '(&(objectClass=dhcpHost)(dhcpHWAddress=ethernet '.$optMac.'))'
			);  

if($res->entries){
	print "The MAC address: $optMac is already used on this DHCP server !\n";
    $ldap->unbind;
    exit 2;
}

# The name must be unique
$res = $ldap->search(	base   => $dhcpDn,
                        scope  => 'sub',
                        filter => '(&(objectClass=dhcpHost)(cn='.$optName.'))'
			);  

if($res->entries){
	print "The name: $optName is already used on this DHCP server !\n";
    $ldap->unbind;
    exit 2;
}

# Now, add the entry
my $dn = "cn=".$optName.",cn=networks,cn=".$optDomain.",".$dhcpDn;
if($debug){
    print "Current DN to add: $dn\n";
    print "\n";
}
$res = $ldap->add( $dn	,
			attrs => [
				objectClass         => 'top',
				objectClass         => 'dhcpHost',
                cn                  => $optName,
				dhcpHWAddress       => 'ethernet '.$optMac,
                dhcpStatements      => 'fixed-address '.$optIp
			]
		);

if($res->is_error){
    print "Problem while adding the object: $optName with $optMac to $optIp !\n";
    $ldap->unbind;
    exit 1;
}
else{
	print "Object: $optName with $optMac to $optIp has been created.\n";
}

# close ldap connection
$ldap->unbind;
