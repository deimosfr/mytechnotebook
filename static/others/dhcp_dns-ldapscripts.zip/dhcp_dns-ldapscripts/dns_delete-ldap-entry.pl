#!/usr/bin/perl -w
#
# This script is to delete DNS entry in LDAP
#


# Includes
use strict;
use Getopt::Long;
use AppConfig qw(:expand :argcount);
use Net::LDAP;

# Some values
my $version = "0.4";

# Some configurations
my $configFile = "/usr/local/etc/dhcp-dns_ldapscripts.conf";


# Get all configurations
my $config = AppConfig->new(
    'ldapserver'    => {ARGCOUNT => 1},
    'dhcpdn'        => {ARGCOUNT => 1},
    'dhcpadmin'     => {ARGCOUNT => 1},
    'dhcppasswd'    => {ARGCOUNT => 1},
    'dnsdn'         => {ARGCOUNT => 1},
    'dnsadmin'      => {ARGCOUNT => 1},
    'dnspasswd'     => {ARGCOUNT => 1},
    'debug'
	);
$config->file($configFile);

my $debug=$config->debug();

my $ldapServer=$config->ldapserver();

my $dnsDn=$config->dnsdn();
my $dnsAdmin=$config->dnsadmin();
my $dnsPasswd=$config->dnspasswd();

# If debug, just display all value from config file !
if($debug){
    print "LDAP server is $ldapServer\n";
    print "\n";
    print "DNS params:\n";
    print "\tDNS DN is $dnsDn\n";
    print "\tDNS Admin is $dnsAdmin\n";
    print "\tDNS Passwd is ... Check your config file !\n";
    print "\n";
}

# Params management
Getopt::Long::Configure('no_ignorecase');
my $optVersion = undef;
my $optHelp = undef;
my $optReverse = undef;
my $optName = undef;
my $optValue = undef;
my $optType = undef;
my $optDnsDomain = undef;
GetOptions ("v"   => \$optVersion,	    "version"       => \$optVersion,
            "h"   => \$optHelp,		    "help"          => \$optHelp,
            "r"   => \$optReverse,	    "reverse"	    => \$optReverse,
            "n=s" => \$optName, 	    "name=s"	    => \$optName,
            "a=s" => \$optValue,        "value=s"       => \$optValue,
            "t=s" => \$optType,         "type=s"  	    => \$optType,
            "d=s" => \$optDnsDomain,    "domain=s"  	=> \$optDnsDomain);

# Display usage
sub printUsage() {
    print "Usage: dns_delete-ldap-entry.pl [-n | --name name]\n";
    print "\t[-a | --value value] [-t | --type type]\n";
    print "\t[-d | --domain dns_domain ] [-r | --reverse]\n";
}

# Display legal mentions
sub printLegalMentions() {
    print "\n";
    print "dns_delete-ldap-entry.pl script, version $version\n";
    print "\n";
    print "This script come with ABSOLUTELY NO WARRANTY.  You may redistribute\n";
    print "copies of the plugins under the terms of the GNU General Public License.\n";
    print "For more information about these matters, see the file named COPYING.\n";
    print "\n";
    print "Copyright (c) 2007 Guillaume LOHEZ <silencer\@free-4ever.net>\n";
    print "\n";
}

# Display help
sub printHelp() {
    print "This script is to search entries for DNS with an LDAP backend\n";
    printLegalMentions();
    printUsage();
    print "\n";
    print "Options:\n";
    print "\t-v, --version :\t\tDisplay version of this plugin\n";
    print "\t-h, --help :\t\tDisplay this help message\n";
    print "\t-n, --name :\t\tName of the object to delete\n";
    print "\t-v, --value :\t\tValue for the object to delete\n";
    print "\t-t, --type :\t\tType of the object, possible types are: A, CNAME and NS\n";
    print "\t-d, --dnsdomain :\tDNS domain name which contain the object\n";
    print "\t-r, --reverse :\t\tDelete reverse record for a type A record\n";
    print "\n";
    exit 0;
}
    
# Options checking
if (defined($optVersion)) {
    printLegalMentions();
    exit 0;
}

if (defined($optHelp)) {
    printHelp();
    exit 0;
}

if (!defined($optName)){
    print "To add an object, we need the hostname !\n";
    printUsage();
    exit 1;
}

if (!defined($optValue)){
    print "To add an object, we need a value !\n";
    printUsage();
    exit 1;
}

if (!defined($optType)){
    print "To add an object, we need a type !\n";
    printUsage();
    exit 1;
}

if ($optType !~ /\ba\b/ && $optType !~ /\bA\b/ && 
    $optType !~ /\bcname\b/ && $optType !~ /\bCNAME\b/ &&
    $optType !~ /\bns\b/ && $optType !~ /\bNS\b/ ){
    print "Only allowed types are: A, CNAME and NS !\n";
    printUsage();
    exit 1;
}

if (!defined($optDnsDomain)){
    print "To add an entry, we need the domain name\n";
    printUsage();
    exit 1;
}

if (defined($optReverse) && $optType !~ /\ba\b/ && $optType !~ /\bA\b/ ){
    print "Reverse option is only available for type A record !\n";
    printUsage();
    exit 1;
}


## Main prog

# Ok, we now a connection to LDAP server will be usefull now
# So, connect to ldap server
my $ldap = Net::LDAP->new($ldapServer) or die "$@";
 
# bind to directory with dn and password
my $res = $ldap->bind($dnsAdmin, password => $dnsPasswd);
 
if($res->is_error ){
	print "Bind to $ldapServer with $dnsAdmin and its password unsuccessfull\n";
	exit 1;
}
else{
	if($debug){
		print "Bind to $ldapServer with $dnsAdmin and its password successfull\n";
        print "\n";
	}
}


## Check if the zone exist or not in this DNS
$res = $ldap->search(	base   => $dnsDn,
                        scope  => 'sub',
                        filter => '(&(objectClass=dNSZone)(zoneName='.$optDnsDomain.'))'
			);
if(!$res->entries){
    print "The zone: $optDnsDomain does not exist on this server !\n";
    $ldap->unbind;
    exit 2;
}


## Type "A" entry
if($optType =~ /\ba\b/ || $optType =~ /\bA\b/){
    if($debug){
        print "Type A record to delete:\n";
        print "\tHostname: $optName\n";
        print "\tValue: $optValue\n";
        print "\tDNS Domain: $optDnsDomain\n";
        if($optReverse){
            print "\tReverse object is requested to delete !\n"
        }
        print "\n";
    }
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(dNSClass=IN)(relativeDomainName='.$optName.')(zoneName='.$optDnsDomain.')(aRecord='.$optValue.'))'
    			);

    print "A record with name: $optName and IP: $optValue\n";
    if(!$res->entries){
        print "\tNot found !\n";
    }
    else{
        my $aEntry = $res->entry;
        my $dn = "relativeDomainName=".$aEntry->get_value("relativeDomainName").",ou=".$optDnsDomain.",".$dnsDn;
        if($debug){
            print "Dn to delete: $dn\n";
        }

        my $ip = $aEntry->get_value('aRecord');

        $res = $ldap->delete($dn);
        if( $res->is_error ){
        	print "\tProblem while deleting this object !\n";
        }
        else{
        	print "\tSuccessfully deleted.\n";
        }
        print "\n";

    # Update the serial of the zone
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$optDnsDomain.'))'
   			);
    my $temp = $res->entry->get_value("sOARecord");
    my @temp2 = split(/ /, $temp);
    my $serial = $temp2[2];

    my $cYear = substr($serial, 0, 4);
    my $cMonth = substr($serial, 4, 2);
    my $cDay = substr($serial, 6, 2);
    my $cNumber = substr($serial, 8, 3);

    if($debug){
        print "Extracted year is: $cYear\n";
        print "Extracted month is: $cMonth\n";
        print "Extracted day is: $cDay\n";
        print "Extracted number is: $cNumber\n";
    }

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    
    my $change = 0;

    if($cYear != ($year+1900)){
        $cYear = ($year+1900);
        $change = 1;
    }
    if($cMonth != ($mon+1)){
        $cMonth = ($mon+1);
        if($cMonth < 10 ){
            $cMonth = "0".$cMonth;
        }
        $change = 1;
    }
    if($cDay != $mday){
        $cDay = $mday;
        if($cDay < 10 ){
            $cDay = "0".$cDay;
        }
        $change = 1;
    }
    if($change){
        $cNumber = "001";
    }
    else{
        $cNumber++;
    }

    my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
    $temp2[2] = $newSerial;
    if($debug){
        print "New serial is: $newSerial\n";
    }

    my $newSoa = join(" ", @temp2);
    if($debug){
        print "New SOA is: $newSoa\n";
    }

    $res = $ldap->modify( "relativeDomainName=@,ou=".$optDnsDomain.",".$dnsDn,
                changes => [
                    replace => [ sOARecord => $newSoa ]
                ]
            );

    if($res->is_error){
        print "Problem updating: SOA of zone: $optDnsDomain with new serial: $newSerial !\n";
        $ldap->unbind;
        exit 1;
    }
    else{
        if($debug){
    	    print "Updating: SOA for zone $optDnsDomain with serial $newSerial.\n";
        }
    }

    # if option --reverse, we delete the reverse entry !
    if(defined($optReverse)){
        if($debug){
            print "Now working on reverse entry\n";
        }

        # Then the type PTR records
        my @separetedIp = split(/\./, $ip);
        my $last = pop(@separetedIp);
        my @reversedIp = reverse(@separetedIp);
        my $joinedIp = join(".", @reversedIp);

        $res = $ldap->search(	base   => $dnsDn,
                                scope  => 'sub',
                                filter => '(&(objectClass=dNSZone)(relativeDomainName='.$last.')(zoneName='.$joinedIp.'.in-addr.arpa)(pTRRecord='.$optName.'.'.$optDnsDomain.'.))'
        			);

        print "Corresponding PTR record(s) with name: $optName\n";
        if(!$res->entries){
            print "\tNot found !\n";
        }
        else{
            my $reverseDn = "relativeDomainName=".$last.",ou=".$joinedIp.".in-addr.arpa,".$dnsDn;
            if($debug){
                print "Dn to delete: $reverseDn\n";
            }
        
            $res = $ldap->delete($reverseDn);
            if( $res->is_error ){
            	print "Problem while deleting this object !\n";
            }
            else{
              	print "\tSuccessfully deleted.\n";
            }
        }
        print "\n";

        # Update the serial of the zone
        $res = $ldap->search(	base   => $dnsDn,
                                scope  => 'sub',
                                filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$joinedIp.'.in-addr.arpa))'
   	    		);
        my $temp = $res->entry->get_value("sOARecord");
        my @temp2 = split(/ /, $temp);
        my $serial = $temp2[2];
    
        my $cYear = substr($serial, 0, 4);
        my $cMonth = substr($serial, 4, 2);
        my $cDay = substr($serial, 6, 2);
        my $cNumber = substr($serial, 8, 3);
    
        if($debug){
            print "Extracted year is: $cYear\n";
            print "Extracted month is: $cMonth\n";
            print "Extracted day is: $cDay\n";
            print "Extracted number is: $cNumber\n";
        }
    
        my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
        
        my $change = 0;
    
        if($cYear != ($year+1900)){
            $cYear = ($year+1900);
            $change = 1;
        }
        if($cMonth != ($mon+1)){
            $cMonth = ($mon+1);
            if($cMonth < 10 ){
                $cMonth = "0".$cMonth;
            }
            $change = 1;
        }
        if($cDay != $mday){
            $cDay = $mday;
            if($cDay < 10 ){
                $cDay = "0".$cDay;
            }
            $change = 1;
        }
        if($change){
            $cNumber = "001";
        }
        else{
            $cNumber++;
        }
    
        my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
        $temp2[2] = $newSerial;
        if($debug){
            print "New serial is: $newSerial\n";
        }
    
        my $newSoa = join(" ", @temp2);
        if($debug){
            print "New SOA is: $newSoa\n";
        }
    
        $res = $ldap->modify( "relativeDomainName=@,ou=".$joinedIp.".in-addr.arpa,".$dnsDn,
                    changes => [
                        replace => [ sOARecord => $newSoa ]
                    ]
                );
    
        if($res->is_error){
            print "Problem updating: SOA of zone: $joinedIp.in-addr.apra with new serial: $newSerial !\n";
            $ldap->unbind;
            exit 1;
        }
        else{
            if($debug){
        	    print "Updating: SOA for zone $joinedIp.in-addr.apra with serial $newSerial.\n";
            }
        }

        }    
    }
}

## Type "CNAME" entry
if($optType =~ /\bcname\b/ || $optType =~ /\bCNAME\b/){
    if($debug){
        print "Type CNAME record to add:\n";
        print "\tAlias name: $optName\n";
        print "\tHostname: $optValue\n";
        print "\tDNS Domain: $optDnsDomain\n";
        print "\n";
    }

    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(dNSClass=CNAME)(relativeDomainName='.$optName.')(zoneName='.$optDnsDomain.')(cNAMERecord='.$optValue.'))'
    			);

    print "CNAME record with alias: $optName on host: $optValue\n";
    if(!$res->entries){
        print "\tNot found !\n";
    }
    else{
        my $cnameEntry = $res->entry;
        my $dn = "relativeDomainName=".$cnameEntry->get_value('relativeDomainName').",ou=".$optDnsDomain.",".$dnsDn;
        if($debug){
            print "Dn to delete: $dn\n";
        }

        $res = $ldap->delete($dn);
        if( $res->is_error ){
        	print "Problem while deleting this object !\n";
        }
        else{
        	print "\tSuccessfully deleted.\n";
        }
        print "\n";
    }

    # Update the serial of the zone
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$optDnsDomain.'))'
   			);
    my $temp = $res->entry->get_value("sOARecord");
    my @temp2 = split(/ /, $temp);
    my $serial = $temp2[2];

    my $cYear = substr($serial, 0, 4);
    my $cMonth = substr($serial, 4, 2);
    my $cDay = substr($serial, 6, 2);
    my $cNumber = substr($serial, 8, 3);

    if($debug){
        print "Extracted year is: $cYear\n";
        print "Extracted month is: $cMonth\n";
        print "Extracted day is: $cDay\n";
        print "Extracted number is: $cNumber\n";
    }

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    
    my $change = 0;

    if($cYear != ($year+1900)){
        $cYear = ($year+1900);
        $change = 1;
    }
    if($cMonth != ($mon+1)){
        $cMonth = ($mon+1);
        if($cMonth < 10 ){
            $cMonth = "0".$cMonth;
        }
        $change = 1;
    }
    if($cDay != $mday){
        $cDay = $mday;
        if($cDay < 10 ){
            $cDay = "0".$cDay;
        }
        $change = 1;
    }
    if($change){
        $cNumber = "001";
    }
    else{
        $cNumber++;
    }

    my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
    $temp2[2] = $newSerial;
    if($debug){
        print "New serial is: $newSerial\n";
    }

    my $newSoa = join(" ", @temp2);
    if($debug){
        print "New SOA is: $newSoa\n";
    }

    $res = $ldap->modify( "relativeDomainName=@,ou=".$optDnsDomain.",".$dnsDn,
                changes => [
                    replace => [ sOARecord => $newSoa ]
                ]
            );

    if($res->is_error){
        print "Problem updating: SOA of zone: $optDnsDomain with new serial: $newSerial !\n";
        $ldap->unbind;
        exit 1;
    }
    else{
        if($debug){
    	    print "Updating: SOA for zone $optDnsDomain with serial $newSerial.\n";
        }
    }

}

## Type "NS" entry
if($optType =~ /\bns\b/ || $optType =~ /\bNS\b/){
    if($debug){
        print "Type NS record to add:\n";
        print "\tZone name: $optName\n";
        print "\tHostname: $optValue\n";
        print "\tDNS Domain: $optDnsDomain\n";
        print "\n";
    }

    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(dNSClass=NS)(relativeDomainName='.$optName.')(zoneName='.$optDnsDomain.')(nSRecord='.$optValue.'))'
    			);

    print "NS record for zone: $optName with delegation to host: $optValue\n";
    if(!$res->entries){
        print "\tNot found !\n";
    }
    else{
        my $dn = "relativeDomainName=".$optName.",ou=".$optDnsDomain.",".$dnsDn;
        if($debug){
            print "Dn to delete: $dn\n";
        }

        $res = $ldap->delete($dn);
        if( $res->is_error ){
        	print "Problem while deleting this object !\n";
        }
        else{
        	print "\tSuccessfully deleted.\n";
        }
    print "\n";
    }

    # Update the serial of the zone
    $res = $ldap->search(	base   => $dnsDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dNSZone)(relativeDomainName=@)(zoneName='.$optDnsDomain.'))'
   			);
    my $temp = $res->entry->get_value("sOARecord");
    my @temp2 = split(/ /, $temp);
    my $serial = $temp2[2];

    my $cYear = substr($serial, 0, 4);
    my $cMonth = substr($serial, 4, 2);
    my $cDay = substr($serial, 6, 2);
    my $cNumber = substr($serial, 8, 3);

    if($debug){
        print "Extracted year is: $cYear\n";
        print "Extracted month is: $cMonth\n";
        print "Extracted day is: $cDay\n";
        print "Extracted number is: $cNumber\n";
    }

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    
    my $change = 0;

    if($cYear != ($year+1900)){
        $cYear = ($year+1900);
        $change = 1;
    }
    if($cMonth != ($mon+1)){
        $cMonth = ($mon+1);
        if($cMonth < 10 ){
            $cMonth = "0".$cMonth;
        }
        $change = 1;
    }
    if($cDay != $mday){
        $cDay = $mday;
        if($cDay < 10 ){
            $cDay = "0".$cDay;
        }
        $change = 1;
    }
    if($change){
        $cNumber = "001";
    }
    else{
        $cNumber++;
    }

    my $newSerial = $cYear.$cMonth.$cDay.$cNumber;
    $temp2[2] = $newSerial;
    if($debug){
        print "New serial is: $newSerial\n";
    }

    my $newSoa = join(" ", @temp2);
    if($debug){
        print "New SOA is: $newSoa\n";
    }

    $res = $ldap->modify( "relativeDomainName=@,ou=".$optDnsDomain.",".$dnsDn,
                changes => [
                    replace => [ sOARecord => $newSoa ]
                ]
            );

    if($res->is_error){
        print "Problem updating: SOA of zone: $optDnsDomain with new serial: $newSerial !\n";
        $ldap->unbind;
        exit 1;
    }
    else{
        if($debug){
    	    print "Updating: SOA for zone $optDnsDomain with serial $newSerial.\n";
        }
    }

}

# close ldap connection
$ldap->unbind;
