#!/usr/bin/perl -w
#
# This script is to delete DHCP entry in LDAP
#


# Includes
use strict;
use Getopt::Long;
use AppConfig qw(:expand :argcount);
use Net::LDAP;

# Some values
my $version = "0.4";

# Some configurations
my $configFile = "/usr/local/etc/dhcp-dns_ldapscripts.conf";


# Get all configurations
my $config = AppConfig->new(
    'ldapserver'    => {ARGCOUNT => 1},
    'dhcpdn'        => {ARGCOUNT => 1},
    'dhcpadmin'     => {ARGCOUNT => 1},
    'dhcppasswd'    => {ARGCOUNT => 1},
    'dnsdn'         => {ARGCOUNT => 1},
    'dnsadmin'      => {ARGCOUNT => 1},
    'dnspasswd'     => {ARGCOUNT => 1},
    'debug'
	);
$config->file($configFile);

my $debug=$config->debug();

my $ldapServer=$config->ldapserver();

my $dhcpDn=$config->dhcpdn();
my $dhcpAdmin=$config->dhcpadmin();
my $dhcpPasswd=$config->dhcppasswd();

# If debug, just display all value from config file !
if($debug){
    print "LDAP server is $ldapServer\n";
    print "\n";
    print "DHCP params:\n";
    print "\tDHCP DN is $dhcpDn\n";
    print "\tDHCP Admin is $dhcpAdmin\n";
    print "\tDHCP Passwd is ... Check your config file !\n";
    print "\n";
}

# Params management
Getopt::Long::Configure('no_ignorecase');
my $optVersion = undef;
my $optHelp = undef;
my $optName = undef;
my $optIp = undef;
my $optMac = undef;
my $optDomain = undef;
GetOptions ("v"   => \$optVersion,	    "version"       => \$optVersion,
            "h"   => \$optHelp,		    "help"          => \$optHelp,
            "n=s" => \$optName, 	    "name=s"	    => \$optName,
            "i=s" => \$optIp,           "ip=s"        	=> \$optIp,
            "m=s" => \$optMac,          "mac=s"    	    => \$optMac,
            "d=s" => \$optDomain,       "domain=s"  	=> \$optDomain);

# Display usage
sub printUsage() {
    print "Usage: dhcp_delete-ldap-entry.pl [-n | --name hostname]\n";
    print "\t [-i | --ip ip_address] [-m | --mac mac_adress]\n";
    print "\t [-d | --domain dhcp_admin_domain]\n";
}

# Display legal mentions
sub printLegalMentions() {
    print "\n";
    print "dhcp_delete-ldap-entry.pl script, version $version\n";
    print "\n";
    print "This script come with ABSOLUTELY NO WARRANTY.  You may redistribute\n";
    print "copies of the plugins under the terms of the GNU General Public License.\n";
    print "For more information about these matters, see the file named COPYING.\n";
    print "\n";
    print "Copyright (c) 2007 Guillaume LOHEZ <silencer\@free-4ever.net>\n";
    print "\n";
}

# Display help
sub printHelp() {
    print "This script is to delete entries for DHCP with an LDAP backend\n";
    printLegalMentions();
    printUsage();
    print "\n";
    print "Options:\n";
    print "\t-v, --version :\t\tDisplay version of this plugin\n";
    print "\t-h, --help :\t\tDisplay this help message\n";
    print "\t-n, --name :\t\tName of the host to delete\n";
    print "\t-i, --ip :\t\tIP address to delete\n";
    print "\t-m, --mac :\t\tMAC address to delete\n";
    print "\t-d, --domain :\t\tDHCP admin domain to delete the host inside\n";
    print "\n";
    exit 0;
}
    
# Options checking
if (defined($optVersion)) {
    printLegalMentions();
    exit 0;
}

if (defined($optHelp)) {
    printHelp();
    exit 0;
}

if (!defined($optName) && !defined($optIp) && !defined($optMac)){
    print "To delete an object, we need a hostname, an IP or a MAC address !\n";
    printUsage();
    exit 1;
}

if (defined($optName) && defined($optIp) && defined($optMac) || 
    defined($optName) && defined($optIp) ||
    defined($optName) && defined($optMac) ||
    defined($optIp) && defined($optMac) ){
    print "We can only delete for one type of object in the same time !\n";
    printUsage();
    exit 1;
}

if (!defined($optDomain)){
    print "To delete an entry, we need the admin domain name\n";
    printUsage();
    exit 1;
}


## Main prog

# Ok, we now a connection to LDAP server will be usefull now
# So, connect to ldap server
my $ldap = Net::LDAP->new($ldapServer) or die "$@";
 
# bind to directory with dn and password
my $res = $ldap->bind($dhcpAdmin, password => $dhcpPasswd);
 
if($res->is_error ){
	print "Bind to $ldapServer with $dhcpAdmin and its password unsuccessfull\n";
	exit 1;
}
else{
	if($debug){
		print "Bind to $ldapServer with $dhcpAdmin and its password successfull\n";
        print "\n";
	}
}

# We are deleting a hostname
if($optName){
    $res = $ldap->search(	base   => $dhcpDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dhcpHost)(cn='.$optName.'))'
    			);

    if(!$res->entries){
        print "Object with the name: $optName not found !\n";
    }
    else{
        my @nameTemp = split(/ /, $res->entry->get_value("dhcpStatements"));
        my $nameIp = $nameTemp[1];
        @nameTemp = split(/ /, $res->entry->get_value("dhcpHWAddress"));
        my $nameMac = $nameTemp[1];
        my $nameCn = $res->entry->get_value("cn");

        my $dn = "cn=".$optName.",cn=networks,cn=".$optDomain.",".$dhcpDn;
        if($debug){
            print "Dn to delete: $dn\n";
        }

        $res = $ldap->delete($dn);
        if( $res->is_error ){
        	print "Problem while deleting the object: $nameCn with IP: $nameIp and $nameMac !\n";
        }
        else{
        	print "Object: $nameCn with IP: $nameIp and $nameMac successfully deleted.\n";
        }
    }
    print "\n";

}

# We are looking for an IP address
if($optIp){
    $res = $ldap->search(	base   => $dhcpDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dhcpHost)(dhcpStatements=fixed-address '.$optIp.'))'
    			);

    if(!$res->entries){
        print "Object with the IP: $optIp not found !\n";
    }
    else{
        my @ipTemp = split(/ /, $res->entry->get_value("dhcpStatements"));
        my $ipIp = $ipTemp[1];
        @ipTemp = split(/ /, $res->entry->get_value("dhcpHWAddress"));
        my $ipMac = $ipTemp[1];
        my $ipCn = $res->entry->get_value("cn");

        my $dn = "cn=".$ipCn.",cn=networks,cn=".$optDomain.",".$dhcpDn;
        if($debug){
            print "Dn to delete: $dn\n";
        }

        $res = $ldap->delete($dn);
        if( $res->is_error ){
        	print "Problem while deleting the object: $ipCn with IP: $ipIp and $ipMac !\n";
        }
        else{
        	print "Object: $ipCn with IP: $ipIp and $ipMac successfully deleted.\n";
        }
    print "\n";
    }
}

# We are looking for a MAC address
if($optMac){
    $res = $ldap->search(	base   => $dhcpDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dhcpHost)(dhcpHWAddress=ethernet '.$optMac.'))'
    			);

    if(!$res->entries){
        print "Object with the MAC: $optMac not found !\n";
    }
    else{
        my @macTemp = split(/ /, $res->entry->get_value("dhcpStatements"));
        my $macIp = $macTemp[1];
        @macTemp = split(/ /, $res->entry->get_value("dhcpHWAddress"));
        my $macMac = $macTemp[1];
        my $macCn = $res->entry->get_value("cn");

        my $dn = "cn=".$macCn.",cn=networks,cn=".$optDomain.",".$dhcpDn;
        if($debug){
            print "Dn to delete: $dn\n";
        }

        $res = $ldap->delete($dn);
        if( $res->is_error ){
        	print "Problem while deleting the object: $macCn with IP: $macIp and $macMac !\n";
        }
        else{
        	print "Object: $macCn with IP: $macIp and $macMac successfully deleted.\n";
        }
    print "\n";
    }

}

# close ldap connection
$ldap->unbind;
