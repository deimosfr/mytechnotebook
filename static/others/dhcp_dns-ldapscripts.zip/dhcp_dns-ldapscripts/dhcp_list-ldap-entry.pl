#!/usr/bin/perl -w
#
# This script is to list all DHCP entry in LDAP
#


# Includes
use strict;
use Getopt::Long;
use AppConfig qw(:expand :argcount);
use Net::LDAP;

# Some values
my $version = "0.4";

# Some configurations
my $configFile = "/usr/local/etc/dhcp-dns_ldapscripts.conf";


# Get all configurations
my $config = AppConfig->new(
    'ldapserver'    => {ARGCOUNT => 1},
    'dhcpdn'        => {ARGCOUNT => 1},
    'dhcpadmin'     => {ARGCOUNT => 1},
    'dhcppasswd'    => {ARGCOUNT => 1},
    'dnsdn'         => {ARGCOUNT => 1},
    'dnsadmin'      => {ARGCOUNT => 1},
    'dnspasswd'     => {ARGCOUNT => 1},
    'debug'
	);
$config->file($configFile);

my $debug=$config->debug();

my $ldapServer=$config->ldapserver();

my $dhcpDn=$config->dhcpdn();
my $dhcpAdmin=$config->dhcpadmin();
my $dhcpPasswd=$config->dhcppasswd();

# If debug, just display all value from config file !
if($debug){
    print "LDAP server is $ldapServer\n";
    print "\n";
    print "DHCP params:\n";
    print "\tDHCP DN is $dhcpDn\n";
    print "\tDHCP Admin is $dhcpAdmin\n";
    print "\tDHCP Passwd is ... Check your config file !\n";
    print "\n";
}

# Params management
Getopt::Long::Configure('no_ignorecase');
my $optVersion = undef;
my $optHelp = undef;
my $optDomain = undef;
GetOptions ("v"   => \$optVersion,	    "version"       => \$optVersion,
            "h"   => \$optHelp,		    "help"          => \$optHelp,
            "d=s" => \$optDomain,       "domain=s"  	=> \$optDomain);

# Display usage
sub printUsage() {
    print "Usage: dhcp_search-ldap-entry.pl [-d | --domain dhcp_admin_domain]\n";
}

# Display legal mentions
sub printLegalMentions() {
    print "\n";
    print "dhcp_list-ldap-entry.pl script, version $version\n";
    print "\n";
    print "This script come with ABSOLUTELY NO WARRANTY.  You may redistribute\n";
    print "copies of the plugins under the terms of the GNU General Public License.\n";
    print "For more information about these matters, see the file named COPYING.\n";
    print "\n";
    print "Copyright (c) 2007 Guillaume LOHEZ <silencer\@free-4ever.net>\n";
    print "\n";
}

# Display help
sub printHelp() {
    print "This script is to list all entries for DHCP with an LDAP backend\n";
    printLegalMentions();
    printUsage();
    print "\n";
    print "Options:\n";
    print "\t-v, --version :\t\tDisplay version of this plugin\n";
    print "\t-h, --help :\t\tDisplay this help message\n";
    print "\t-d, --domain :\t\tDHCP admin domain to list\n";
    print "\n";
    exit 0;
}
    
# Options checking
if (defined($optVersion)) {
    printLegalMentions();
    exit 0;
}

if (defined($optHelp)) {
    printHelp();
    exit 0;
}


## Main prog

# Ok, we now a connection to LDAP server will be usefull now
# So, connect to ldap server
my $ldap = Net::LDAP->new($ldapServer) or die "$@";
 
# bind to directory with dn and password
my $res = $ldap->bind($dhcpAdmin, password => $dhcpPasswd);
 
if($res->is_error ){
	print "Bind to $ldapServer with $dhcpAdmin and its password unsuccessfull\n";
	exit 1;
}
else{
	if($debug){
		print "Bind to $ldapServer with $dhcpAdmin and its password successfull\n";
        print "\n";
	}
}

# We are looking for all static entries
if(defined($optDomain)){
    $res = $ldap->search(	base   => "cn=".$optDomain.",".$dhcpDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dhcpHost)(cn=*))'
    			);
}
else{
    $res = $ldap->search(	base   => $dhcpDn,
                            scope  => 'sub',
                            filter => '(&(objectClass=dhcpHost)(cn=*))'
    			);
}
if(!$res->entries){
    print "No static entry found !\n";
}
else{
    foreach my $entry ($res->entries) {
        my @mac = split(/ /, $entry->get_value('dhcpHWAddress'));
        my @ip = split(/ /, $entry->get_value('dhcpStatements'));
        print "Hostname: ".$entry->get_value('cn')." with IP: ".$ip[1]." and MAC: ".$mac[1]."\n";
    }
}


# close ldap connection
$ldap->unbind;
